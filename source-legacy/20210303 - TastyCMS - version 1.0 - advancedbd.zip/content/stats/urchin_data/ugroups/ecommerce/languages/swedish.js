parent.ssLoad( 0,"Webbrapport ");
parent.ssLoad( 1,"Trafik");
parent.ssLoad( 2,"�gonblicksbild");
parent.ssLoad( 3,"Timdiagram");
parent.ssLoad( 4,"Dagdiagram");
parent.ssLoad( 5,"M�nadsdiagram");
parent.ssLoad( 6,"Sidor");
parent.ssLoad( 7,"Vanligaste sidor");
parent.ssLoad( 8,"Katalogtr�d");
parent.ssLoad( 9,"Filformat");
parent.ssLoad(10,"Status/fel");
parent.ssLoad(11,"L�nkar");
parent.ssLoad(12,"Vanligaste l�nkar");
parent.ssLoad(13,"Vanligaste nyckelord");
parent.ssLoad(14,"L�nktr�d");
parent.ssLoad(15,"Nyckelordstr�d");
parent.ssLoad(16,"S�kprogram");
parent.ssLoad(17,"Dom�ner");
parent.ssLoad(18,"Vanligaste dom�ner");
parent.ssLoad(19,"Dom�ntr�d");
parent.ssLoad(20,"Vanligaste l�nder");
parent.ssLoad(21,"Internetleverant�rer");
parent.ssLoad(22,"Webbl�sare");
parent.ssLoad(23,"Webbl�sartr�d");
parent.ssLoad(24,"Plattformstr�d");
parent.ssLoad(25,"Vanligaste kombination");
parent.ssLoad(26,"Sp�rning");
parent.ssLoad(27,"Ing�ngssidor");
parent.ssLoad(28,"Utg�ngssidor");
parent.ssLoad(29,"Klicks�kv�g");
parent.ssLoad(30,"Bes�ksdjup");
parent.ssLoad(31,"E-handel");
parent.ssLoad(32,"Totalt");
parent.ssLoad(33,"Vanligaste produkter");
parent.ssLoad(34,"Produkttr�d");
parent.ssLoad(35,"Regioner");
parent.ssLoad(36,"Datumintervall");
parent.ssLoad(37,"Dag");
parent.ssLoad(38,"Vecka");
parent.ssLoad(39,"M�nad");
parent.ssLoad(40,"�r");
parent.ssLoad(41,"Ange intervall");
parent.ssLoad(42,"Kontroller");
parent.ssLoad(43,"Inst�llningar");
parent.ssLoad(44,"Exportera data");
parent.ssLoad(45,"Invertera");
parent.ssLoad(46,"Hj�lp");
parent.ssLoad(47,"Sammanfattning ");
parent.ssLoad(48,"Genomsnitt/dag");
parent.ssLoad(49,"�ndra");
parent.ssLoad(50,"Anv�ndarnamn");
parent.ssLoad(51,"Bes�kare");
parent.ssLoad(52,"Sidvyer");
parent.ssLoad(53,"Tr�ffar");
parent.ssLoad(54,"Byte");
parent.ssLoad(55,"Tid");
parent.ssLoad(56,"Dollar");
parent.ssLoad(57,"Totalt");
parent.ssLoad(58,"Per bes�kare");
parent.ssLoad(59,"Rapport");
parent.ssLoad(60,"Visa per");
parent.ssLoad(61,"Webbrapport f�r");
parent.ssLoad(62,"#Visa");
parent.ssLoad(63,"F�reg�ende");
parent.ssLoad(64,"Procent");
parent.ssLoad(65,"N�sta");
parent.ssLoad(66,"Hj�lpinfo");
parent.ssLoad(67,"<B>Licens saknas!</B> Du m�ste ha en Urchin-licens f�r att kunna anv�nda denna rapportfunktion. Dom�nbaserade licenser f�r enskilda webbplatser finns online f�r $199. Om du vill k�pa en licens f�r denna webbplats och aktivera alla rapporter nu, klickar du p�  <A CLASS=normal HREF=\"javascript:parent.getLicense();\">h�r</A>.");
parent.ssLoad(68,"Rapporten �r inaktiverad");
parent.ssLoad(69,"av");

parent.ssLoad(70,"�gonblicksbild: Med hj�lp av �gonblicksbilden kan du snabbt visa aktiviteten p� din webbsida. Delarna i stapeldiagrammet motsvarar Bes�kare, enligt standardinst�llningen. Du kan v�xla till Sidvyer, Tr�ffar eller Antal �verf�rda byte (bandbredd). Om du har installerat e-Urchins e-handelsmodul visas �ven fliken Dollar, d�r du kan visa information om denna och de flesta andra rapporter, n�r det g�ller hur mycket pengar som har anv�nts p� din webbsida.<P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/201.html\">klicka h�r</A>.");

parent.ssLoad(71,"Sammanfattning: Sammanfattningsrapporten �r en enkel, numerisk kontrollr�kning av antalet bes�kare p� din webbplats inom ett visst datumintervall. Delarna i rapporten �r Totalt, Genomsnitt och Genomsnitt per bes�kare. Tips! Om du vill j�mf�ra denna information med en annan tidsperiod �ppnar du ett nytt webbl�sarf�nster och anger ett nytt datumintervall.<P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/202.html\">klicka h�r</A>.");

parent.ssLoad(72,"Timdiagram: Detta diagram visar antalet bes�kare p� din webbplats vid olika tidpunkter under dagen. Informationen t�cker en hel m�nads aktiviteter, i antalet bes�kare. Du kan v�xla mellan stapeldiagram f�r Sidvyer, Tr�ffar eller Antal �verf�rda byte (bandbredd).  <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/203.html\">klicka h�r</A>.");

parent.ssLoad(73,"Dagdiagram: Detta diagram visar antalet bes�kare p� din webbplats per dag under en viss tidsperiod. Anv�nd funktionen f�r datumintervall n�r du vill ange ett annat intervall. Delarna i stapeldiagrammet motsvarar Bes�kare, enligt standardinst�llningen, och kan v�xlas till Sidvyer, Tr�ffar eller Antal �verf�rda byte (bandbredd).<P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/204.html\">klicka h�r</A>.");

parent.ssLoad(74,"M�nadsdiagram: Detta diagram visar antalet bes�kare p� din webbplats per m�nad under de senaste 12 m�naderna. Om din webbplats har varit i drift under mindre �n 12 m�nader visar diagrammet  information f�r de m�nader som �r tillg�ngliga. Delarna i stapeldiagrammet motsvarar Bes�kare, enligt standardinst�llningen, och kan v�xlas till Sidvyer, Tr�ffar eller Antal �verf�rda byte (bandbredd).<P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/205.html\">klicka h�r</A>.");

parent.ssLoad(75,"Vanligaste sidor: Denna rapport visar de 10 mest bes�kta sidorna p� din webbplats. Stapell�ngden motsvarar den relativa procentandelen. Du kan styra hur m�nga sidor som ska visas i denna rapport genom att �ndra v�rdet i omr�det #Visa.<P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/206.html\">klicka h�r</A>.");

parent.ssLoad(76,"Katalogtr�d: Denna rapport visar varje katalog (kallas ocks� mapp) p� din webbplats och de sidor i katalogen som har bes�kts. Om du vill visa dessa sidor klickar du p� den lilla pilen bredvid varje post s� ut�kas menyn. Du kan styra hur m�nga kataloger som ska visas i denna rapport genom att �ndra v�rdet i omr�det #Visa. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/207.html\">klicka h�r</A>.");

parent.ssLoad(77,"Filformat: Denna rapport visar vilka filformat som laddats ned fr�n din webbplats, exempelvis GIF-bilder, HTML-filer och CGI-skript. Det kan vara intressant att visa denna rapport n�r det g�ller tr�ffar (serverf�rfr�gningar) j�mf�rt med byte f�r att kunna se vilka filformat som anv�nder de flesta n�tverksresurserna. Du kan styra hur m�nga filformat som ska visas i denna rapport genom att �ndra v�rdet i omr�det #Visa. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/208.html\">klicka h�r</A>.");

parent.ssLoad(78,"Status/fel: Denna rapport visar statuskoden f�r varje svar. Felen i 400-kategorin innefattar filer som inte hittas. Klicka p� den lilla pilen om du vill ha mer information om felen. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/1204.html\">klicka h�r</A>.");

parent.ssLoad(79,"Vanligaste l�nkar: Denna rapport visar adresserna (URL) till de webbsidor som har l�nkar till din webbplats som n�gon klickat p�. Detta innefattar med all sannolikhet s�kprogram och andra katalogplatser. Du kan styra hur m�nga l�nkar som ska visas i denna rapport genom att �ndra v�rdet i omr�det #Visa. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/209.html\">klicka h�r</A>.");

parent.ssLoad(80,"Vanligaste nyckelord: Denna rapport visar de nyckelord som anv�ndare skriver i s�kprogram f�r att hitta din webbplats. Med hj�lp av rapporten kan du se om de nyckelord du f�rv�ntade dig skulle leda bes�kare till din webbplats har �nskv�rd effekt.<P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/211.html\">klicka h�r</A>.");

parent.ssLoad(81,"L�nktr�d: Denna rapport visar de vanligaste dom�nerna som bes�karna anv�nt f�r att komma till din sida. Du kan klicka p� den lilla bl� pilen bredvid varje post n�r du vill visa de faktiska sidorna som inneh�ller de l�nkar som bes�karna klickade p�. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/210.html\">klicka h�r</A>.");

parent.ssLoad(82,"Nyckelordstr�d: Denna mycket anv�ndbara rapport visar de vanligaste s�kprogrammen som bes�kare anv�nt f�r att hitta din webbplats. Genom att klicka p� den lilla pilen bredvid varje post kan du visa vilka nyckelord som anv�nts i olika s�kprogram f�r att hitta din webbplats. Du kan styra hur m�nga poster som ska visas i rapporten genom att ange ett nytt v�rde i rutan \"#Visa\" och trycka p� Retur. Du kan v�xla rapporten mellan Bes�kare, Sidvyer, Tr�ffar, Antal �verf�rda byte (bandbredd) och Tid.  <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/212.html\">klicka h�r</A>.");

parent.ssLoad(83,"S�kprogram: Denna rapport visar alla s�kprogram som bes�kare anv�nt f�r att hitta din webbplats. Genom att klicka p� den lilla bl� pilen bredvid varje post kan du visa vilka nyckelord som  skrevs. F�r webbadministrat�rer �r detta en av Urchins mest anv�ndbara rapporter. H�r ser du exakt hur v�l din webbplats �r registrerad i olika s�kprogram och vilka nyckelord som ger tr�ffar. Detta �r mycket anv�ndbart om du nyligen har registrerat eller �ndrat inneh�llet p� webbplatsen.<P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/212.html\">klicka h�r</A>.");

parent.ssLoad(84,"Vanligaste dom�ner: Denna praktiska rapport visar fr�n vilka n�tverk bes�karna till din webbplats kommer. Urchin k�nner igen de flesta n�tverk, men inte alla. Det inneb�r att vissa n�tverk inte kan identifieras. Denna information �r viktig n�r du skr�ddarsyr din webbplats, eftersom vissa bes�kare har webbl�sare med olika funktioner och m�jligheter. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/213.html\">klicka h�r</A>.");

parent.ssLoad(85,"Dom�ntr�d: Denna report visar de vanligaste dom�nerna, exempelvis .com och .net, som bes�karna p� din webbplats kommer ifr�n. Genom att klicka p� pilen bredvid varje post kan du visa n�tverket under respektive dom�n. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/214.html\">klicka h�r</A>.");

parent.ssLoad(86,"Vanligaste l�nder: Denna rapport visar de  l�nder som har bes�kt din webbplats flest g�nger. De framf�rallt amerikanska dom�nerna (com, net och org) och de dom�ner som endast finns i USA (edu, gov och mil) �r inkluderade. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/215.html\">klicka h�r</A>.");

parent.ssLoad(87,"Internetleverant�rer: Denna rapport visar de <B>st�rsta</B> internetleverant�rerna, exempelvis earthlink.net, vars kunder har bes�kt din webbplats. Du kan styra hur m�nga poster som ska visas i denna rapport genom att ange ett nytt v�rde i rutan \"#Visa\" och trycka p� Retur. Rapporten kan v�xlas mellan Bes�kare, Sidvyer, Tr�ffar, Antal �verf�rda byte (bandbredd) och Tid.  <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/topisps.html\">klicka h�r</A>.");

parent.ssLoad(88,"Webbl�sartr�d: Denna rapport visar de vanligaste webbl�sarna, exempelvis Netscape Navigator och Microsoft Internet Explorer, som m�nniskor anv�nt f�r att bes�ka din webbplats. Du kan ocks� visa robotar, exempelvis s�dana som anv�nds av s�kprogram f�r att en anv�ndare ska hitta inneh�ll p� en webbsida, och andra typer av automatiserade internetprogram. Genom att klicka p� pilen bredvid varje post kan du visa versioner av varje enskild webbl�sare eller agent. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/216.html\">klicka h�r</A>.");

parent.ssLoad(89,"Plattformstr�d: Denna rapport visar de vanligaste datorplattformarna, exempelvis Windows, Macintosh och Unix, som anv�nts f�r att bes�ka din webbplats. Genom att klicka p� pilen bredvid varje post kan du visa versioner av varje enskild plattform, exempelvis Windows 98 eller FreeBSD.<P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/217.html\">klicka h�r</A>.");

parent.ssLoad(90,"Vanligaste kombination: Denna rapport kombinerar webbl�sar- och plattformsrapporterna och ger en lista �ver de datorkonfigurationer som oftast anv�nds f�r bes�k p� din webbplats, exempelvis Explorer 5/Windows 98 och Mac PPC/Netscape 4. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/218.html\">klicka h�r</A>.");

parent.ssLoad(91,"Ing�ngssidor: Denna rapport visar de vanligaste sidorna som m�nniskor f�rst bes�kt p� din webbplats. Detta �r ofta index.html eller default.html, som �r de vanligaste namnen p� startsidor. �ven sidor som har l�nkats fr�n andra webbplatser eller som �r m�rkta med bokm�rken visas. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/219.html\">klicka h�r</A>.");

parent.ssLoad(92,"Utg�ngssidor: Denna rapport visar de sidor som oftast bes�kts som sista sida innan bes�kare l�mnat din webbplats. Det �r viktigt att granska denna rapport f�r att f� bes�karna att stanna l�ngre p� webbplatsen. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/220.html\">klicka h�r</A>.");

parent.ssLoad(93,"Klicks�kv�g: Denna rapport visar de vanligaste s�kv�garna som bes�kare tagit f�r att komma till din webbplats. S�kv�garna �r sorterade efter den f�rsta sida som bes�ktes. Genom att klicka p� varje post kan du visa efterf�ljande sidor i de s�kv�gar som bes�karna tog. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/221.html\">klicka h�r</A>.");

parent.ssLoad(94,"Bes�ksl�ngd: Denna rapport visar hur l�ng tid bes�karna tillbringat p� din webbsida (genomsnitt). Obs! Tidssegmenten f�r varje diagramdel �kar l�ngs x-axeln. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/223.html\">klicka h�r</A>.");

parent.ssLoad(95,"Bes�ksdjup: Detta diagram visar hur l�ngt bes�karna klickat sig fram p� din webbplats (antalet sidor som bes�ktes visas). Denna rapport �r mycket anv�ndbar n�r du vill utv�rdera hur relevant inneh�llet �r f�r dina bes�kare. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/222.html\">klicka h�r</A>.");

parent.ssLoad(96,"Bes�kare");
parent.ssLoad(97,"Sidor/bes�kare");
parent.ssLoad(98,"Tr�ffar/bes�kare");
parent.ssLoad(99,"Byte/bes�kare");
parent.ssLoad(100,"Tid/bes�kare");
parent.ssLoad(101,"Dollar/bes�kare");

parent.ssLoad(102,"Anv�ndarnamn: Denna rapport visar de vanligaste anv�ndarnamnen som anv�ndes under en verifieringsprocess som din webbsida kr�vde. Om du inte kr�ver ett l�senord visas inga l�senord.  <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/224.html\">klicka h�r</A>.");

parent.ssLoad(103,"Serverrapport");
parent.ssLoad(104,"Platsrankning");
parent.ssLoad(105,"Serverrankning");

parent.ssLoad(106,"Totalt: Denna rapport visar grundl�ggande f�rs�ljningsinformation f�r det valda datumintervallet. Det totala f�rs�ljningsv�rdet visas per bes�kare och dag (genomsnitt). <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/totals.html\">klicka h�r</A>.");

parent.ssLoad(107,"Vanligaste produkter: Denna rapport visar de vanligaste artiklarna som s�lts p� din webbplats, tillsammans med hur stor procent av totalf�rs�ljningen varje artikel motsvarar, samt ett relativt stapeldiagram f�r en snabb, visuell indikation. Tillsammans med varje artikel i listan visas kategorin (om till�mpligt) f�r artikeln. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/topproducts.html\">klicka h�r</A>.");

parent.ssLoad(108,"Produkttr�d: Denna rapport visar de vanligaste kategorierna f�r de artiklar som s�ljs. Klicka p� den lilla bl� pilen bredvid varje post n�r du vill visa underkategorier (om till�mpligt) och sj�lva artiklarna. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/producttree.html\">klicka h�r</A>.");

parent.ssLoad(109,"Regioner: Denna rapport visar de vanligaste regionerna som k�parna p� din webbplats kommer fr�n. Klicka p� den lilla bl� pilen bredvid varje post n�r du vill visa underregioner. Bredvid varje post visas den totala summan (dollar) som regionen motsvarar samt ett stapeldiagram som visar den relativa betydelsen m�tt i f�rs�ljning per region. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/regions.html\">klicka h�r</A>.");
parent.ssLoad(110,"Bes�ksl�ngd");
parent.ssLoad(111,"Bes�ksl�ngd: Denna rapport visar hur l�ng tid bes�karna tillbringat p� din webbsida (genomsnitt). Obs! Tidssegmenten f�r varje diagramdel �kar l�ngs x-axeln. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/223.html\">klicka h�r</A>.");
parent.ssLoad(112,"Totalt antal bes�kare");
parent.ssLoad(113,"Totalt antal sidvyer");
parent.ssLoad(114,"Totalt antal tr�ffar");
parent.ssLoad(115,"Total antal �verf�rda byte");
parent.ssLoad(116,"Bes�kare per dag (i genomsnitt)");
parent.ssLoad(117,"Sidvyer per dag (i genomsnitt)");
parent.ssLoad(118,"Tr�ffar per dag (i genomsnitt)");
parent.ssLoad(119,"Byte �verf�rda per dag (i genomsnitt)");
parent.ssLoad(120,"Sidvyer per bes�kare (i genomsnitt)");
parent.ssLoad(121,"Tr�ffar per bes�kare (i genomsnitt)");
parent.ssLoad(122,"Byte per bes�kare (i genomsnitt)");
parent.ssLoad(123,"Bes�ksl�ngd (i genomsnitt)");
parent.ssLoad(124,"Totalt");
parent.ssLoad(125,"Genomsnitt/dag");
parent.ssLoad(126,"Genomsnitt per timme");
parent.ssLoad(128,"Genomsnitt per m�nad");
parent.ssLoad(129,"System");
parent.ssLoad(130,"Vanligaste webbplatser");
parent.ssLoad(131,"Vanligaste webbplatser: I denna tabell visas webbplatserna p� din server i rangordning.");
parent.ssLoad(132,"Vanligaste servrar ");
parent.ssLoad(133,"Vanligaste servrar: I denna tabell rankas anv�nda servrar i lastbalansering <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/server.html\">klicka h�r</A>.");

parent.ssLoad(134,"Vanligaste butiker");
parent.ssLoad(135,"Vanligaste butiker: Om du har fler butiker i e-handelssystemet visas de i denna rapport efter dollar och order. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/topstores.html\">klicka h�r</A>.");
parent.ssLoad(136,"Totalsumma");
parent.ssLoad(137,"Dollar per dag (genomsnitt)");
parent.ssLoad(138,"Dollar per bes�kare (genomsnitt)");
parent.ssLoad(139,"Skickade formul�r");
parent.ssLoad(140,"Skickade formul�r: I denna rapport visas en lista med de formul�r som anv�nds oftast p� din webbsida. Egentligen �r det formul�rhanterare som anges, t ex CGI-skript. Endast de formul�rhanterare som anv�nder POST-metoden finns med i listan. <P>Om du vill ha mer information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/postedforms.html\">klicka h�r</A>.");
parent.ssLoad(141,"Januari");
parent.ssLoad(142,"Februari");
parent.ssLoad(143,"Mars");
parent.ssLoad(144,"April");
parent.ssLoad(145,"Maj");
parent.ssLoad(146,"Juni");
parent.ssLoad(147,"Juli");
parent.ssLoad(148,"Augusti");
parent.ssLoad(149,"September");
parent.ssLoad(150,"Oktober");
parent.ssLoad(151,"November");
parent.ssLoad(152,"December");
parent.ssLoad(153,"Fr�n");
parent.ssLoad(154,"Till");
parent.ssLoad(155,"M�n");
parent.ssLoad(156,"Tis");
parent.ssLoad(157,"Ons");
parent.ssLoad(158,"Tor");
parent.ssLoad(159,"Fre");
parent.ssLoad(160,"L�r");
parent.ssLoad(161,"S�n");
parent.ssLoad(162,"Jan");
parent.ssLoad(163,"Feb");
parent.ssLoad(164,"Mar");
parent.ssLoad(165,"Apr");
parent.ssLoad(166,"Maj");
parent.ssLoad(167,"Jun");
parent.ssLoad(168,"Jul");
parent.ssLoad(169,"Aug");
parent.ssLoad(170,"Sep");
parent.ssLoad(171,"Okt");
parent.ssLoad(172,"Nov");
parent.ssLoad(173,"Dec");
parent.ssLoad(174,"sek");
parent.ssLoad(175,"sidor");
parent.ssLoad(176,"min");
parent.ssLoad(177,"Rapportinst�llningar i");
parent.ssLoad(178,"Serienummer");
parent.ssLoad(179,"Licenskod");
parent.ssLoad(180,"Spr�k");
parent.ssLoad(181,"Anv�nd inst�llningarna");
parent.ssLoad(182,"kinesiska") 
parent.ssLoad(183,"engelska") 
parent.ssLoad(184,"franska") 
parent.ssLoad(185,"tyska") 
parent.ssLoad(186,"italienska") 
parent.ssLoad(187,"japanska") 
parent.ssLoad(188,"koreanska") 
parent.ssLoad(189,"portugisiska") 
parent.ssLoad(190,"spanska") 
parent.ssLoad(191,"svenska") 
parent.ssLoad(192,"200: OK");
parent.ssLoad(193,"201: Created");
parent.ssLoad(194,"202: Accepted");
parent.ssLoad(195,"203: Non-Authorative Information");
parent.ssLoad(196,"204: No Content");
parent.ssLoad(197,"205: Reset Content");
parent.ssLoad(198,"206: Partial Content");

parent.ssLoad(199,"300: Multiple Choices");
parent.ssLoad(200,"301: Moved Permanently");
parent.ssLoad(201,"302: Found");
parent.ssLoad(202,"303: See Other");
parent.ssLoad(203,"304: Not Modified");
parent.ssLoad(204,"305: Use Proxy");

parent.ssLoad(205,"400: Bad Request");
parent.ssLoad(206,"401: Authorization Required");
parent.ssLoad(207,"402: Payment Required");
parent.ssLoad(208,"403: Forbidden");
parent.ssLoad(209,"404: Not Found");
parent.ssLoad(210,"405: Method Not Allowed");
parent.ssLoad(211,"406: Not Acceptable (encoding)");
parent.ssLoad(212,"407: Proxy Authentication Required");
parent.ssLoad(213,"408: Request Timed Out");
parent.ssLoad(214,"409: Conflicting Request");
parent.ssLoad(215,"410: Gone");
parent.ssLoad(216,"411: Content Length Required");
parent.ssLoad(217,"412: Precondition Failed");
parent.ssLoad(218,"413: Request Entity Too Long");
parent.ssLoad(219,"414: Request URI Too Long");
parent.ssLoad(220,"415: Unsupported Media Type");
parent.ssLoad(221,"416: Requested Range Not Satisfiable");
parent.ssLoad(222,"417: Expectation Failed");

parent.ssLoad(223,"500: Internal Server Error");
parent.ssLoad(224,"501: Not Implemented");
parent.ssLoad(225,"502: Bad Gateway");
parent.ssLoad(226,"503: Service Unavailable");
parent.ssLoad(227,"504: Gateway Timeout");
parent.ssLoad(228,"505: HTTP Version Not Supported");

parent.ssLoad(229,"Click Path From");
parent.ssLoad(230,"Click Through Page");
parent.ssLoad(231,"Clicks");
parent.ssLoad(232,"The Click Paths shows how people navigated through your site. From any one page, this chart shows how many times people clicked on the various links in the page. To see where people went next, click on a link of a particular page.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/221.html\">click here</A>.");
parent.ssLoad(233,"Date Range");
parent.ssLoad(234,"Help Information");
parent.ssLoad(235,"Percent");
