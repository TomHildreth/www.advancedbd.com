parent.ssLoad( 0,"Rapport du site");
parent.ssLoad( 1,"Trafic");
parent.ssLoad( 2,"Instantan�");
parent.ssLoad( 3,"Graphique heure");
parent.ssLoad( 4,"Graphique jour");
parent.ssLoad( 5,"Graphique mois");
parent.ssLoad( 6,"Pages");
parent.ssLoad( 7,"Meilleures pages");
parent.ssLoad( 8,"Arbre r�pertoire");
parent.ssLoad( 9,"Types fichiers");
parent.ssLoad(10,"�tats/erreurs");
parent.ssLoad(11,"R�f�rences");
parent.ssLoad(12,"Meilleures r�f�rences");
parent.ssLoad(13,"Meilleures cl�s");
parent.ssLoad(14,"Arbre de r�f�rences");
parent.ssLoad(15,"Arbre de cl�s");
parent.ssLoad(16,"Moteurs de recherche");
parent.ssLoad(17,"Domaines");
parent.ssLoad(18,"Meilleurs domaines");
parent.ssLoad(19,"Arbre domaines");
parent.ssLoad(20,"Meilleurs pays");
parent.ssLoad(21,"Meilleurs ISP");
parent.ssLoad(22,"Explorateurs");
parent.ssLoad(23,"Arbre d'explorateurs");
parent.ssLoad(24,"Arbre de plates-formes");
parent.ssLoad(25,"Meilleures combinaisons");
parent.ssLoad(26,"Suivi");
parent.ssLoad(27,"Meilleures entr�es");
parent.ssLoad(28,"Meilleures sorties");
parent.ssLoad(29,"Cliquage de recherche");
parent.ssLoad(30,"Profondeur de la visite");
parent.ssLoad(31,"Commerce �lectronique");
parent.ssLoad(32,"Totaux");
parent.ssLoad(33,"Meilleurs produits");
parent.ssLoad(34,"Arbre produits");
parent.ssLoad(35,"R�gions");
parent.ssLoad(36,"P�riode");
parent.ssLoad(37,"Jour");
parent.ssLoad(38,"Semaine");
parent.ssLoad(39,"Mois");
parent.ssLoad(40,"Ann�e");
parent.ssLoad(41,"Entrer p�riode");
parent.ssLoad(42,"Commandes");
parent.ssLoad(43,"Pr�f�rences");
parent.ssLoad(44,"Export donn�es");
parent.ssLoad(45,"Inversion");
parent.ssLoad(46,"Aide");
parent.ssLoad(47,"R�sum�");
parent.ssLoad(48,"Moyenne quotidienne");
parent.ssLoad(49,"Changement");
parent.ssLoad(50,"Noms d'utilisateurs");
parent.ssLoad(51,"Visiteurs");
parent.ssLoad(52,"Acc�s pages");
parent.ssLoad(53,"Succ�s");
parent.ssLoad(54,"Octets");
parent.ssLoad(55,"Heure");
parent.ssLoad(56,"Somme");
parent.ssLoad(57,"Totaux");
parent.ssLoad(58,"Par visiteur");
parent.ssLoad(59,"Rapport");
parent.ssLoad(60,"Vue par");
parent.ssLoad(61,"Rapport pour");
parent.ssLoad(62,"Nbr. Affich�");
parent.ssLoad(63,"Pr�c�dent");
parent.ssLoad(64,"Pourcentage");
parent.ssLoad(65,"Suivant");
parent.ssLoad(66,"Info aide");

parent.ssLoad(67,"<B>! Non licenci� :</B> Cette fonction de rapport requiert une licence Urchin.  Des licences de domaine pour sites individuels sont offertes en ligne pour 199 USD. Pour licencier ce site et activer imm�diatement tous les rapports, cliquez sur  <A CLASS=normal HREF=\"javascript:parent.getLicense();\">ici</A>.");

parent.ssLoad(68,"Rapport d�sactiv�");
parent.ssLoad(69,"de");

parent.ssLoad(70,"Instantan� : un instantan� est un coup d'oeil rapide aux r�centes activit�s du site Web. Les �l�ments du graphique � barres repr�sentent les visiteurs par d�faut. Les s�lections d'indication des �l�ments de ce graphique sont Acc�s pages, Succ�s ou Octets transf�r�s (largeur de bande). Si le module e-Urchin e-commerce est install�, un onglet Somme est �galement affich�, permettant de voir les informations de ce rapport, ainsi que de la plupart des autres, en ce qui concerne les sommes d�pens�es sur votre site Web.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/201.html\">cliquez ici</A>.");

parent.ssLoad(71,"R�sum� : le r�sum� est une simple repr�sentation num�rique du trafic du site pour la p�riode en cours. Les sections sont : Totaux, Moyennes et Moyennes par visiteur. Conseil : pour comparer ces informations � celles d'une autre p�riode, ouvrez une nouvelle fen�tre d'explorateur, acc�dez au rapport et entrez une nouvelle p�riode.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/202.html\">cliquez ici</A>.");

parent.ssLoad(72,"Graphique heure : ce graphique montre le trafic du site pour une heure de la journ�e. Il indique le nombre total de visiteurs pour le mois entier. Les s�lections d'indication des �l�ments de ce graphique sont Acc�s pages, Succ�s ou Octets transf�r�s (largeur de bande). <P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/203.html\">cliquez ici</A>.");

parent.ssLoad(73,"Graphique jour : ce graphique montre le trafic par jour du site pour la p�riode sp�cifi�e. La fonction P�riode permet de choisir une diff�rente p�riode. Les �l�ments du graphique � barres repr�sentent les visiteurs par d�faut. Les s�lections d'indication des �l�ments de ce graphique sont Acc�s pages, Succ�s ou Octets transf�r�s (largeur de bande). <P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/204.html\">cliquez ici</A>.");

parent.ssLoad(74,"Graphique mois : ce graphique indique le trafic du site pour chacun des 12 derniers mois. Si le site est en exploitation depuis moins d'un an, le rapport montre les mois pour lesquels des informations sont disponibles. Les �l�ments du graphique � barres repr�sentent les visiteurs par d�faut. Les s�lections d'indication des �l�ments de ce graphique sont Acc�s pages, Succ�s et Octets transf�r�s (largeur de bande).<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/205.html\">cliquez ici</A>.");

parent.ssLoad(75,"Meilleures pages : ce rapport montre les 10 pages les plus fr�quemment visit�es du site et indique le pourcentage relatif de chacune. Le nombre de pages montr�es dans ce rapport peut �tre modifi� en changeant la valeur dans le champ Nbr. Affich�.  <P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/206.html\">cliquez ici</A>.");

parent.ssLoad(76,"Arbre r�pert : ce rapport montre chacun des r�pertoires (parfois appel�s dossiers) du site et les pages qui ont �t� visit�es. Pour voir ces pages, il suffit de cliquer sur la petite fl�che se trouvant � c�t� de chaque entr�e, ce qui agrandit le menu. Le nombre de r�pertoires montr�s dans ce rapport peut �tre modifi� en changeant la valeur dans le champ Nbr. Affich�. <P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/207.html\">cliquez ici</A>.");

parent.ssLoad(77,"Types fichier : ce rapport montre le type de fichiers qui ont �t� visit�s sur le site, tels qu'images GIF, fichiers HTML ou scripts CGI. Ce rapport est int�ressant en ce sens qu'il permet de comparer le nombres de succ�s (demandes de serveur) au nombre d'octets afin de voir quels types de fichiers utilisent le plus de ressources du r�seau. Le nombre de fichiers montr�s dans ce rapport peut �tre modifi� en changeant la valeur dans le champ Nbr. Affich�. <P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/208.html\">cliquez ici</A>.");

parent.ssLoad(78,"�tat/erreurs : ce rapport montre le code d'�tat de chaque r�ponse. Les 400 repr�sentent les erreurs, y compris les fichiers pas trouv�s. Cliquez sur la petite fl�che pour obtenir plus de d�tails sur les erreurs.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/1204.html\">cliquez ici</A>.");

parent.ssLoad(79,"Meilleures r�f : ce rapport fournit la liste des adresses r�elles (URL) des pages Web reli�es � votre site qui ont �t� cliqu�es. Cette liste comprendra  probablement des moteurs de recherche et autres sites de r�pertoires. Le nombre de r�f�rences montr�es dans ce rapport peut �tre contr�l� en modifiant la valeur dans le champ Nbr. Affich�.  <P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/209.html\">cliquez ici</A>.");

parent.ssLoad(80,"Meilleures cl�s : ce rapport fournit la liste des mots cl�s entr�s dans les moteurs de recherche pour trouver le site. Ce rapport aide � d�terminer si les mots cl�s choisis ont rempli la fonction d'attirer des clients sur votre site.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/211.html\">cliquez ici</A>.");

parent.ssLoad(81,"Arbre r�f : ce rapport fournit la liste des domaines qui ont le plus attir� de clients sur votre site. Cliquez sur la petite fl�che bleue � c�t� de chaque domaine pour afficher les pages contenant les liaisons sur lesquelles les clients ont cliqu�.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/210.html\">cliquez ici</A>.");

parent.ssLoad(82,"Arbre de cl�s : ce tr�s utile rapport fournit la liste des moteurs de recherche les plus utilis�s pour trouver votre site. Cliquez sur la petite fl�che situ�e � c�t� de chaque entr�e pour voit les mots cl�s ayant permis de trouver votre site. Le nombre d'entr�es montr�es dans ce rapport peut �tre chang� en entrant une nouvelle valeur dans le champ \"Nbr. Affich�\" et en appuyant sur la touche d'entr�e du clavier. Les s�lections d'indication des �l�ments de ce graphique sont Visiteurs, Acc�s pages, Succ�s, Octets transf�r�s (largeur de bande) et Heure.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/212.html\">cliquez ici</A>.");

parent.ssLoad(83,"Moteurs rech : ce rapport fournit la liste de tous les moteurs de recherche ayant permis d'aboutir � votre site. En cliquant sur la petite fl�che bleue situ�e � c�t� de chaque moteur, vous pouvez voir les mots cl�s qui ont �t� entr�s. Pour un webmestre, ceci est l'un des rapports Urchin les plus utiles. Il indique avec pr�cision si votre site est correctement inscrit sur les moteurs de recherche et quels mots cl�s attirent des clients. Ceci peut �tre tr�s utile si le site a �t� r�cemment inscrit ou modifi�.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/212.html\">cliquez ici</A>.");

parent.ssLoad(84,"Meilleurs domaines : ce rapport pratique montre de quels r�seaux viennent les visiteurs de votre site. Bien qu'Urchin puisse r�soudre la plupart des r�seaux, certains ne pourront jamais �tre r�solus, ce qui signifie que le r�seau ne peut pas �tre identifi�. Cette information est essentielle pour la personnalisation de votre site Web, car il se peut que la validation des explorateurs de certains visiteurs soit diff�rente.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/213.html\">cliquez ici</A>.");

parent.ssLoad(85,"Arbre domaines : ce rapport fournit la liste des meilleurs domaines tels que .com et .net dont  viennent les visiteurs de votre site.  Cliquez sur la petite fl�che situ�e � c�t� de chaque entr�e pour afficher les noms de r�seaux au-dessous de chaque domaine principal.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/214.html\">cliquez ici</A>.");

parent.ssLoad(86,"Meilleurs pays : Ce rapport fournit la liste des pays ayant le plus acc�d� � votre site. Les domaines principalement U.S. (com, net et org) et les domaines exclusivement U.S. (edu, gov et mil) sont inclus.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/215.html\">cliquez ici</A>.");

parent.ssLoad(87,"Meilleurs ISP : ce rapport fournit la liste des meilleurs ISP <B>principaux</B> tels que earthlink.net, dont les clients ont visit� votre site. Le nombre d'entr�es montr�es par ce rapport peut �tre chang� en entrant une nouvelle valeur dans le champ \"Nbr. Affich�\" et en appuyant sur la touche d'entr�e du clavier. Les s�lections d'indication des �l�ments de ce graphique sont Visiteurs, Acc�s pages, Succ�s, Octets transf�r�s (largeur de bande) et Heure.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/topisps.html\">cliquez ici</A>.");

parent.ssLoad(88,"Arbre explor : ce rapport fournit la liste des meilleurs explorateurs, tels que Netscape Navigator et Microsoft Internet Explorer, utilis�s pour visiter votre site. Il montre �galement des robots, tels que ceux utilis�s par les moteurs de recherche pour trouver le contenu des sites Web et d'autres types de programmes Internet automatis�s. Cliquez sur la fl�che situ�e � c�t� de chaque entr�e pour afficher la version de chaque explorateur ou agent.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/216.html\">cliquez ici</A>.");

parent.ssLoad(89,"Arbre plt-forme : ce rapport fournit la liste des principales plates-formes informatiques telles que Windows, Macintosh et Unix, utilis�es pour visiter votre site. Cliquez sur la fl�che situ�e � c�t� de chaque entr�e pour  afficher la version de chaque plate-forme utilis�e, telle que Windows 98 ou FreeBSD.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/217.html\">cliquez ici</A>.");

parent.ssLoad(90,"Meilleures comb : ce rapport combine les rapports d'explorateurs et de plates-formes pour fournir une liste des configurations les plus fr�quemment utilis�es pour visiter votre site, par exemple : Explorer 5/Windows 98 et Mac PPC/Netscape 4. <P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/218.html\">cliquez ici</A>.");

parent.ssLoad(91,"Top Entrances: This report lists the top pages people first arrived at within your site. This will usually be something like index.html or default.html, which are the most common home page names. Tici will also be pages listed that may have been linked from other sites or bookmarked for quick access. <P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/219.html\">cliquez ici</A>.");

parent.ssLoad(92,"Meilleures sort : ce rapport fournit une liste des pages les plus fr�quemment visit�es en dernier avant de quitter votre site. Il est important d'�tudier ce rapport afin d'am�liorer la r�tention ou la pers�v�rance des visiteurs.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/220.html\">cliquez ici</A>.");

parent.ssLoad(93,"Cliquage rech : ce rapport fournit une liste des voies d'acc�s les plus utilis�es pour explorer votre site, avec la page initiale en premier. Il suffit de cliquer sur chaque entr�e pour afficher les pages suivantes des voies emprunt�es par vos visiteurs.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/221.html\">cliquez ici</A>.");

parent.ssLoad(94,"Dur�e visite : ce rapport indique la dur�e moyenne des visites de votre site. Remarque : les segments de dur�e pour chaque �l�ment de graphique augmentent selon l'axe \" x \".<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/223.html\">cliquez ici</A>.");

parent.ssLoad(95,"Profondeur : ce graphique illustre la profondeur des visites, indiqu�e par le nombre de pages. Ce rapport est tr�s utile pour d�terminer � quel point le contenu de votre site est adapt� aux visiteurs.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/222.html\">cliquez ici</A>.");

parent.ssLoad(96,"Visiteurs");
parent.ssLoad(97,"Pages/visiteur");
parent.ssLoad(98,"Succ�s/visiteur");
parent.ssLoad(99,"Octets/visiteur");
parent.ssLoad(100,"Dur�e/visiteur");
parent.ssLoad(101,"Somme/visiteur");

parent.ssLoad(102,"Noms util : ce rapport fournit une liste des noms d'utilisateurs utilis�s lors de tout processus d'identification requis par votre site. Si vous n'exigez pas de mot de passe, aucun nom d'utilisateur n'est indiqu�.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/224.html\">cliquez ici</A>.");

parent.ssLoad(103,"Rapport serveur");
parent.ssLoad(104,"Classement site");
parent.ssLoad(105,"Classement des serveurs");

parent.ssLoad(106,"Totaux : Ce rapport fournit les informations de ventes de base pour la p�riode s�lectionn�e. La valeur totale des ventes est indiqu�e avec la moyenne par visiteur et par jour.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/totals.html\">cliquez ici</A>.");

parent.ssLoad(107,"Meilleurs prod : ce rapport fournit la liste des articles les plus vendus sur votre site Web, ainsi que le pourcentage du total que repr�sente chaque vente, avec un graphique � barres connexe permettant une visualisation rapide. Chacun des articles de la liste est accompagn� du nom de la cat�gorie � laquelle il appartient (le cas �ch�ant).<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/topproducts.html\">cliquez ici</A>.");

parent.ssLoad(108,"Arbre produits : ce rapport fournit la liste des cat�gories de produits les plus vendues. Le nom de chaque article est suivi d'une petite fl�che bleue sur laquelle vous pouvez cliquer pour afficher les sous-cat�gories (le cas �ch�ant) et les articles proprement dits.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/producttree.html\">cliquez ici</A>.");

parent.ssLoad(109,"R�gions : ce rapport fournit la liste des  principales r�gions d'origine des visiteurs de votre site. Cliquez sur la petite fl�che bleue accompagnant chaque entr�e pour afficher les sous-r�gions. Chaque entr�e est suivie du montant de vente qu'elle repr�sente et d'un graphique � barres indiquant l'importance relative des ventes de chaque r�gion.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/regions.html\">cliquez ici</A>.");
parent.ssLoad(110,"Dur�e visite");
parent.ssLoad(111,"Dur�e visite : ce rapport indique la dur�e moyenne des visites de votre site. Remarque : les segments de dur�e pour chaque �l�ment de graphique augmentent selon l'axe \" x \".<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/223.html\">cliquez ici</A>.");
parent.ssLoad(112,"Total de visiteurs");
parent.ssLoad(113,"Total d'acc�s de page");
parent.ssLoad(114,"Total de succ�s");
parent.ssLoad(115,"Total d'octets transf�r�s");
parent.ssLoad(116,"Nombre moyen de visiteurs par jour");
parent.ssLoad(117,"Nombre moyen d'acc�s pages par jour");
parent.ssLoad(118,"Nombre moyen de succ�s par jour");
parent.ssLoad(119,"Nombre moyen d'octets transf�r�s par jour");
parent.ssLoad(120,"Nombre moyen d'acc�s pages par visiteur");
parent.ssLoad(121,"Nombre moyen de succ�s par visiteur");
parent.ssLoad(122,"Nombre moyen d'octets par visiteur");
parent.ssLoad(123,"Dur�e moyenne des visites");
parent.ssLoad(124,"Total de la p�riode");
parent.ssLoad(125,"Moyenne quotidienne");
parent.ssLoad(126,"Moyenne horaire");
parent.ssLoad(128,"Moyenne mensuelle");
parent.ssLoad(129,"Syst�me");
parent.ssLoad(130,"Meilleurs sites");
parent.ssLoad(131,"Meilleurs sites : ce tableau classe les sites Web de votre serveur.");
parent.ssLoad(132,"Meilleurs serveurs");
parent.ssLoad(133,"Meilleurs serveurs: ce tableau classe les serveurs utilis�s pour �quilibrer la charge.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/server.html\">cliquez ici</A>.");

parent.ssLoad(134,"Meilleurs magasins");
parent.ssLoad(135,"Meilleurs magasins : si votre syst�me de commerce �lectronique comprend plusieurs magasins, ce rapport en donne le classement par montants de ventes et commandes.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/topstores.html\">cliquez ici</A>.");
parent.ssLoad(136,"Montant total");
parent.ssLoad(137,"Montant moyen par jour");
parent.ssLoad(138,"Montant moyen par visiteur");
parent.ssLoad(139,"Formulaires publi�s");
parent.ssLoad(140,"Formulaires publi�s : ce rapport pr�sente une liste des formulaires les plus utilis�s sur votre site. La liste indique les gestionnaires de formulaires tels que les scripts CGI. Seuls les gestionnaires utilisant la m�thode POST sont indiqu�s.<P>Pour plus de d�tails, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/fr30/postedforms.html\">cliquez ici</A>.");
parent.ssLoad(141,"Janvier");
parent.ssLoad(142,"F�vrier");
parent.ssLoad(143,"Mars");
parent.ssLoad(144,"Avril");
parent.ssLoad(145,"Mai");
parent.ssLoad(146,"Juin");
parent.ssLoad(147,"Juillet");
parent.ssLoad(148,"Ao�t");
parent.ssLoad(149,"Septembre");
parent.ssLoad(150,"Octobre");
parent.ssLoad(151,"Novembre");
parent.ssLoad(152,"D�cembre");
parent.ssLoad(153,"du")
parent.ssLoad(154,"au")
parent.ssLoad(155,"Lun")
parent.ssLoad(156,"Mar")
parent.ssLoad(157,"Mer")
parent.ssLoad(158,"Jeu")
parent.ssLoad(159,"Ven")
parent.ssLoad(160,"Sam")
parent.ssLoad(161,"Dim")
parent.ssLoad(162,"Jan");
parent.ssLoad(163,"F�v");
parent.ssLoad(164,"Mar");
parent.ssLoad(165,"Avr");
parent.ssLoad(166,"Mai");
parent.ssLoad(167,"Juin");
parent.ssLoad(168,"Juil");
parent.ssLoad(169,"Ao�t");
parent.ssLoad(170,"Sept");
parent.ssLoad(171,"Oct");
parent.ssLoad(172,"Nov");
parent.ssLoad(173,"D�c");
parent.ssLoad(174,"sec");
parent.ssLoad(175,"pages");
parent.ssLoad(176,"min");
parent.ssLoad(177,"Prifirences de rapport pour");
parent.ssLoad(178,"Numiro de sirie");
parent.ssLoad(179,"Code de licence");
parent.ssLoad(180,"Langue");
parent.ssLoad(181,"Utiliser les prifirences");
parent.ssLoad(182,"chinois") 
parent.ssLoad(183,"anglais") 
parent.ssLoad(184,"fran�ais") 
parent.ssLoad(185,"allemands") 
parent.ssLoad(186,"italiens") 
parent.ssLoad(187,"japonais") 
parent.ssLoad(188,"cor�ens") 
parent.ssLoad(189,"portugese") 
parent.ssLoad(190,"espagnols") 
parent.ssLoad(191,"les su�dois") 

parent.ssLoad(192,"200: OK");
parent.ssLoad(193,"201: Created");
parent.ssLoad(194,"202: Accepted");
parent.ssLoad(195,"203: Non-Authorative Information");
parent.ssLoad(196,"204: No Content");
parent.ssLoad(197,"205: Reset Content");
parent.ssLoad(198,"206: Partial Content");

parent.ssLoad(199,"300: Multiple Choices");
parent.ssLoad(200,"301: Moved Permanently");
parent.ssLoad(201,"302: Found");
parent.ssLoad(202,"303: See Other");
parent.ssLoad(203,"304: Not Modified");
parent.ssLoad(204,"305: Use Proxy");

parent.ssLoad(205,"400: Bad Request");
parent.ssLoad(206,"401: Authorization Required");
parent.ssLoad(207,"402: Payment Required");
parent.ssLoad(208,"403: Forbidden");
parent.ssLoad(209,"404: Not Found");
parent.ssLoad(210,"405: Method Not Allowed");
parent.ssLoad(211,"406: Not Acceptable (encoding)");
parent.ssLoad(212,"407: Proxy Authentication Required");
parent.ssLoad(213,"408: Request Timed Out");
parent.ssLoad(214,"409: Conflicting Request");
parent.ssLoad(215,"410: Gone");
parent.ssLoad(216,"411: Content Length Required");
parent.ssLoad(217,"412: Precondition Failed");
parent.ssLoad(218,"413: Request Entity Too Long");
parent.ssLoad(219,"414: Request URI Too Long");
parent.ssLoad(220,"415: Unsupported Media Type");
parent.ssLoad(221,"416: Requested Range Not Satisfiable");
parent.ssLoad(222,"417: Expectation Failed");

parent.ssLoad(223,"500: Internal Server Error");
parent.ssLoad(224,"501: Not Implemented");
parent.ssLoad(225,"502: Bad Gateway");
parent.ssLoad(226,"503: Service Unavailable");
parent.ssLoad(227,"504: Gateway Timeout");
parent.ssLoad(228,"505: HTTP Version Not Supported");

parent.ssLoad(229,"Click Path From");
parent.ssLoad(230,"Click Through Page");
parent.ssLoad(231,"Clicks");
parent.ssLoad(232,"The Click Paths shows how people navigated through your site. From any one page, this chart shows how many times people clicked on the various links in the page. To see where people went next, click on a link of a particular page.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/221.html\">click here</A>.");
parent.ssLoad(233,"Date Range");
parent.ssLoad(234,"Help Information");
parent.ssLoad(235,"Percent");
