parent.ssLoad( 0,"Rapporto sito");
parent.ssLoad( 1,"Traffico");
parent.ssLoad( 2,"Istantanea");
parent.ssLoad( 3,"Grafico orario");
parent.ssLoad( 4,"Grafico quotidiano");
parent.ssLoad( 5,"Grafico mensile");
parent.ssLoad( 6,"Pagine");
parent.ssLoad( 7,"Pagine principali");
parent.ssLoad( 8,"Albero directory");
parent.ssLoad( 9,"Tipi di file");
parent.ssLoad(10,"Stato/Errori");
parent.ssLoad(11,"Riferimenti");
parent.ssLoad(12,"Riferimenti principali");
parent.ssLoad(13,"Parole chiave principali");
parent.ssLoad(14,"Albero dei riferimenti");
parent.ssLoad(15,"Albero delle parole chiave");
parent.ssLoad(16,"Sistemi ricerca");
parent.ssLoad(17,"Domini");
parent.ssLoad(18,"Domini principali");
parent.ssLoad(19,"Albero domini");
parent.ssLoad(20,"Paesi principali");
parent.ssLoad(21,"ISP principali");
parent.ssLoad(22,"Browser");
parent.ssLoad(23,"Albero browser");
parent.ssLoad(24,"Albero piattaforme");
parent.ssLoad(25,"Combo principali");
parent.ssLoad(26,"Registrazione");
parent.ssLoad(27,"Entrate principali");
parent.ssLoad(28,"Uscite principali");
parent.ssLoad(29,"Percorsi principali");
parent.ssLoad(30,"Profondit� visita");
parent.ssLoad(31,"E-Commerce");
parent.ssLoad(32,"Totali");
parent.ssLoad(33,"Prodotti principali");
parent.ssLoad(34,"Albero prodotti");
parent.ssLoad(35,"Regioni");
parent.ssLoad(36,"Intervallo date");
parent.ssLoad(37,"Giorno");
parent.ssLoad(38,"Settimana");
parent.ssLoad(39,"Mese");
parent.ssLoad(40,"Anno");
parent.ssLoad(41,"Immettere intervallo");
parent.ssLoad(42,"Comandi");
parent.ssLoad(43,"Preferenze");
parent.ssLoad(44,"Dati di esportazione");
parent.ssLoad(45,"Inverti");
parent.ssLoad(46,"?");
parent.ssLoad(47,"Riassunto");
parent.ssLoad(48,"Media quotidiana");
parent.ssLoad(49,"Modifica");
parent.ssLoad(50,"Nomi utente");
parent.ssLoad(51,"Visitatori");
parent.ssLoad(52,"Visualizzazione pagine");
parent.ssLoad(53,"Risultati positivi");
parent.ssLoad(54,"Byte");
parent.ssLoad(55,"Tempo");
parent.ssLoad(56,"Dollari");
parent.ssLoad(57,"Totali");
parent.ssLoad(58,"Per visitatore");
parent.ssLoad(59,"Rapporto");
parent.ssLoad(60,"Visualizzazione per");
parent.ssLoad(61,"Rapporto sito per");
parent.ssLoad(62,"N. Mostrato");
parent.ssLoad(63,"Precedente");
parent.ssLoad(64,"Percentuale");
parent.ssLoad(65,"Successivo");
parent.ssLoad(66,"Inf. sulla Guida");
parent.ssLoad(67,"<B>! Senza licenza:</B> questa funzione di rapporto richiede una licenza Urchin. Le licenze basate sul dominio sono disponibili in linea al prezzo di 199 dollari. Per assegnare una licenza a questo sito e attivare tutti i rapporti ora, fare clic <A CLASS=normal HREF=\"javascript:parent.getLicense();\">qui</A>.");
parent.ssLoad(68,"Rapporto disabilitato");
parent.ssLoad(69,"di");

parent.ssLoad(70,"Istantanea: l'istantanea � una vista rapida dell'attivit� recente sul sito Web. Per impostazione predefinita gli elementi dell'istogramma rappresentano i visitatori e possono essere commutati a Visualizzazioni delle pagine, Risultati positivi o Byte trasferiti (ampiezza di banda). Se � installato il modulo di e-commerce e-Urchin, � visualizzata anche una scheda Dollari, che consente di visualizzare queste informazioni e la maggior parte delle informazioni di altri rapporti in termini di dollari effettivamente spesi sul sito. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/201.html\">fare clic qui</A>.");

parent.ssLoad(71,"Riassunto: il rapporto Riassunto � un semplice conteggio numerico del traffico verso il sito per l'intervallo attuale di date. Alcune delle sezioni sono Totali, Medie e Medie per visitatore. Suggerimento: per confrontare questi dati con un altro intervallo di tempo, aprire una nuova finestra del browser, passare al rapporto e immettere un nuovo intervallo di date. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/202.html\">fare clic qui</A>.");

parent.ssLoad(72,"Grafico orario: questo grafico mostra il traffico verso il sito, in base all'ora del giorno. Il grafico riporta l'attivit� di un intero mese, in termini di visitatori. Gli elementi dell'istogramma possono essere commutati a Visualizzazioni delle pagine, Risultati positivi o Byte trasferiti (ampiezza di banda). <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/203.html\">fare clic qui</A>.");

parent.ssLoad(73,"Grafico quotidiano: questo grafico mostra il traffico quotidiano verso il sito fino al periodo di tempo specificato. Utilizzare la funzione di intervallo di date per specificare un intervallo diverso. Per impostazione predefinita gli elementi dell'istogramma rappresentano i visitatori e possono essere commutati a Visualizzazioni delle pagine, Risultati positivi o Byte trasferiti (ampiezza di banda). <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/204.html\">fare clic qui</A>.");

parent.ssLoad(74,"Grafico mensile: questo grafico mostra il traffico verso il sito su base mensile per gli ultimi 12 mesi. Se il sito � operativo da un periodo inferiore, sono riportati i mesi per cui sono disponibili i dati. Per impostazione predefinita gli elementi dell'istogramma rappresentano i visitatori possono essere commutati a Visualizzazioni delle pagine, Risultati positivi o Byte trasferiti (ampiezza di banda). <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/205.html\">fare clic qui</A>.");

parent.ssLoad(75,"Pagine principali: questo rapporto mostra le 10 pagine pi� visitate sul sito e le riporta in forma grafica indicandone la percentuale relativa. Il numero di pagine mostrato su questo rapporto pu� essere controllato modificando il valore nell'area N. Mostrato. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/206.html\">fare clic qui</A>.");

parent.ssLoad(76,"Albero delle directory: questo rapporto mostra ciascuna directory (talvolta denominata cartella) presente nel sito e le pagine a cui si � fatto accesso al suo interno. Per visualizzare tali pagine, espandere il menu facendo clic sulla freccia accanto a ciascuna voce. Il numero di directory mostrato su questo rapporto pu� essere controllato modificando il valore nell'area N. Mostrato. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/207.html\">fare clic qui</A>.");

parent.ssLoad(77,"Tipi di file: questo rapporto mostra i tipi di file a cui � stato richiesto l'accesso sul sito, come ad esempio immagini GIF, file HTML o procedure CGI. � interessante visualizzare questo rapporto in termini di relazione tra risultati positivi (richieste del server) e byte, al fine di osservare quali tipi di file utilizzino la maggior parte delle risorse di rete. Il numero di tipi di file mostrato su questo rapporto pu� essere controllato modificando il valore nell'area N. Mostrato. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/208.html\">fare clic qui</A>.");

parent.ssLoad(78,"Stato/Errori: questo rapporto mostra il codice di stato di ciascuna risposta. I 400 rappresentano errori tra cui file non trovati. Fare clic sulla freccia per visualizzare ulteriori dettagli sugli errori. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/1204.html\">fare clic qui</A>.");

parent.ssLoad(79,"Riferimenti principali: questo rapporto elenca gli indirizzi effettivi (URL) delle pagine Web, contenenti collegamenti al sito, che sono stati selezionati. Probabilmente comprender� i sistemi di ricerca e altri siti di directory. Il numero di riferimenti mostrato su questo rapporto pu� essere controllato modificando il valore nell'area N. Mostrato. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/209.html\">fare clic qui</A>.");

parent.ssLoad(80,"Parole chiave principali: questo rapporto elenca le parole chiave effettive digitate nei sistemi di ricerca per trovare il sito. Questo rapporto contribuisce a valutare se le parole chiave che si prevedeva guidassero i visitatori al sito stiano avendo l'effetto desiderato. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/211.html\">fare clic qui</A>.");

parent.ssLoad(81,"Albero dei riferimenti: questo rapporto elenca i domini principali che hanno portato i visitatori al sito. � possibile fare clic sulla freccia blu accanto a ciascuna voce per visualizzare le pagine effettive contenenti i collegamenti che sono stati selezionati. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/210.html\">fare clic qui</A>.");

parent.ssLoad(82,"Albero delle parole chiave: questo rapporto, molto utile, elenca i sistemi di ricerca principali utilizzati per trovare il sito. Facendo clic sulla freccia accanto a ciascuna voce, � possibile visualizzare le parole chiave effettive utilizzate in questo particolare sistema di ricerca per trovare il sito. Il numero di voci mostrate in questo rapporto pu� essere modificato immettendo un nuovo valore nella casella \"N. Mostrato\" e premendo Invio sulla tastiera. � possibile alternare questo rapporto tra Visitatori, Visualizzazioni delle pagine, Risultati positivi, Byte trasferiti (ampiezza di banda) e Tempo. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/212.html\">fare clic qui</A>.");

parent.ssLoad(83,"Sistemi di ricerca: questo rapporto elenca ciascun sistema di ricerca utilizzato con successo per trovare il sito. Facendo clic sulla freccia blu accanto a ciascuna voce, � possibile visualizzare le parole chiave effettivamente digitate. Per un webmaster, questo � uno dei rapporti pi� utili di Urchin. Mostra precisamente la qualit� della registrazione del sito sui sistemi di ricerca, oltre ad indicare le parole chiave che stanno alimentando il traffico. Pu� essere molto utile per coloro che si sono registrati, o hanno modificato il contenuto del sito, di recente. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/212.html\">fare clic qui</A>.");

parent.ssLoad(84,"Domini principali: questo utile rapporto mostra le reti da cui provengono i visitatori del sito. Urchin � in grado di risolvere la maggior parte delle reti, ma alcune resteranno sempre non risolte, il che significa che non � stato possibile identificare la rete. Queste informazioni sono molto importanti per la struttura del sito Web, in quanto alcuni visitatori potrebbero avere browser con capacit� diverse. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/213.html\">fare clic qui</A>.");

parent.ssLoad(85,"Albero dei domini: questo rapporto elenca i domini di livello principale, come ad esempio .com e .net, da cui provengono i visitatori del sito. Facendo clic sulla freccia accanto a ciascuna voce, � possibile visualizzare le reti effettive sotto ciascun dominio di livello principale. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/214.html\">fare clic qui</A>.");

parent.ssLoad(86,"Paesi principali: questo rapporto elenca i Paesi principali che hanno fatto accesso al sito. Sono inclusi i domini principalmente USA (com, net e org) e i domini esclusivamente USA (edu, gov e mil). <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/215.html\">fare clic qui</A>.");

parent.ssLoad(87,"ISP principali: questo rapporto elenca i principali ISP <B>pi� importanti</B>, quali ad esempio earthlink.net, i cui clienti abbiano visitato il sito. Il numero di voci mostrate in questo rapporto pu� essere modificato immettendo un nuovo valore nella casella \"N. Mostrato\" e premendo Invio sulla tastiera. � possibile alternare questo rapporto tra Visitatori, Visualizzazioni delle pagine, Risultati positivi, Byte trasferiti (ampiezza di banda) e Tempo. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/topisps.html\">fare clic qui</A>.");

parent.ssLoad(88,"Albero dei browser: questo rapporto elenca i browser principali, quali ad esempio Netscape Navigator e Microsoft Internet Explorer, utilizzati per visitare il sito. Si vedranno anche elencati robot, quali quelli utilizzati dai sistemi di ricerca per trovare il contenuto dei siti Web, e altri tipi di programmi automatizzati per Internet. Facendo clic sulla freccia accanto a ciascuna voce, � possibile visualizzare le versioni di ciascun browser o agente particolare. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/216.html\">fare clic qui</A>.");

parent.ssLoad(89,"Albero delle piattaforme: questo rapporto elenca le principali piattaforme di computer, quali ad esempio Windows, Macintosh e Unix, utilizzate per visitare il sito. Facendo clic sulla freccia accanto a ciascuna voce, � possibile visualizzare le versioni di ciascuna piattaforma utilizzata, quali ad esempio Windows 98 o FreeBSD. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/217.html\">fare clic qui</A>.");

parent.ssLoad(90,"Combo principali: questo rapporto combina i rapporti dei browser e delle piattaforme e produce un elenco delle impostazioni dei computer utilizzate pi� di frequente per visualizzare il sito. Alcuni esempi di piattaforme utilizzate sono Explorer 5/Windows 98 e Mac PPC/Netscape 4. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/218.html\">fare clic qui</A>.");

parent.ssLoad(91,"Entrate principali: questo rapporto elenca le pagine principali del sito raggiunte per prime dai visitatori. Di solito saranno del tipo index.html o default.html, che sono i nomi pi� comuni per le pagine iniziali. Saranno riportate anche pagine che potrebbero essere state collegate da altri siti o segnalate per velocizzare l'accesso. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/219.html\">fare clic qui</A>.");

parent.ssLoad(92,"Uscite principali: questo rapporto elenca le pagine visitate con maggiore frequenza per ultime prima che i visitatori lascino il sito. � importante studiare questo rapporto per trovare modalit� migliori di trattenere o \"incollare\" i visitatori. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/220.html\">fare clic qui</A>.");

parent.ssLoad(93,"Percorsi principali: questo rapporto elenca i percorsi principali utilizzati all'interno del sito, ordinati in base alla pagina iniziale visitata. Facendo clic su ciascuna voce, � possibile visualizzare le pagine successive nei percorsi seguiti dai visitatori e cos� via. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/221.html\">fare clic qui</A>.");

parent.ssLoad(94,"Durata della visita: questo rapporto mostra il tempo medio trascorso dai visitatori sul sito. Nota: i segmenti temporali per ciascun elemento grafico aumentano lungo l'asse 'x'. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/223.html\">fare clic qui</A>.");

parent.ssLoad(95,"Profondit�: questo grafico illustra la profondit� alla quale i visitatori hanno visitato il sito, visualizzata per numero di pagine visitate. Questo rapporto � molto utile per la valutazione della pertinenza del contenuto per i visitatori. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/222.html\">fare clic qui</A>.");

parent.ssLoad(96,"Visitatori");
parent.ssLoad(97,"Pagine/visitatore");
parent.ssLoad(98,"Risultati positivi/visitatore");
parent.ssLoad(99,"Byte/visitatore");
parent.ssLoad(100,"Tempo/visitatore");
parent.ssLoad(101,"Dollari/visitatore");

parent.ssLoad(102,"Nomi utente: questo rapporto elenca i principali nomi utente utilizzati durante i processi di autenticazione richiesti dal sito. Se non si richiede una password, non � elencato alcun nome utente. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/224.html\">fare clic qui</A>.");

parent.ssLoad(103,"Rapporto server");
parent.ssLoad(104,"Classificazione dei siti ");
parent.ssLoad(105,"Classificazione dei server ");

parent.ssLoad(106,"Totali: questo rapporto mostra le informazioni di base sulle vendite per l'intervallo di date selezionato. Il valore totale delle vendite � mostrato assieme alle medie per visitatore e per giorno. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/totals.html\">fare clic qui</A>.");

parent.ssLoad(107,"Prodotti principali: questo rapporto elenca gli articoli principali venduti sul sito Web, assieme alla percentuale del totale delle vendite rappresentato da ciascuno, e contiene un istogramma relativo che offre un'indicazione visiva immediata. Oltre a ciascun articolo, nell'elenco � riportata anche l'eventuale categoria ad esso associata. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/topproducts.html\">fare clic qui</A>.");

parent.ssLoad(108,"Albero dei prodotti: questo rapporto elenca le categorie principali degli articoli venduti. Accanto a ciascuna voce � presente una freccia blu su cui � possibile fare clic per visualizzare eventuali sottocategorie e gli articoli stessi. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/producttree.html\">fare clic qui</A>.");

parent.ssLoad(109,"Regioni: questo rapporto elenca le regioni principali di provenienza degli acquirenti del sito. Facendo clic sulla freccia blu accanto a ciascuna voce, � possibile visualizzare le sottoregioni. Accanto a ciascuna voce � riportato il valore totale in dollari rappresentato e un istogramma che indica l'importanza relativa di ciascuna regione in base alle vendite. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/regions.html\">fare clic qui</A>.");
parent.ssLoad(110,"Durata della visita ");
parent.ssLoad(111,"Durata della visita: questo rapporto mostra il tempo medio trascorso dai visitatori sul sito. Nota: i segmenti temporali per ciascun elemento grafico aumentano lungo l'asse 'x'. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/223.html\">fare clic qui</A>.");
parent.ssLoad(112,"Totale visitatori");
parent.ssLoad(113,"Totale visualizzazioni delle pagine");
parent.ssLoad(114,"Totale risultati positivi");
parent.ssLoad(115,"Totale byte trasferiti");
parent.ssLoad(116,"Numero medio di visitatori al giorno");
parent.ssLoad(117,"Numero medio di visualizzazioni delle pagine al giorno");
parent.ssLoad(118,"Numero medio di risultati positivi al giorno");
parent.ssLoad(119,"Numero medio di byte trasferiti al giorno");
parent.ssLoad(120,"Numero medio di visualizzazioni delle pagine per visitatore");
parent.ssLoad(121,"Numero medio di risultati positivi per visitatore");
parent.ssLoad(122,"Numero medio di byte per visitatore");
parent.ssLoad(123,"Durata media della visita");
parent.ssLoad(124,"Intervallo totale");
parent.ssLoad(125,"Media quotidiana");
parent.ssLoad(126,"Media oraria");
parent.ssLoad(128,"Media mensile");
parent.ssLoad(129,"Sistema");
parent.ssLoad(130,"Siti principali");
parent.ssLoad(131,"Siti principali: questa tabella classifica i siti Web sul server.");
parent.ssLoad(132,"Server principali ");
parent.ssLoad(133,"Server principali: questa tabella classifica il server utilizzato nel bilanciamento del carico. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/server.html\">fare clic qui</A>.");

parent.ssLoad(134,"Depositi principali");
parent.ssLoad(135,"Depositi principali: se si dispone di pi� depositi nel sistema di e-commerce, questo rapporto li classifica per importi in dollari e per ordini. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/topstores.html\">fare clic qui</A>.");
parent.ssLoad(136,"Importo totale in dollari");
parent.ssLoad(137,"Importo medio in dollari al giorno");
parent.ssLoad(138,"Importo medio in dollari per visitatore");
parent.ssLoad(139,"Moduli registrati");
parent.ssLoad(140,"Moduli registrati: questo prospetto mostra un elenco dei principali moduli adoperati sul sito.  L'elenco in realt� indica il gestore dei moduli, quale ad esempio uno script CGI. Sono elencati solo i gestori dei moduli che utilizzano il metodo POST. <P>Per ulteriori informazioni, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/it30/postedforms.html\">fare clic qui</A>.");
parent.ssLoad(141,"Gennaio");
parent.ssLoad(142,"Febbraio");
parent.ssLoad(143,"Marzo");
parent.ssLoad(144,"Aprile");
parent.ssLoad(145,"Maggio");
parent.ssLoad(146,"Giugno");
parent.ssLoad(147,"Luglio");
parent.ssLoad(148,"Agosto");
parent.ssLoad(149,"Settembre");
parent.ssLoad(150,"Ottobre");
parent.ssLoad(151,"Novembre");
parent.ssLoad(152,"Dicembre");
parent.ssLoad(153,"Da")
parent.ssLoad(154,"A")
parent.ssLoad(155,"Lun")
parent.ssLoad(156,"Mar")
parent.ssLoad(157,"Mer")
parent.ssLoad(158,"Gio")
parent.ssLoad(159,"Ven")
parent.ssLoad(160,"Sab")
parent.ssLoad(161,"Dom")
parent.ssLoad(162,"Gen");
parent.ssLoad(163,"Feb");
parent.ssLoad(164,"Mar");
parent.ssLoad(165,"Apr");
parent.ssLoad(166,"Mag");
parent.ssLoad(167,"Giu");
parent.ssLoad(168,"Lug");
parent.ssLoad(169,"Ago");
parent.ssLoad(170,"Set");
parent.ssLoad(171,"Ott");
parent.ssLoad(172,"Nov");
parent.ssLoad(173,"Dic");
parent.ssLoad(174,"sec");
parent.ssLoad(175,"pagine");
parent.ssLoad(176,"res");
parent.ssLoad(177,"Preferenze rapporto per");
parent.ssLoad(178,"Numero di serie");
parent.ssLoad(179,"Codice licenza");
parent.ssLoad(180,"Lingua");
parent.ssLoad(181,"Applica preferenze");
parent.ssLoad(182,"cinesi") 
parent.ssLoad(183,"inglesi") 
parent.ssLoad(184,"francesi") 
parent.ssLoad(185,"tedeschi") 
parent.ssLoad(186,"italiani") 
parent.ssLoad(187,"giapponesi") 
parent.ssLoad(188,"coreani") 
parent.ssLoad(189,"portugese") 
parent.ssLoad(190,"spagnoli") 
parent.ssLoad(191,"svedese") 
parent.ssLoad(192,"200: OK");
parent.ssLoad(193,"201: Created");
parent.ssLoad(194,"202: Accepted");
parent.ssLoad(195,"203: Non-Authorative Information");
parent.ssLoad(196,"204: No Content");
parent.ssLoad(197,"205: Reset Content");
parent.ssLoad(198,"206: Partial Content");

parent.ssLoad(199,"300: Multiple Choices");
parent.ssLoad(200,"301: Moved Permanently");
parent.ssLoad(201,"302: Found");
parent.ssLoad(202,"303: See Other");
parent.ssLoad(203,"304: Not Modified");
parent.ssLoad(204,"305: Use Proxy");

parent.ssLoad(205,"400: Bad Request");
parent.ssLoad(206,"401: Authorization Required");
parent.ssLoad(207,"402: Payment Required");
parent.ssLoad(208,"403: Forbidden");
parent.ssLoad(209,"404: Not Found");
parent.ssLoad(210,"405: Method Not Allowed");
parent.ssLoad(211,"406: Not Acceptable (encoding)");
parent.ssLoad(212,"407: Proxy Authentication Required");
parent.ssLoad(213,"408: Request Timed Out");
parent.ssLoad(214,"409: Conflicting Request");
parent.ssLoad(215,"410: Gone");
parent.ssLoad(216,"411: Content Length Required");
parent.ssLoad(217,"412: Precondition Failed");
parent.ssLoad(218,"413: Request Entity Too Long");
parent.ssLoad(219,"414: Request URI Too Long");
parent.ssLoad(220,"415: Unsupported Media Type");
parent.ssLoad(221,"416: Requested Range Not Satisfiable");
parent.ssLoad(222,"417: Expectation Failed");

parent.ssLoad(223,"500: Internal Server Error");
parent.ssLoad(224,"501: Not Implemented");
parent.ssLoad(225,"502: Bad Gateway");
parent.ssLoad(226,"503: Service Unavailable");
parent.ssLoad(227,"504: Gateway Timeout");
parent.ssLoad(228,"505: HTTP Version Not Supported");

parent.ssLoad(229,"Click Path From");
parent.ssLoad(230,"Click Through Page");
parent.ssLoad(231,"Clicks");
parent.ssLoad(232,"The Click Paths shows how people navigated through your site. From any one page, this chart shows how many times people clicked on the various links in the page. To see where people went next, click on a link of a particular page.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/221.html\">click here</A>.");
parent.ssLoad(233,"Date Range");
parent.ssLoad(234,"Help Information");
parent.ssLoad(235,"Percent");
