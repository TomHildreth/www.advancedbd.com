parent.ssLoad( 0,"Relat�rio do site");
parent.ssLoad( 1,"Tr�fego");
parent.ssLoad( 2,"Instant�neo");
parent.ssLoad( 3,"Gr�fico hor�rio");
parent.ssLoad( 4,"Gr�fico di�rio");
parent.ssLoad( 5,"Gr�fico mensal");
parent.ssLoad( 6,"P�ginas");
parent.ssLoad( 7,"Principais p�ginas");
parent.ssLoad( 8,"�rvore de diret�rio");
parent.ssLoad( 9,"Tipos de arquivo");
parent.ssLoad(10,"Status/ erros");
parent.ssLoad(11,"Encaminhamentos");
parent.ssLoad(12,"Principais encaminhamentos");
parent.ssLoad(13,"Principais palavras-chave");
parent.ssLoad(14,"�rvore de encaminhamentos");
parent.ssLoad(15,"�rvore de palavras-chave");
parent.ssLoad(16,"Mecanismo de busca");
parent.ssLoad(17,"Dom�nios");
parent.ssLoad(18,"Principais dom�nios");
parent.ssLoad(19,"�rvore de dom�nios");
parent.ssLoad(20,"Principais pa�ses");
parent.ssLoad(21,"Principais provedores");
parent.ssLoad(22,"Navegadores");
parent.ssLoad(23,"�rvore de navegadores");
parent.ssLoad(24,"�rvore de plataformas");
parent.ssLoad(25,"Principais combina��es");
parent.ssLoad(26,"Acompanhamento");
parent.ssLoad(27,"Principais entradas");
parent.ssLoad(28,"Principais sa�das");
parent.ssLoad(29,"Seq��ncia de cliques");
parent.ssLoad(30,"Profundidade da visita");
parent.ssLoad(31,"E-commerce");
parent.ssLoad(32,"Totais");
parent.ssLoad(33,"Principais produtos");
parent.ssLoad(34,"�rvore de produtos");
parent.ssLoad(35,"Regi�es");
parent.ssLoad(36,"Intervalo de datas");
parent.ssLoad(37,"Dia");
parent.ssLoad(38,"Semana");
parent.ssLoad(39,"M�s");
parent.ssLoad(40,"Ano");
parent.ssLoad(41,"Digitar intervalo");
parent.ssLoad(42,"Controles");
parent.ssLoad(43,"Prefer�ncias");
parent.ssLoad(44,"Exportar dados");
parent.ssLoad(45,"Inverter");
parent.ssLoad(46,"Ajuda");
parent.ssLoad(47,"Sum�rio");
parent.ssLoad(48,"M�dia di�ria");
parent.ssLoad(49,"Alterar");
parent.ssLoad(50,"Nomes de usu�rios");
parent.ssLoad(51,"Visitantes");
parent.ssLoad(52,"Visualiza��es de p�ginas");
parent.ssLoad(53,"Acessos");
parent.ssLoad(54,"Bytes");
parent.ssLoad(55,"Hora");
parent.ssLoad(56,"D�lares");
parent.ssLoad(57,"Totais");
parent.ssLoad(58,"Por visitante");
parent.ssLoad(59,"Relat�rio");
parent.ssLoad(60,"Exibir por");
parent.ssLoad(61,"Relat�rio do site para");
parent.ssLoad(62,"#Mostrada");
parent.ssLoad(63,"Anterior");
parent.ssLoad(64,"Por cento");
parent.ssLoad(65,"Pr�xima");
parent.ssLoad(66,"Informa��o de ajuda");
parent.ssLoad(67,"<B>N�o licenciado:</B> Este relat�rio requer uma Licen�a da Urchin. As licen�as para sites individuais, com base no dom�nio, est�o dispon�veis on-line por $199. Para licenciar este site e ativar todos os relat�rios agora, clique  <A CLASS=normal HREF=\"javascript:parent.getLicense();\">aqui</A>.");
parent.ssLoad(68,"Relat�rio inv�lido");
parent.ssLoad(69,"De");

parent.ssLoad(70,"Instant�neo: O Instant�neo apresenta uma vis�o geral da atividade recente do seu website. Os elementos no gr�fico de barras representam os Visitantes, e podem tamb�m ser classificados por Visualiza��es de p�ginas, Acessos ou Bytes transferidos (largura de banda). Se voc� tiver instalado o m�dulo de e-commerce Urchin, aparecer� tamb�m a guia D�lares, permitindo que voc� visualize esta e muitas outras informa��es do relat�rio em termos de d�lares gastos no seu site.  <P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/201.html\">clique aqui</A>.");

parent.ssLoad(71,"Sum�rio: O relat�rio sum�rio apresenta simplificadamente a contagem num�rica do tr�fego no seu site at� a presente data. As se��es incluem Totais, M�dias, e M�dias por visitante. Sugest�o: para comparar estes dados com os de outro per�odo, abra uma nova janela no navegador, v� at� o seu relat�rio e digite um novo intervalo de datas.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/202.html\">clique aqui</A>.");

parent.ssLoad(72,"Gr�fico hor�rio: Este gr�fico mostra o tr�fego no seu site com base na hora do dia. O gr�fico relata a atividade de um m�s inteiro em termos de Visitantes. Os elementos do gr�fico de barras podem ser classificados por Visualiza��es de p�ginas, Acessos, ou Bytes transferidos (largura de banda).<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/203.html\">clique aqui</A>.");

parent.ssLoad(73,"Gr�fico di�rio: Este gr�fico mostra o tr�fego no seu site por dia no per�odo de tempo especificado. Use a fun��o intervalo de datas para especificar um intervalo diferente. Os elementos do gr�fico de barras representam os Visitantes, e podem tamb�m ser classificados por Visualiza��es de p�ginas, Acessos, ou Bytes transferidos (largura de banda).<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/204.html\">clique aqui</A>.");

parent.ssLoad(74,"Gr�fico mensal: Este gr�fico mostra o tr�fego no seu site numa base mensal durante os �ltimos 12 meses. Se o site n�o esteve em funcionamento todo esse tempo, somente ser�o relatados os meses em que houver dados dispon�veis. Os elementos do gr�fico de barras representam os Visitantes, e podem tamb�m ser classificados por Visualiza��es de p�ginas, Acessos, ou Bytes transferidos (largura de banda).<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/205.html\">clique aqui</A>.");

parent.ssLoad(75,"Principais p�ginas: Este relat�rio mostra as 10 p�ginas mais visitadas no seu site, e apresenta a porcentagem relativa a cada uma delas. O n�mero de p�ginas mostradas neste relat�rio pode ser controlado alterando-se o valor na �rea #Mostrada.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/206.html\">clique aqui</A>.");

parent.ssLoad(76,"�rvore de diret�rio: Este relat�rio lista cada diret�rio (tamb�m chamado de pasta) do seu site e as p�ginas nele contidas que foram acessadas. Para ver essas p�ginas, � s� clicar na setinha ao lado de cada entrada, e o menu se abrir�. O n�mero de diret�rios mostrados neste relat�rio pode ser controlado alterando-se o valor na �rea #Mostrada.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/207.html\">clique aqui</A>.");

parent.ssLoad(77,"Tipos de arquivo: Este relat�rio mostra os tipos de arquivos que foram acessados no seu site, como imagens GIF, arquivos HTML, ou scripts CGI. � interessante visualizar este relat�rio em termos de Acessos (requisi��es feitas ao servidor) em oposi��o a Bytes, para ver que tipos de arquivos est�o usando mais recursos na rede. O n�mero de tipos de arquivos mostrados neste relat�rio pode ser controlado alterando-se o valor na �rea #Mostrada.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/208.html\">clique aqui</A>.");

parent.ssLoad(78,"Status/Erros: Este relat�rio mostra o c�digo de status de cada resposta. Os 400s representam erros, inclusive arquivos n�o encontrados. Clique na setinha para ver mais detalhes sobre os erros.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/1204.html\">clique aqui</A>.");

parent.ssLoad(79,"Principais encaminhamentos: Este relat�rio lista os endere�os (URLs) das p�ginas contendo links que, ao serem clicados, conduzem o internauta ao seu site. Ele provavelmente incluir� mecanismos de busca e sites de cataloga��o de endere�os. O n�mero de encaminhamentos apresentados neste relat�rio pode ser controlado alterando-se o valor na �rea #Mostrada.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/209.html\">clique aqui</A>.");

parent.ssLoad(80,"Principais palavras-chave: Este relat�rio lista as palavras-chave que as pessoas digitaram nos mecanismos de busca para encontrar o seu site. Este relat�rio ajuda voc� a avaliar quais palavras-chave est�o tendo o efeito esperado, levando pessoas a seu site.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/211.html\">clique aqui</A>.");

parent.ssLoad(81,"�rvore de encaminhamentos: Este relat�rio lista os principais dom�nios que trouxeram visitantes ao seu site. Pode-se clicar na setinha azul ao lado de cada entrada para conhecer as p�ginas que cont�m os links nos quais as pessoas clicaram.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/210.html\">clique aqui</A>.");

parent.ssLoad(82,"�rvore de palavras-chave: Este relat�rio bastante �til lista os principais mecanismos de busca usados para se chegar ao seu site. Clicando na setinha ao lado de cada entrada, voc� pode ver as palavras-chave usadas naquele determinado mecanismo de busca para chegar at� o seu site. O n�mero de entradas mostradas neste relat�rio pode ser alterado, digitando-se um novo valor na caixa \"#Mostrada\" e apertando-se a tecla Enter. Este relat�rio pode ser classificado por Visitantes, Visualiza��es de p�gina, Acessos, Bytes transferidos (largura de banda), e Tempo.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/212.html\">clique aqui</A>.");

parent.ssLoad(83,"Mecanismos de busca: Este relat�rio lista cada um dos mecanismos de busca usado com sucesso para se chegar ao seu site. Clicando na setinha azul perto de cada entrada, voc� pode ver as palavras-chave digitadas. Este � um dos relat�rios mais �teis do Urchin para o webmaster.  Ele mostra com exatid�o como o seu site est� cadastrado nos mecanismos de busca, e quais palavras-chave resultam em tr�fego. Isso pode ser muito �til se voc� cadastrou p�ginas recentemente, ou se mudou o conte�do do site.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/212.html\">clique aqui</A>.");

parent.ssLoad(84,"Principais dom�nios: Este vers�til  relat�rio mostra as redes de onde v�m os visitantes do seu site. O Urchin � capaz de reconhecer a maioria das redes. Algumas, entretanto, n�o ser�o reconhecidas, significando que  a rede n�o p�de ser identificada. Esta informa��o � muito importante para personalizar seu website, j� que alguns visitantes podem ter navegadores com capacidades diferentes.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/213.html\">clique aqui</A>.");

parent.ssLoad(85,"�rvore de dom�nios: Este relat�rio lista os principais dom�nios, tal como .com e .net, dos quais v�m os visitantes do seu site. Clicando na setinha ao lado de cada entrada, voc� pode ver as redes sob cada um dos principais dom�nios.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/214.html\">clique aqui</A>.");

parent.ssLoad(86,"Principais pa�ses: Este relat�rio lista os principais pa�ses que acessam o seu site. Est�o inclu�dos os dom�nios  predominantemente atribu�dos a sites dos EUA (com, net e  org) e os que s�o exclusivamente atribu�dos a sites dos EUA  (edu, gov e mil). <P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/215.html\">clique aqui</A>.");

parent.ssLoad(87,"Principais provedores de Internet: Este relat�rio lista os principais provedores (ISPs) de <B>grande porte</B>, como earthlink.net, cujos clientes visitaram seu site. O n�mero de entradas mostradas neste relat�rio pode ser alterado digitando-se um novo valor na caixa \"#Mostrada\" e pressionando-se a tecla Enter. Este relat�rio pode ser classificado por Visitantes, Visualiza��es de p�ginas, Acessos, Bytes transferidos (largura de banda), e Tempo.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/topisps.html\">clique aqui</A>.");

parent.ssLoad(88,"�rvore de navegadores: Este relat�rio lista os principais navegadores, como Netscape Navigator e Microsoft Internet Explorer, usados pelos visitantes do seu site. Voc� tamb�m ver� listados rob�s, como os usados pelos mecanismos de busca para encontrar o conte�do de um website, e outros tipos de programas de internet automatizados. Clicando na seta ao lado de cada entrada, voc� pode ver as vers�es de cada navegador ou agente espec�fico.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/216.html\">clique aqui</A>.");

parent.ssLoad(89,"�rvore de plataformas: Este relat�rio lista as principais plataformas de computadores, como Windows, Macintosh, e Unix,  usadas pelos visitantes do seu site. Clicando na seta ao lado de cada entrada, voc� pode ver as vers�es de cada plataforma usada, como Windows 98 ou FreeBSD.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/217.html\">clique aqui</A>.");

parent.ssLoad(90,"Principais combina��es: Este relat�rio combina os relat�rios de Navegadores e Plataformas e produz uma lista das configura��es mais comuns dos computadores usados para visualizar seu site. Alguns exemplos seriam Explorer 5/Windows 98 e Mac PPC/Netscape 4.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/218.html\">clique aqui</A>.");

parent.ssLoad(91,"Principais entradas: Este relat�rio lista as principais p�ginas que s�o acessadas em primeiro lugar dentro do seu site. Isso, em geral, ser� algo como index.html ou default.html, nomes mais comumente dados � p�gina inicial de um site. Outras das p�ginas listadas podem ter sido acessadas a partir de links de outros sites ou adicionadas aos marcadores do navegador para acesso r�pido.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/219.html\">clique aqui</A>.");

parent.ssLoad(92,"Principais sa�das: Este relat�rio lista as p�ginas mais comumente visitadas antes de as pessoas sa�rem do seu site. � importante estudar este relat�rio a fim de segurar, ou reter, o visitante por mais tempo no site.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/220.html\">clique aqui</A>.");

parent.ssLoad(93,"Seq��ncia de cliques: Este relat�rio lista os principais caminhos seguidos pelas pessoas ao navegar pelo seu site, a partir da p�gina visitada em primeiro lugar. Ao clicar em cada entrada, voc� pode ir vendo a seq��ncia de p�ginas de cada caminho seguido por seus visitantes, e assim por diante. <P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/221.html\">clique aqui</A>.");

parent.ssLoad(94,"Dura��o da visita: Este relat�rio mostra quanto tempo, em m�dia, os visitantes ficam no seu site.  Nota: os segmentos temporais para cada elemento gr�fico aumentam ao longo do eixo  'x' .<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/223.html\">clique aqui</A>.");

parent.ssLoad(95,"Profundidade: Este gr�fico ilustra a que profundidade os visitantes navegam no seu site, mostrando o n�mero de  p�ginas visitadas.  Este relat�rio � muito �til para avaliar a pertin�ncia do seu conte�do para os visitantes.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/222.html\">clique aqui</A>.");

parent.ssLoad(96,"Visitantes");
parent.ssLoad(97,"P�ginas/visitante");
parent.ssLoad(98,"Acessos/visitante");
parent.ssLoad(99,"Bytes/visitante");
parent.ssLoad(100,"Tempo/visitante");
parent.ssLoad(101,"D�lares/visitante");

parent.ssLoad(102,"Nomes de usu�rios: Este relat�rio lista os principais nomes de usu�rios empregados em qualquer processo de autentica��o exigido pelo seu site. Se voc� n�o exige uma senha, ent�o nenhum nome de usu�rio ser� listado.<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/224.html\">clique aqui</A>.");

parent.ssLoad(103,"Relat�rio de servidor");
parent.ssLoad(104,"Classifica��o de site");
parent.ssLoad(105,"Classifica��o de servidor");

parent.ssLoad(106,"Totais: Este relat�rio mostra as informa��es b�sicas de vendas durante o Intervalo de datas selecionado. O valor total das vendas � apresentado junto com as m�dias por visitante e por dia. <P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/totals.html\">clique aqui</A>.");

parent.ssLoad(107,"Principais produtos: Este relat�rio lista os principais itens vendidos no seu website, junto com a porcentagem do total das vendas que cada um deles representa, e um gr�fico de barras relativo, para r�pida assimila��o visual. Junto a cada item na lista, aparece relacionada a categoria do item (se houver). <P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/topproducts.html\">clique aqui</A>.");

parent.ssLoad(108,"�rvore de produtos: Este relat�rio lista as principais categorias de itens vendidos. Ao lado de cada item h� uma setinha azul na qual se pode clicar para ver as subcategorias (se houver) e os pr�prios itens. <P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/producttree.html\">clique aqui</A>.");

parent.ssLoad(109,"Regi�es: Este relat�rio lista as principais regi�es de onde v�m os consumidores do seu site. Ao clicar na setinha azul ao lado de cada entrada, voc� ver� as subregi�es. Ao lado de cada entrada est� o valor total em d�lares que ela representa, e um gr�fico de barras indicando a import�ncia relativa de cada regi�o por vendas. <P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/regions.html\">clique aqui</A>.");
parent.ssLoad(110,"Dura��o visita");
parent.ssLoad(111,"Dura��o da visita: Este relat�rio mostra quanto tempo, em m�dia, os visitantes ficam no seu site.  Nota: os segmentos temporais para cada elemento gr�fico aumentam ao longo do eixo  'x' .<P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/223.html\">clique aqui</A>.");
parent.ssLoad(112,"Total de visitantes");
parent.ssLoad(113,"Total de visualiza��es de p�ginas");
parent.ssLoad(114,"Total de acessos");
parent.ssLoad(115,"Total de bytes transferidos");
parent.ssLoad(116,"M�dia de visitantes por dia");
parent.ssLoad(117,"M�dia de visualiza��es de p�ginas por dia");
parent.ssLoad(118,"M�dia de acessos por dia");
parent.ssLoad(119,"M�dia de bytes transferidos por dia");
parent.ssLoad(120,"M�dia de visualiza��es de p�ginas por visitante");
parent.ssLoad(121,"M�dia de acessos por visitante");
parent.ssLoad(122,"M�dia de bytes por visitante");
parent.ssLoad(123,"Dura��o m�dia da visita");
parent.ssLoad(124,"Alcance total");
parent.ssLoad(125,"M�dia di�ria");
parent.ssLoad(126,"M�dia hor�ria");
parent.ssLoad(128,"M�dia mensal");
parent.ssLoad(129,"Sistema");
parent.ssLoad(130,"Principais sites");
parent.ssLoad(131,"Principais sites: Esta tabela classifica os websites do seu servidor");
parent.ssLoad(132,"Principais servidores");
parent.ssLoad(133,"Principais servidores: Esta tabela classifica o servidor usado na distribui��o de carga <P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/server.html\">clique aqui</A>.");
parent.ssLoad(134,"Principais lojas");
parent.ssLoad(135,"Principais lojas: se o seu sistema de e-commerce possui v�rias lojas,  com este relat�rio voc� pode classific�-las por d�lares e pedidos. <P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/topstores.html\">clique aqui</A>.");
parent.ssLoad(136,"Total em d�lares");
parent.ssLoad(137,"M�dia de d�lares por dia");
parent.ssLoad(138,"M�dia de d�lares por visitante");
parent.ssLoad(139,"Formul�rios enviados");
parent.ssLoad(140,"Formul�rios enviados: Este relat�rio apresenta uma lista dos relat�rios mais usados no seu site. A lista na verdade indica o operador de formul�rio, tal como um script CGI. Apenas os operadores de formul�rio que usam o m�todo ENVIAR s�o listados.  <P>Para mais informa��es, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/po30/postedforms.html\">clique aqui</A>.");
parent.ssLoad(141,"Janeiro");
parent.ssLoad(142,"Fevereiro");
parent.ssLoad(143,"Mar�o");
parent.ssLoad(144,"Abril");
parent.ssLoad(145,"Maio");
parent.ssLoad(146,"Junho");
parent.ssLoad(147,"Julho");
parent.ssLoad(148,"Agosto");
parent.ssLoad(149,"Setembro");
parent.ssLoad(150,"Outubro");
parent.ssLoad(151,"Novembro");
parent.ssLoad(152,"Dezembro");
parent.ssLoad(153,"De")
parent.ssLoad(154,"Para")
parent.ssLoad(155,"Seg")
parent.ssLoad(156,"Ter")
parent.ssLoad(157,"Qua")
parent.ssLoad(158,"Qui")
parent.ssLoad(159,"Sex")
parent.ssLoad(160,"S�b")
parent.ssLoad(161,"Dom")
parent.ssLoad(162,"Jan");
parent.ssLoad(163,"Fev");
parent.ssLoad(164,"Mar");
parent.ssLoad(165,"Abr");
parent.ssLoad(166,"Maio");
parent.ssLoad(167,"Jun");
parent.ssLoad(168,"Jul");
parent.ssLoad(169,"Ago");
parent.ssLoad(170,"Set");
parent.ssLoad(171,"Out");
parent.ssLoad(172,"Nov");
parent.ssLoad(173,"Dez");
parent.ssLoad(174,"sec");
parent.ssLoad(175,"p�gina");
parent.ssLoad(176,"min");
parent.ssLoad(177,"Prefer�ncias de relat�rio para");
parent.ssLoad(178,"N�mero de s�rie");
parent.ssLoad(179,"C�digo da licen�a");
parent.ssLoad(180,"Idioma");
parent.ssLoad(181,"Prefer�ncias para inscri��o");
parent.ssLoad(182,"chin�s") 
parent.ssLoad(183,"ingleses") 
parent.ssLoad(184,"franc�s") 
parent.ssLoad(185,"Alem�o") 
parent.ssLoad(186,"italiano") 
parent.ssLoad(187,"japon�s") 
parent.ssLoad(188,"coreano") 
parent.ssLoad(189,"portugu�s") 
parent.ssLoad(190,"espanhol") 
parent.ssLoad(191,"sueco") 
parent.ssLoad(192,"200: OK");
parent.ssLoad(193,"201: Created");
parent.ssLoad(194,"202: Accepted");
parent.ssLoad(195,"203: Non-Authorative Information");
parent.ssLoad(196,"204: No Content");
parent.ssLoad(197,"205: Reset Content");
parent.ssLoad(198,"206: Partial Content");

parent.ssLoad(199,"300: Multiple Choices");
parent.ssLoad(200,"301: Moved Permanently");
parent.ssLoad(201,"302: Found");
parent.ssLoad(202,"303: See Other");
parent.ssLoad(203,"304: Not Modified");
parent.ssLoad(204,"305: Use Proxy");

parent.ssLoad(205,"400: Bad Request");
parent.ssLoad(206,"401: Authorization Required");
parent.ssLoad(207,"402: Payment Required");
parent.ssLoad(208,"403: Forbidden");
parent.ssLoad(209,"404: Not Found");
parent.ssLoad(210,"405: Method Not Allowed");
parent.ssLoad(211,"406: Not Acceptable (encoding)");
parent.ssLoad(212,"407: Proxy Authentication Required");
parent.ssLoad(213,"408: Request Timed Out");
parent.ssLoad(214,"409: Conflicting Request");
parent.ssLoad(215,"410: Gone");
parent.ssLoad(216,"411: Content Length Required");
parent.ssLoad(217,"412: Precondition Failed");
parent.ssLoad(218,"413: Request Entity Too Long");
parent.ssLoad(219,"414: Request URI Too Long");
parent.ssLoad(220,"415: Unsupported Media Type");
parent.ssLoad(221,"416: Requested Range Not Satisfiable");
parent.ssLoad(222,"417: Expectation Failed");

parent.ssLoad(223,"500: Internal Server Error");
parent.ssLoad(224,"501: Not Implemented");
parent.ssLoad(225,"502: Bad Gateway");
parent.ssLoad(226,"503: Service Unavailable");
parent.ssLoad(227,"504: Gateway Timeout");
parent.ssLoad(228,"505: HTTP Version Not Supported");

parent.ssLoad(229,"Click Path From");
parent.ssLoad(230,"Click Through Page");
parent.ssLoad(231,"Clicks");
parent.ssLoad(232,"The Click Paths shows how people navigated through your site. From any one page, this chart shows how many times people clicked on the various links in the page. To see where people went next, click on a link of a particular page.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/221.html\">click here</A>.");
parent.ssLoad(233,"Date Range");
parent.ssLoad(234,"Help Information");
parent.ssLoad(235,"Percent");
