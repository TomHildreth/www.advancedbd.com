parent.ssLoad( 0,"Site-Bericht");
parent.ssLoad( 1,"Verkehr");
parent.ssLoad( 2,"Schnappschu�");
parent.ssLoad( 3,"Stundendiagramm");
parent.ssLoad( 4,"Tagesdiagramm");
parent.ssLoad( 5,"Monatsdiagramm");
parent.ssLoad( 6,"Seiten");
parent.ssLoad( 7,"Topseiten");
parent.ssLoad( 8,"Verzeichnisbaum");
parent.ssLoad( 9,"Dateitypen");
parent.ssLoad(10,"Status/Fehler");
parent.ssLoad(11,"Referrals");
parent.ssLoad(12,"Top-Referrals");
parent.ssLoad(13,"Topschl�sselw.");
parent.ssLoad(14,"Referral-Baum");
parent.ssLoad(15,"Schl�sselwortbaum");
parent.ssLoad(16,"Suchprogramme");
parent.ssLoad(17,"Dom�nen");
parent.ssLoad(18,"Topdom�nen");
parent.ssLoad(19,"Dom�nenbaum");
parent.ssLoad(20,"Topl�nder");
parent.ssLoad(21,"Top-ISPs");
parent.ssLoad(22,"Browser");
parent.ssLoad(23,"Browserbaum");
parent.ssLoad(24,"Plattformbaum");
parent.ssLoad(25,"Topkombinationen");
parent.ssLoad(26,"Verfolgen");
parent.ssLoad(27,"Topeingangsseiten");
parent.ssLoad(28,"Topausgangsseiten");
parent.ssLoad(29,"Durchklicken");
parent.ssLoad(30,"Besuchstiefe");
parent.ssLoad(31,"E-Commerce");
parent.ssLoad(32,"Summen");
parent.ssLoad(33,"Topprodukte");
parent.ssLoad(34,"Produktbaum");
parent.ssLoad(35,"Regionen");
parent.ssLoad(36,"Zeitraum");
parent.ssLoad(37,"Tag");
parent.ssLoad(38,"Woche");
parent.ssLoad(39,"Monat");
parent.ssLoad(40,"Jahr");
parent.ssLoad(41,"Zeitabschnitt eingeben");
parent.ssLoad(42,"Kontrollen");
parent.ssLoad(43,"Einstellungen");
parent.ssLoad(44,"Daten exportieren");
parent.ssLoad(45,"Umkehren");
parent.ssLoad(46,"Hilfe");
parent.ssLoad(47,"Zusammenfassung");
parent.ssLoad(48,"Tagesdurchschnitt");
parent.ssLoad(49,"�ndern");
parent.ssLoad(50,"Benutzernamen");
parent.ssLoad(51,"Besucher");
parent.ssLoad(52,"Seitenansichten");
parent.ssLoad(53,"Treffer");
parent.ssLoad(54,"Byte");
parent.ssLoad(55,"Uhrzeit");
parent.ssLoad(56,"Dollar");
parent.ssLoad(57,"Summen");
parent.ssLoad(58,"Pro Besucher");
parent.ssLoad(59,"Bericht");
parent.ssLoad(60,"Ansicht f�r");
parent.ssLoad(61,"Site-Bericht f�r");
parent.ssLoad(62,"Zahl Angezeigt");
parent.ssLoad(63,"Zur�ck");
parent.ssLoad(64,"Prozent");
parent.ssLoad(65,"Weiter");
parent.ssLoad(66,"Hilfeinformationen");
parent.ssLoad(67,"<B>! Nicht lizenziert:</B> F�r diese Berichtsfunktion ben�tigen Sie eine Urchin-Lizenz. Dom�nenbasierte Lizenzen f�r einzelne Websites erhalten Sie online f�r 199 USD. Um f�r diese Website eine Lizenz zu erwerben und sofort alle Berichte zu aktivieren, klicken Sie <A CLASS=normal HREF=\"javascript:parent.getLicense();\">hier</A>.");
parent.ssLoad(68,"Bericht deaktiviert");
parent.ssLoad(69,"von");

parent.ssLoad(70,"Schnappschu�: Der Schnappschu� bietet einen �berblick �ber die j�ngsten Aktivit�ten auf der Website. Die Elemente des Balkendiagramms stellen standardm��ig Besucher dar und k�nnen auf Seitenansichten, Treffer oder �bertragene Byte (Bandbreite) umgeschaltet werden. Wenn Sie das E-Commerce-Modul von Urchin installiert haben, wird auch das Register \"Dollar\" angezeigt, in dem Sie diese Information und die der meisten anderen Berichte nach der auf Ihrer Site ausgegebenen Geldmenge anzeigen k�nnen.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/201.html\">klicken Sie hier</A>.");

parent.ssLoad(71,"Zusammenfassung: Der Zusammenfassungsbericht ist eine einfache numerische Zusammenstellung des Verkehrs auf Ihrer Site im aktuellen Zeitraum. Zu den vorhandenen Bereichen z�hlen \"Summen\", \"Durchschnitte\" und \"Durchschnitte pro Besucher\". Tip: Wenn Sie diese Daten mit einem anderen Zeitraum vergleichen m�chten, �ffnen Sie ein neues Browserfenster, rufen Sie Ihren Bericht auf, und geben Sie einen neuen Zeitraum ein.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/202.html\">klicken Sie hier</A>.");

parent.ssLoad(72,"Stundendiagramm: Dieses Diagramm zeigt den Verkehr auf Ihrer Site nach Tageszeit an. Das Diagramm gibt die Aktivit�t eines gesamten Monats nach Besucherzahl aus. Das Balkendiagramm enth�lt die Elemente \"Seitenansichten\", \"Treffer\" oder \"�bertragene Byte (Bandbreite)\".<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/203.html\">klicken Sie hier</A>.");

parent.ssLoad(73,"Tagesdiagramm: Dieses Diagramm zeigt im angegebenen Zeitraum den t�glichen Verkehr auf Ihrer Site an. Verwenden Sie zur Wahl eines anderen Zeitraums die Datumsbereichsfunktion. Die Elemente des Balkendiagramms stellen standardm��ig \"Besucher\" dar und k�nnen auf \"Seitenansichten\", \"Treffer\" oder \"�bertragene Byte (Bandbreite)\" umgeschaltet werden.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/204.html\">klicken Sie hier</A>.");

parent.ssLoad(74,"Monatsdiagramm: Dieses Diagramm zeigt f�r die letzten 12 Monate den monatlichen Verkehr auf Ihrer Site an. Wenn Ihre Site weniger als zw�lf Monaten in Betrieb ist, werden die Monate ausgegeben, f�r die Daten zur Verf�gung stehen. Die Elemente des Balkendiagramms stellen standardm��ig \"Besucher\" dar und k�nnen auf \"Seitenansichten\", \"Treffer\" oder \"�bertragene Byte (Bandbreite)\" umgeschaltet werden.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/205.html\">klicken Sie hier</A>.");

parent.ssLoad(75,"Topseiten: Dieser Bericht zeigt die zehn Seiten Ihrer Site an, die am h�ufigsten besucht wurden, und stellt den jeweiligen Prozentwert bildlich dar. Die Anzahl der in diesem Bericht angegebenen Seiten kann mit dem Wert im Bereich Zahl Angezeigt ge�ndert werden. <P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/206.html\">klicken Sie hier</A>.");

parent.ssLoad(76,"Verzeichnisbaum: In diesem Bericht werden alle Verzeichnisse auf Ihrer Site (manchmal auch als \"Ordner\" bezeichnet) und die darin enthaltenen Seiten aufgef�hrt, auf die zugegriffen wurde. Um diese Seiten zu sehen, klicken Sie auf die Pfeilfl�che neben dem jeweiligen Eintrag, damit das Men� erweitert wird. Die Anzahl der in diesem Bericht angezeigten Verzeichnisse kann mit dem Wert im Bereich Zahl Angezeigt ge�ndert werden.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/207.html\">klicken Sie hier</A>.");

parent.ssLoad(77,"Dateitypen: Dieser Bericht enth�lt die Dateitypen auf Ihrer Site, auf die zugegriffen wurde, z. B. GIF-Bilder, HTML-Dateien oder CGI-Skripts. Dieser Bericht ist aufschlu�reich, da sich die Trefferzahl (Serveranfragen) mit der Bytezahl vergleichen l��t, um zu sehen, welche Dateitypen die meisten Netzwerkressourcen beanspruchen. Die Anzahl der in diesem Bericht angezeigten Dateitypen kann mit dem Wert im Bereich Zahl Angezeigt ge�ndert werden.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/208.html\">klicken Sie hier</A>.");

parent.ssLoad(78,"Status/Fehler: Dieser Bericht gibt den Statuscode aller Antworten an. Die \"400\"-Codes stellen Fehler dar, wie z. B. nicht gefunden Dateien. Klicken Sie auf die Pfeilfl�che, um n�here Informationen �ber die Fehler einzublenden.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/1204.html\">klicken Sie hier</A>.");

parent.ssLoad(79,"Top-Referrals: Dieser Bericht enth�lt die Adressen (URLs) der Webseiten, auf deren Links zu Ihrer Site der Besucher geklickt hat. Hierzu geh�ren h�chstwahrscheinlich Suchprogramme und andere Verzeichnis-Sites. Die Anzahl der in diesem Bericht angezeigten Referrals kann mit dem Wert im Bereich Zahl Angezeigt ge�ndert werden.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/209.html\">klicken Sie hier</A>.");

parent.ssLoad(80,"Topschl�sselw�rter: Dieser Bericht enth�lt die Schl�sselw�rter, welche die Besucher zum Auffinden Ihrer Site eingegeben haben. Mit diesem Bericht k�nnen Sie feststellen, ob die Schl�sselw�rter, welche die Besucher zu Ihrer Site f�hren sollen, den gew�nschten Effekt haben.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/211.html\">klicken Sie hier</A>.");

parent.ssLoad(81,"Referral-Baum: Dieser Bericht enth�lt die Topdom�nen, welche die Besucher zu Ihrer Site gef�hrt haben. Sie k�nnen auf den kleinen blauen Pfeil neben dem jeweiligen Eintrag klicken, um die Seiten mit den Links anzuzeigen, auf welche die Besucher geklickt haben.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/210.html\">klicken Sie hier</A>.");

parent.ssLoad(82,"Schl�sselwortbaum: Dieser sehr n�tzliche Bericht gibt an, welche Suchproamme die Besucher zum Auffinden Ihrer Site am meisten verwendet haben. Durch Klicken auf den kleinen Pfeil neben dem jeweiligen Eintrag k�nnen Sie die Schl�sselw�rter einblenden, die beim entsprechenden Suchprogramm verwendet wurden, um Ihre Site zu finden. Die Anzahl der in diesem Bericht angezeigten Eintr�ge kann durch Eingabe eines neuen Wertes im Feld \"Zahl Angezeigt\" und Dr�cken der Eingabetaste ge�ndert werden. Sie k�nnen die Anzeige dieses Berichts zwischen \"Besucher\", \"Seitenansichten\", \"Treffer\", \"�bertragene Byte (Bandbreite)\" und \"Uhrzeit\" umschalten.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/212.html\">klicken Sie hier</A>.");

parent.ssLoad(83,"Suchprogramme: Dieser Bericht enth�lt alle Suchprogramme, die erfolgreich zum Auffinden Ihrer Website verwendet wurden. Durch Klicken auf den kleinen blauen Pfeil neben dem jeweiligen Eintrag k�nnen Sie die von den Besuchern eingegebenen Schl�sselw�rter anzeigen. F�r einen Webmaster ist dies einer der n�tzlichsten Urchin-Berichte. Er zeigt Ihnen genau, wie gut Ihre Site bei den Suchprogrammen registriert ist und welche Schl�sselw�rter Ihnen Besucher bringen. Dies kann sehr n�tzlich sein, wenn Sie Ihre Site erst k�rzlich registriert oder den Inhalt der Site ge�ndert haben.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/212.html\">klicken Sie hier</A>.");

parent.ssLoad(84,"Topdom�nen: Dieser aufschlu�reiche Bericht zeigt Ihnen, von welchen Netzwerken Ihre Besucher kommen. Urchin kann die meisten Netzwerke erkennen, doch gibt es immer einige Netzwerke, die nicht identifiziert werden k�nnen. Diese Information ist sehr wichtig zur Anpassung Ihrer Website, da die Besucher Browser mit unterschiedlichen F�higkeiten haben.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/213.html\">klicken Sie hier</A>.");

parent.ssLoad(85,"Dom�nenbaum: Dieser Bericht enth�lt die Topdom�nen, wie z. B. .com und .net, von denen die Besucher Ihrer Site kommen. Durch Klicken auf den kleinen Pfeil neben dem jeweiligen Eintrag k�nnen Sie die eigentlichen Netzwerke unter der betreffenden Topdom�ne sehen.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/214.html\">klicken Sie hier</A>.");

parent.ssLoad(86,"Topl�nder: Dieser Bericht f�hrt die Zugriffe auf Ihre Website nach L�ndern auf. Die .net-, .com- und .org-Dom�nen (oft USA) und die .edu-, .gov- und .mil-Dom�nen (immer USA) sind ebenfalls in dieser Liste aufgef�hrt.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/215.html\">klicken Sie hier</A>.");

parent.ssLoad(87,"Top-ISPs: Dieser Bericht enth�lt die am h�ufigsten vertretenen <B>Haupt-ISPs</B>, wie z. B. earthlink.net, deren Kunden Ihre Site besucht haben. Die Anzahl der in diesem Bericht angezeigten Eintr�ge kann durch Eingabe eines neuen Wertes im Feld \"Zahl Angezeigt\" und Dr�cken der Eingabetaste ge�ndert werden. Dieser Bericht kann zwischen \"Besucher\", \"Seitenansichten\", \"Treffer\", \"�bertragene Byte (Bandbreite)\" und \"Uhrzeit\" umgeschaltet werden.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/topisps.html\">klicken Sie hier</A>.");

parent.ssLoad(88,"Browserbaum: Dieser Bericht enth�lt die  Browser, wie z. B. Netscape Navigator und Microsoft Internet Explorer, welche die Benutzer zum Besuchen Ihrer Site am h�ufigsten verwendet haben. Es werden auch sog. Roboter, wie z. B. die von den Suchprogrammen zum Finden von Website-Inhalten verwendeten, und andere Arten von automatisierten Internetprogrammen aufgef�hrt. Durch Klicken auf den Pfeil neben dem jeweiligen Eintrag k�nnen Sie die Versionen des betreffenden Browsers oder Agenten einblenden.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/216.html\">klicken Sie hier</A>.");

parent.ssLoad(89,"Plattformbaum: Dieser Bericht enth�lt die Computerplattformen, wie z. B. Windows, Macintosh und Unix, welche die Benutzer zum Besuchen Ihrer Site am h�ufigsten verwendet haben. Durch Klicken auf den Pfeil neben dem jeweiligen Eintrag k�nnen Sie die Versionen der verwendeten Plattformen sehen, wie z. B. Windows 98 oder FreeBSD.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/217.html\">klicken Sie hier</A>.");

parent.ssLoad(90,"Topkombinationen: Dieser Bericht kombiniert die Browser- und Plattformberichte und enth�lt eine Liste der Computerkonfigurationen, die zum Betrachten Ihrer Site am h�ufigsten verwendet werden. Beispiele hierf�r sind Explorer 5/Windows 98 und Mac PPC/Netscape 4.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/218.html\">klicken Sie hier</A>.");

parent.ssLoad(91,"Topeingangsseiten: Dieser Bericht enth�lt die Seiten, auf welcher die meisten Besucher Ihrer Site zuerst ankommen. Dies ist normalerweise index.html oder default.html, welche die g�ngigsten Namen f�r Homepages sind. Es werden au�erdem Seiten aufgef�hrt, auf die ein Link von anderen Sites existiert oder die f�r schnellen Zugriff markiert sind.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/219.html\">klicken Sie hier</A>.");

parent.ssLoad(92,"Topausgangsseiten: Dieser Bericht enth�lt die Seiten, von denen aus die meisten Besucher Ihre Site verlassen haben. Dieser Bericht ist besonders n�tzlich, wenn es darum geht, Besucher zu halten bzw. zur R�ckkehr zu bewegen. <P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/220.html\">klicken Sie hier</A>.");

parent.ssLoad(93,"Durchklicken: Dieser Bericht enth�lt die Pfade, welche die Besucher Ihrer Site sm h�ufigsten verwendet haben. Die Sortierung beginnt mit der ersten besuchten Seite. Durch Klicken auf jeden der Eintr�ge k�nnen Sie die n�chsten Seiten des Pfads darstellen, den Ihre Besucher genommen haben usw.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/221.html\">klicken Sie hier</A>.");

parent.ssLoad(94,"Besuchsdauer: Dieser Bericht enth�lt die Zeitdauer, welche die Besucher im Durchschnitt auf Ihrer Site verbracht haben. Hinweis: Die Zeitsegmente f�r jedes Grafikelement nehmen auf der X-Achse zu.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/223.html\">klicken Sie hier</A>.");

parent.ssLoad(95,"Tiefe: Dieses Diagramm veranschaulicht die Tiefe, mit der die Benutzer Ihre Site besucht haben. Die Anzeige erfolgt nach Anzahl der besuchten Seiten. Dieser Bericht ist sehr n�tzlich zur Bewertung der Relevanz des Inhalts f�r Ihre Besucher.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/222.html\">klicken Sie hier</A>.");

parent.ssLoad(96,"Besucher");
parent.ssLoad(97,"Seiten/Besucher");
parent.ssLoad(98,"Treffer/Besucher");
parent.ssLoad(99,"Byte/Besucher");
parent.ssLoad(100,"Zeit/Besucher");
parent.ssLoad(101,"Dollar/Besucher");

parent.ssLoad(102,"Benutzernamen: Dieser Bericht enth�lt die beliebtesten Benutzernamen, die w�hrend des von Ihrer Site erforderlichen �berpr�fungsprozesses verwendet wurden. Wenn Sie kein Kennwort erfordern, werden keine Benutzernamen aufgef�hrt.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/224.html\">klicken Sie hier</A>.");

parent.ssLoad(103,"Serverbericht");
parent.ssLoad(104,"Site-Rangliste");
parent.ssLoad(105,"Serverrangliste");

parent.ssLoad(106,"Summen: Dieser Bericht enth�lt grundlegende Umsatzinformationen f�r den ausgew�hlten Zeitraum. Es wird der Gesamtwert der Ums�tze angezeigt und dazu der Durchschnitt pro Besucher und pro Tag.");

parent.ssLoad(107,"Topprodukte: Dieser Bericht f�hrt die Produkte auf, die auf Ihrer Website am h�ufigsten verkauft wurden. Au�erdem wird der jeweilige Anteil am Gesamtumsatz und ein relatives Balkendiagramm f�r einen schnellen �berblick angezeigt. Zusammen mit allen Produkten in der Liste wird auch die jeweilige Kategorie (sofern zutreffend) des Produkts angegeben.");

parent.ssLoad(108,"Produktbaum: Dieser Bericht enth�lt die Topkategorien der verkauften Produkte. Neben jedem Produkt befindet sich ein kleiner blauer Pfeil, auf den Sie klicken k�nnen, um Unterkategorien (sofern zutreffend) und die eigentlichen Produkte anzuzeigen.");

parent.ssLoad(109,"Regionen: Dieser Bericht enth�lt die Regionen, aus denen die meisten K�ufer  kommen. Durch Klicken auf den kleinen blauen Pfeil neben dem jeweiligen Eintrag werden Teilregionen angezeigt. Neben jedem Eintrag befindet sich der zugeh�rige Dollargesamtwert sowie ein Balkendiagramm, das die relative Bedeutung der jeweiligen Region nach Umsatz angibt.");
parent.ssLoad(110,"Besuchsdauer");
parent.ssLoad(111,"Besuchsdauer: Dieser Bericht enth�lt die Zeitdauer, welche die Besucher im Durchschnitt auf Ihrer Site verbracht haben. Hinweis: Die Zeitsegmente f�r jedes Grafikelement nehmen auf der X-Achse zu.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/223.html\">klicken Sie hier</A>.");
parent.ssLoad(112,"Besuchergesamtzahl");
parent.ssLoad(113,"Gesamtzahl der Seitenansichten");
parent.ssLoad(114,"Gesamttreffer");
parent.ssLoad(115,"Insgesamt �bertragene Byte");
parent.ssLoad(116,"Durchschnittliche Besucher pro Tag");
parent.ssLoad(117,"Durchschnittliche Seitensansichten pro Tag");
parent.ssLoad(118,"Durchschnittliche Treffer pro Tag");
parent.ssLoad(119,"Durchschnittlich pro Tag �bertragene Byte");
parent.ssLoad(120,"Durchschnittliche Seitenansichten pro Besucher");
parent.ssLoad(121,"Durchschnittliche Treffer pro Besucher");
parent.ssLoad(122,"Durchschnittliche Byte pro Besucher");
parent.ssLoad(123,"Durchschnittliche Besuchsdauer");
parent.ssLoad(124,"Gesamtbereich");
parent.ssLoad(125,"Tagesdurchschnitt");
parent.ssLoad(126,"Stundendurchschnitt");
parent.ssLoad(128,"Monatsdurchschnitt");
parent.ssLoad(129,"System");
parent.ssLoad(130,"Top-Sites");
parent.ssLoad(131,"Top-Sites: In dieser Tabelle werden die Websites auf Ihrem Server eingestuft.");
parent.ssLoad(132,"Top-Server");
parent.ssLoad(133,"Top-Server: In dieser Tabelle werden die zum Lastausgleich verwendeten Server eingestuft.<P>Wenn Sie n�here Informationen w�nschen, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/gr30/205a.html\">klicken Sie hier</A>.");
parent.ssLoad(134,"Top-Shops");
parent.ssLoad(135,"Top-Shops: Wenn Ihr E-Commerce-System aus mehreren Shops besteht, werden hier die Shops nach Ums�tzen und nach Bestellungen eingestuft.");
parent.ssLoad(136,"Gesamtumsatz (USD)");
parent.ssLoad(137,"Umsatzdurchschnitt pro Tag (USD)");
parent.ssLoad(138,"Umsatzdurchschnitt pro Besucher (USD)");
parent.ssLoad(139,"Eingegebene Formulare");
parent.ssLoad(140,"Eingegebene Formulare: Dieser Bericht enth�lt eine Liste der  auf Ihrer Site am h�ufigsten verwendeten Formulare. Die Liste gibt den Formular-Handler an, wie z. B. ein CGI-Skript. Es werden nur Formular-Handler aufgef�hrt, welche die Methode POST verwenden.");
parent.ssLoad(141,"Januar");
parent.ssLoad(142,"Februar");
parent.ssLoad(143,"M�rz");
parent.ssLoad(144,"April");
parent.ssLoad(145,"Mai");
parent.ssLoad(146,"Juni");
parent.ssLoad(147,"Juli");
parent.ssLoad(148,"August");
parent.ssLoad(149,"September");
parent.ssLoad(150,"Oktober");
parent.ssLoad(151,"November");
parent.ssLoad(152,"Dezember");
parent.ssLoad(153,"Vom")
parent.ssLoad(154,"Bis")
parent.ssLoad(155,"Mo")
parent.ssLoad(156,"Di")
parent.ssLoad(157,"Mi")
parent.ssLoad(158,"Do")
parent.ssLoad(159,"Fr")
parent.ssLoad(160,"Sa")
parent.ssLoad(161,"So")
parent.ssLoad(162,"Jan");
parent.ssLoad(163,"Feb");
parent.ssLoad(164,"M�rz");
parent.ssLoad(165,"Apr");
parent.ssLoad(166,"Mai");
parent.ssLoad(167,"Juni");
parent.ssLoad(168,"Juli");
parent.ssLoad(169,"Aug");
parent.ssLoad(170,"Sep");
parent.ssLoad(171,"Okt");
parent.ssLoad(172,"Nov");
parent.ssLoad(173,"Dez");
parent.ssLoad(174,"sek");
parent.ssLoad(175,"seiten");
parent.ssLoad(176,"min");
parent.ssLoad(177,"Berichtsvorgaben f�r");
parent.ssLoad(178,"Seriennummer");
parent.ssLoad(179,"Lizenzummer");
parent.ssLoad(180,"Sprache");
parent.ssLoad(181,"�bernehmen");
parent.ssLoad(182,"chinesische") 
parent.ssLoad(183,"englische") 
parent.ssLoad(184,"franz�sische") 
parent.ssLoad(185,"deutsche") 
parent.ssLoad(186,"italienische") 
parent.ssLoad(187,"japanische") 
parent.ssLoad(188,"koreanische") 
parent.ssLoad(189,"portugese") 
parent.ssLoad(190,"spanische") 
parent.ssLoad(191,"swedish") 
parent.ssLoad(192,"200: OK");
parent.ssLoad(193,"201: Created");
parent.ssLoad(194,"202: Accepted");
parent.ssLoad(195,"203: Non-Authorative Information");
parent.ssLoad(196,"204: No Content");
parent.ssLoad(197,"205: Reset Content");
parent.ssLoad(198,"206: Partial Content");

parent.ssLoad(199,"300: Multiple Choices");
parent.ssLoad(200,"301: Moved Permanently");
parent.ssLoad(201,"302: Found");
parent.ssLoad(202,"303: See Other");
parent.ssLoad(203,"304: Not Modified");
parent.ssLoad(204,"305: Use Proxy");

parent.ssLoad(205,"400: Bad Request");
parent.ssLoad(206,"401: Authorization Required");
parent.ssLoad(207,"402: Payment Required");
parent.ssLoad(208,"403: Forbidden");
parent.ssLoad(209,"404: Not Found");
parent.ssLoad(210,"405: Method Not Allowed");
parent.ssLoad(211,"406: Not Acceptable (encoding)");
parent.ssLoad(212,"407: Proxy Authentication Required");
parent.ssLoad(213,"408: Request Timed Out");
parent.ssLoad(214,"409: Conflicting Request");
parent.ssLoad(215,"410: Gone");
parent.ssLoad(216,"411: Content Length Required");
parent.ssLoad(217,"412: Precondition Failed");
parent.ssLoad(218,"413: Request Entity Too Long");
parent.ssLoad(219,"414: Request URI Too Long");
parent.ssLoad(220,"415: Unsupported Media Type");
parent.ssLoad(221,"416: Requested Range Not Satisfiable");
parent.ssLoad(222,"417: Expectation Failed");

parent.ssLoad(223,"500: Internal Server Error");
parent.ssLoad(224,"501: Not Implemented");
parent.ssLoad(225,"502: Bad Gateway");
parent.ssLoad(226,"503: Service Unavailable");
parent.ssLoad(227,"504: Gateway Timeout");
parent.ssLoad(228,"505: HTTP Version Not Supported");

parent.ssLoad(229,"Click Path From");
parent.ssLoad(230,"Click Through Page");
parent.ssLoad(231,"Clicks");
parent.ssLoad(232,"The Click Paths shows how people navigated through your site. From any one page, this chart shows how many times people clicked on the various links in the page. To see where people went next, click on a link of a particular page.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/221.html\">click here</A>.");
parent.ssLoad(233,"Date Range");
parent.ssLoad(234,"Help Information");
parent.ssLoad(235,"Percent");
