parent.ssLoad( 0,"Reports");
parent.ssLoad( 1,"Traffic");
parent.ssLoad( 2,"Snapshot");
parent.ssLoad( 3,"Hourly Graph");
parent.ssLoad( 4,"Daily Graph");
parent.ssLoad( 5,"Monthly Graph");
parent.ssLoad( 6,"Pages");
parent.ssLoad( 7,"Top Pages");
parent.ssLoad( 8,"Directory Tree");
parent.ssLoad( 9,"File Types");
parent.ssLoad(10,"Status/Errors");
parent.ssLoad(11,"Referrals");
parent.ssLoad(12,"Top Referrals");
parent.ssLoad(13,"Top Keywords");
parent.ssLoad(14,"Referral Tree");
parent.ssLoad(15,"Keyword Tree");
parent.ssLoad(16,"Search Engines");
parent.ssLoad(17,"Domains");
parent.ssLoad(18,"Top Domains");
parent.ssLoad(19,"Domain Tree");
parent.ssLoad(20,"Top Countries");
parent.ssLoad(21,"Top ISPs");
parent.ssLoad(22,"Browsers");
parent.ssLoad(23,"Browser Tree");
parent.ssLoad(24,"Platform Tree");
parent.ssLoad(25,"Top Combos");
parent.ssLoad(26,"Tracking");
parent.ssLoad(27,"Top Entrances");
parent.ssLoad(28,"Top Exits");
parent.ssLoad(29,"Click Through");
parent.ssLoad(30,"Depth of Visit");
parent.ssLoad(31,"E-Commerce");
parent.ssLoad(32,"Totals");
parent.ssLoad(33,"Top Products");
parent.ssLoad(34,"Product Tree");
parent.ssLoad(35,"Regions");
parent.ssLoad(36,"Date Range");
parent.ssLoad(37,"Day");
parent.ssLoad(38,"Week");
parent.ssLoad(39,"Month");
parent.ssLoad(40,"Year");
parent.ssLoad(41,"Enter Range");
parent.ssLoad(42,"Controls");
parent.ssLoad(43,"Preferences");
parent.ssLoad(44,"Export Data");
parent.ssLoad(45,"Invert");
parent.ssLoad(46,"Help");
parent.ssLoad(47,"Summary");
parent.ssLoad(48,"Daily Average");
parent.ssLoad(49,"Change");
parent.ssLoad(50,"Usernames");
parent.ssLoad(51,"Visitors");
parent.ssLoad(52,"Pageviews");
parent.ssLoad(53,"Hits");
parent.ssLoad(54,"Bytes");
parent.ssLoad(55,"Time");
parent.ssLoad(56,"Revenue");
parent.ssLoad(57,"Totals");
parent.ssLoad(58,"Per Visitor");
parent.ssLoad(59,"Report");
parent.ssLoad(60,"View By");
parent.ssLoad(61,"Report for");
parent.ssLoad(62,"Shown");
parent.ssLoad(63,"Previous");
parent.ssLoad(64,"Percent");
parent.ssLoad(65,"Next");
parent.ssLoad(66,"Help Information");
parent.ssLoad(67,"<B>! Unlicensed:</B> This reporting feature requires an Urchin License.  Domain based licenses for individual sites are available on-line for $199.  To license this site and activate all the reports now, click <A CLASS=normal HREF=\"javascript:parent.getLicense();\">here</A>.");
parent.ssLoad(68,"Report Disabled");
parent.ssLoad(69,"of");

parent.ssLoad(70,"Snapshot: The Snapshot is a quick look at the recent activity on your website. The bar graph elements represent Visitors by default, and can be toggled to Pageviews, Hits, or Bytes transferred (bandwidth).  If you have the e-Urchin e-commerce module installed, a Revenue tab will also be displayed, allowing you to view this and most other reports' information in terms of actual money spent on your site. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/201.html\">click here</A>.");

parent.ssLoad(71,"Summary: The Summary report is a simple numerical tally of the traffic to your site for the current date range.  Sections include Totals, Averages, and Averages per Visitor.  Tip: to compare this data to another time period, open a new browser window, go to your report, and enter a new date range. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/202.html\">click here</A>.");

parent.ssLoad(72,"Hourly Graph: This graph shows the traffic to your site based on hour of the day.  The graph reports on an entire month's activity in terms of Visitors.  The bar graph elements can be toggled to Pageviews, Hits, or Bytes transferred (bandwidth).  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/203.html\">click here</A>.");

parent.ssLoad(73,"Daily Graph: This graph shows the traffic to your site per day over the specified time period. Use the date range function to specify a different range.  The bar graph elements represent Visitors by default, and can be toggled to Pageviews, Hits, or Bytes transferred (bandwidth).  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/204.html\">click here</A>.");

parent.ssLoad(74,"Monthly Graph: This graph shows the traffic to your site on a per-month basis over the last 12 months. If your site has been operational for less than that amount of time, the months for which data is available are reported on. The bar graph elements represent Visitors by default, and can be toggled to Pageviews, Hits, or Bytes transferred (bandwidth). <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/205.html\">click here</A>.");

parent.ssLoad(75,"Top Pages: This report shows the top 10 pages visited on your site, and graphs each by relative percentage. The number of pages shown on this report can be controlled by changing the value in the Shown area.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/206.html\">click here</A>.");

parent.ssLoad(76,"Directory Tree: This report lists each directory (sometimes called a folder) in your site and the pages within it that have been accessed. To see these pages, just click on the small arrow next to each entry, and the menu will be expanded. The number of directories shown on this report can be controlled by changing the value in the Shown area. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/207.html\">click here</A>.");

parent.ssLoad(77,"File Types: This report shows the types of files that were accessed on your site, such as GIF images, HTML files, or CGI scripts. It's interesting to view this report in terms of Hits (server requests) vs. Bytes in order to see which types of files are using the most network resources. The number of file types shown on this report can be controlled by changing the value in the Shown area. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/208.html\">click here</A>.");

parent.ssLoad(78,"Status/Errors: This report shows the status code of each response.  The 400s represent errors including files not found.  Click on the small arrow to see more details on the errors. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/1204.html\">click here</A>.");

parent.ssLoad(79,"Top Referrals: This report lists the actual addresses (URLs) of the webpages that have links to your site that were clicked on. This will most likely include search engines and other directory sites. The number of referrals shown on this report can be controlled by changing the value in the Shown area.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/209.html\">click here</A>.");

parent.ssLoad(80,"Top Keywords: This report lists the actual keywords people typed into search engines to find your site.   This report helps you assess whether the keywords expected to lead people to your site are having the desired effect.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/211.html\">click here</A>.");

parent.ssLoad(81,"Referral Tree: This report lists the top domains that brought visitors to your site. The small blue arrow next to each entry can be clicked on to reveal the actual pages containing the links people clicked on. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/210.html\">click here</A>.");

parent.ssLoad(82,"Keyword Tree: This very useful report lists the top search engines people used to find your site.  By clicking on the small arrow next to each entry, you can see the actual keywords used on that particular search engine to successfully find your site.  The number of entries shown on this report can be changed by entering a new value in the \"Shown\" box and pressing Enter on your keyboard. This report can be toggled between Visitors, Pageviews, Hits, Bytes transferred (bandwidth), and Time.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/212.html\">click here</A>.");

parent.ssLoad(83,"Search Engines: This report lists each search engine that was successfully used to find your site. By clicking on the small blue arrow next to each entry, you can see the actual keywords people typed.  For a webmaster, this is one of Urchin's most useful reports.  It  shows you precisely how well your site is registered on the search engines, and which keywords are bringing you traffic.  This can be very useful if you have recently registered or changed the content of your site. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/212.html\">click here</A>.");

parent.ssLoad(84,"Top Domains: This handy report shows you what networks your site visitors came from. Urchin can resolve most networks, but some will always be unresolved, meaning the network could not be identified. This information is very important for tailoring your website, as some visitors may have browsers with different capabilities. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/213.html\">click here</A>.");

parent.ssLoad(85,"Domain Tree: This report lists the top-level domains, such as .com and .net, that your site's visitors came from. By clicking the small arrow next to each entry, you can see the actual networks under each top-level domain. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/214.html\">click here</A>.");

parent.ssLoad(86,"Top Countries: This report lists top level domains with an emphasis on political affiliation. Since the bulk of web traffic is from net, com, and org domains, and these are mostly US-based, they are included. The rest will be primarily actual country codes.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/215.html\">click here</A>.");

parent.ssLoad(87,"Top ISPs: This report lists the top <B>major</B> ISPs, such as earthlink.net, whose customers have visited your site.  The number of entries shown on this report can be changed by entering a new value in the \"Shown\" box and pressing Enter on your keyboard. This report can be toggled between Visitors, Pageviews, Hits, Bytes transferred (bandwidth), and Time.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/topisps.html\">click here</A>.");

parent.ssLoad(88,"Browser Tree: This report lists the top browsers, such as Netscape Navigator and Microsoft Internet Explorer, that people used to visit your site. You will also see robots, such as those used by search engines to find website content, and other types of automated internet programs listed. By clicking the arrow next to each entry, you can see the versions of each particular browser or agent. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/216.html\">click here</A>.");

parent.ssLoad(89,"Platform Tree: This report lists the top computer platforms, such as Windows, Macintosh, and Unix, that people used to visit your site. By clicking on the arrow next to each entry, you can see the versions of each platform used, such as Windows 98 or FreeBSD. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/217.html\">click here</A>.");

parent.ssLoad(90,"Top Combos: This report combines the Browser and Platform reports and produces a list of the most commonly used computer setups used to view your site. Examples would include Explorer 5/Windows 98 and Mac PPC/Netscape 4. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/218.html\">click here</A>.");

parent.ssLoad(91,"Top Entrances: This report lists the top pages people first arrived at within your site. This will usually be something like index.html or default.html, which are the most common home page names. There will also be pages listed that may have been linked from other sites or bookmarked for quick access. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/219.html\">click here</A>.");

parent.ssLoad(92,"Top Exits: This report lists the pages that were most commonly visited last before people left your site.  It's important to study this report in order to improve visitor retention, or stickiness. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/220.html\">click here</A>.");

parent.ssLoad(93,"Click Through: This report lists the top paths people took in travelling through your site, sorted by the initial page visited. By clicking each entry, you can view the next pages in the paths taken by your visitors, and so on. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/221.html\">click here</A>.");

parent.ssLoad(94,"Length of Visit: This report shows the duration that visitors spent on your site on average.  Note: the time segments for each graph element increase along the 'x' axis. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/223.html\">click here</A>.");

parent.ssLoad(95,"Depth: This graph illustrates the depth to which visitors travelled within your site, displayed by number of pages visited.  This report is very useful for evaluating the pertinence of your content to your visitors. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/222.html\">click here</A>.");

parent.ssLoad(96,"Visitors");
parent.ssLoad(97,"Pages/Visitor");
parent.ssLoad(98,"Hits/Visitor");
parent.ssLoad(99,"Bytes/Visitor");
parent.ssLoad(100,"Time/Visitor");
parent.ssLoad(101,"Revenue/Visitor");

parent.ssLoad(102,"Usernames: This report lists the top usernames that were used during any authentication process required by your site. If you do not require a password, then no usernames are listed.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/224.html\">click here</A>.");

parent.ssLoad(103,"Server Report");
parent.ssLoad(104,"Site Rankings");
parent.ssLoad(105,"Server Rankings");

parent.ssLoad(106,"Totals: This report shows basic sales information for the selected Date Range. The total value of sales is shown along with averages per visitor and per day. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/totals.html\">click here</A>.");

parent.ssLoad(107,"Top Products: This report lists the top items sold on your website, along with the percent of total sales each represents, and a relative bar graph for quick visual indication. Along with each item in the list, the category (if applicable) for the item is listed. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/topproducts.html\">click here</A>.");

parent.ssLoad(108,"Product Tree: This report lists the top categories of items sold. Next to each item is a small blue arrow that can be clicked to reveal subcategories (if applicable) and the items themselves. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/producttree.html\">click here</A>.");

parent.ssLoad(109,"Regions: This report lists the top regions where buyers from your site came from.  By clicking the small blue arrow next to each entry, the subregions can be seen. Next to each entry is the total monetary value it represents, and a bar graph indicating the relative importance by sales of each region. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/regions.html\">click here</A>.");
parent.ssLoad(110,"Length of Visit");
parent.ssLoad(111,"Length of Visit: This report shows the duration that visitors spent on your site on average.  Note: the time segments for each graph element increase along the 'x' axis. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/223.html\">click here</A>.");
parent.ssLoad(112,"Total Visitors");
parent.ssLoad(113,"Total Pageviews");
parent.ssLoad(114,"Total Hits");
parent.ssLoad(115,"Total Bytes Transferred");
parent.ssLoad(116,"Average Visitors Per Day");
parent.ssLoad(117,"Average Pageviews Per Day");
parent.ssLoad(118,"Average Hits Per Day");
parent.ssLoad(119,"Average Bytes Transferred Per Day");
parent.ssLoad(120,"Average Pageviews Per Visitor");
parent.ssLoad(121,"Average Hits Per Visitor");
parent.ssLoad(122,"Average Bytes Per Visitor");
parent.ssLoad(123,"Average Length of Visit");
parent.ssLoad(124,"Range Total");
parent.ssLoad(125,"Daily Average");
parent.ssLoad(126,"Hourly Average");
parent.ssLoad(128,"Monthly Average");
parent.ssLoad(129,"System");
parent.ssLoad(130,"Top Sites");
parent.ssLoad(131,"Top Sites: This table ranks the websites on your server.");
parent.ssLoad(132,"Log Files");
parent.ssLoad(133,"Log Files: This table ranks the top logfiles processed for this site.  These may be transfer, error, and e-commerce logs (one of each), or multiple transfer logs representing the same time period in multihomed (load balanced) installations. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/server.html\">click here</A>.");;
parent.ssLoad(134,"Top Stores");
parent.ssLoad(135,"Top Stores: If you have multiple stores in your e-commerce system, this report will rank those stores by revenue generated and orders. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/topstores.html\">click here</A>.");
parent.ssLoad(136,"Total Revenue");
parent.ssLoad(137,"Average Revenue Per Day");
parent.ssLoad(138,"Average Revenue Per Visitor");
parent.ssLoad(139,"Posted Forms");
parent.ssLoad(140,"Posted Forms: This report shows a list of the top forms used on your site.  The list actually indicates the form handler such as a CGI script.  Only form handlers that use the POST method are listed. <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/postedforms.html\">click here</A>.");
parent.ssLoad(141,"January");
parent.ssLoad(142,"February");
parent.ssLoad(143,"March");
parent.ssLoad(144,"April");
parent.ssLoad(145,"May");
parent.ssLoad(146,"June");
parent.ssLoad(147,"July");
parent.ssLoad(148,"August");
parent.ssLoad(149,"September");
parent.ssLoad(150,"October");
parent.ssLoad(151,"November");
parent.ssLoad(152,"December");
parent.ssLoad(153,"From");
parent.ssLoad(154,"To");
parent.ssLoad(155,"Mon");
parent.ssLoad(156,"Tue");
parent.ssLoad(157,"Wed");
parent.ssLoad(158,"Thu");
parent.ssLoad(159,"Fri");
parent.ssLoad(160,"Sat");
parent.ssLoad(161,"Sun");
parent.ssLoad(162,"Jan");
parent.ssLoad(163,"Feb");
parent.ssLoad(164,"Mar");
parent.ssLoad(165,"Apr");
parent.ssLoad(166,"May");
parent.ssLoad(167,"Jun");
parent.ssLoad(168,"Jul");
parent.ssLoad(169,"Aug");
parent.ssLoad(170,"Sep");
parent.ssLoad(171,"Oct");
parent.ssLoad(172,"Nov");
parent.ssLoad(173,"Dec");
parent.ssLoad(174,"sec");
parent.ssLoad(175,"pages");
parent.ssLoad(176,"min");
parent.ssLoad(177,"Report Preferences for");
parent.ssLoad(178,"Serial Number");
parent.ssLoad(179,"License Code");
parent.ssLoad(180,"Language");
parent.ssLoad(181,"Apply Preferences");
parent.ssLoad(182,"chinese");
parent.ssLoad(183,"english");
parent.ssLoad(184,"french");
parent.ssLoad(185,"german");
parent.ssLoad(186,"italian");
parent.ssLoad(187,"japanese");
parent.ssLoad(188,"korean");
parent.ssLoad(189,"portuguese");
parent.ssLoad(190,"spanish");
parent.ssLoad(191,"swedish");
parent.ssLoad(192,"200: OK");
parent.ssLoad(193,"201: Created");
parent.ssLoad(194,"202: Accepted");
parent.ssLoad(195,"203: Non-Authorative Information");
parent.ssLoad(196,"204: No Content");
parent.ssLoad(197,"205: Reset Content");
parent.ssLoad(198,"206: Partial Content");
parent.ssLoad(199,"300: Multiple Choices");
parent.ssLoad(200,"301: Moved Permanently");
parent.ssLoad(201,"302: Found");
parent.ssLoad(202,"303: See Other");
parent.ssLoad(203,"304: Not Modified");
parent.ssLoad(204,"305: Use Proxy");
parent.ssLoad(205,"400: Bad Request");
parent.ssLoad(206,"401: Authorization Required");
parent.ssLoad(207,"402: Payment Required");
parent.ssLoad(208,"403: Forbidden");
parent.ssLoad(209,"404: Not Found");
parent.ssLoad(210,"405: Method Not Allowed");
parent.ssLoad(211,"406: Not Acceptable (encoding)");
parent.ssLoad(212,"407: Proxy Authentication Required");
parent.ssLoad(213,"408: Request Timed Out");
parent.ssLoad(214,"409: Conflicting Request");
parent.ssLoad(215,"410: Gone");
parent.ssLoad(216,"411: Content Length Required");
parent.ssLoad(217,"412: Precondition Failed");
parent.ssLoad(218,"413: Request Entity Too Long");
parent.ssLoad(219,"414: Request URI Too Long");
parent.ssLoad(220,"415: Unsupported Media Type");
parent.ssLoad(221,"416: Requested Range Not Satisfiable");
parent.ssLoad(222,"417: Expectation Failed");
parent.ssLoad(223,"500: Internal Server Error");
parent.ssLoad(224,"501: Not Implemented");
parent.ssLoad(225,"502: Bad Gateway");
parent.ssLoad(226,"503: Service Unavailable");
parent.ssLoad(227,"504: Gateway Timeout");
parent.ssLoad(228,"505: HTTP Version Not Supported");

parent.ssLoad(229,"Click Path From");
parent.ssLoad(230,"Click Through Page");
parent.ssLoad(231,"Clicks");
parent.ssLoad(232,"The Click Paths shows how people navigated through your site. From any one page, this chart shows how many times people clicked on the various links in the page. To see where people went next, click on a link of a particular page.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/221.html\">click here</A>.");
parent.ssLoad(233,"Date Range");
parent.ssLoad(234,"Help Information");
parent.ssLoad(235,"Percent");
