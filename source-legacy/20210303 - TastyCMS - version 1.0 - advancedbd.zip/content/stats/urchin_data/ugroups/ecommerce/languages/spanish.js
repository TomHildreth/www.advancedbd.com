parent.ssLoad( 0,"Informe de sitio");
parent.ssLoad( 1,"Tr�fico");
parent.ssLoad( 2,"Instant�nea");
parent.ssLoad( 3,"Gr�fico horario");
parent.ssLoad( 4,"Gr�fico diario");
parent.ssLoad( 5,"Gr�fico mensual");
parent.ssLoad( 6,"P�ginas");
parent.ssLoad( 7,"P�ginas principales");
parent.ssLoad( 8,"�rbol de directorio");
parent.ssLoad( 9,"Tipos de archivo");
parent.ssLoad(10,"Estado/Errores");
parent.ssLoad(11,"Referencias");
parent.ssLoad(12,"Referencias principales");
parent.ssLoad(13,"Palabras clave principales");
parent.ssLoad(14,"�rbol de referencias");
parent.ssLoad(15,"�rbol de claves");
parent.ssLoad(16,"Buscadores           ");
parent.ssLoad(17,"Dominios");
parent.ssLoad(18,"Dominios principales");
parent.ssLoad(19,"�rbol de dominios");
parent.ssLoad(20,"Pa�ses principales");
parent.ssLoad(21,"ISPs principales");
parent.ssLoad(22,"Navegadores");
parent.ssLoad(23,"�rbol de navegadores");
parent.ssLoad(24,"�rbol de plataformas");
parent.ssLoad(25,"Combinaciones principales");
parent.ssLoad(26,"Seguimiento");
parent.ssLoad(27,"Entradas principales");
parent.ssLoad(28,"Salidas principales");
parent.ssLoad(29,"Pas� por");
parent.ssLoad(30,"Detalle de visitas");
parent.ssLoad(31,"Comercio electr�nico");
parent.ssLoad(32,"Totales");
parent.ssLoad(33,"Productos principales");
parent.ssLoad(34,"�rbol de productos");
parent.ssLoad(35,"Regiones");
parent.ssLoad(36,"Fechas");
parent.ssLoad(37,"D�a");
parent.ssLoad(38,"Semana");
parent.ssLoad(39,"Mes");
parent.ssLoad(40,"A�o");
parent.ssLoad(41,"Entrar fechas");
parent.ssLoad(42,"Controles");
parent.ssLoad(43,"Preferencias");
parent.ssLoad(44,"Exportar datos");
parent.ssLoad(45,"Invertir");
parent.ssLoad(46,"Ayuda");
parent.ssLoad(47,"Sumario");
parent.ssLoad(48,"Promedio diario");
parent.ssLoad(49,"Cambiar");
parent.ssLoad(50,"Nombres de usuarios");
parent.ssLoad(51,"Visitantes");
parent.ssLoad(52,"P�ginas vistas");
parent.ssLoad(53,"Peticiones");
parent.ssLoad(54,"Bytes");
parent.ssLoad(55,"Hora");
parent.ssLoad(56,"D�lares");
parent.ssLoad(57,"Totales");
parent.ssLoad(58,"Por visitante");
parent.ssLoad(59,"Informe");
parent.ssLoad(60,"Vista por");
parent.ssLoad(61,"Informe de sitio para");
parent.ssLoad(62,"Se muestra");
parent.ssLoad(63,"Previo");
parent.ssLoad(64,"Por ciento");
parent.ssLoad(65,"Siguiente");
parent.ssLoad(66,"Informaci�n de ayuda");
parent.ssLoad(67,"<B>! Carece de licencia:</B> Esta funci�n del informe requiere una Licencia de Urchin.  Las licencias de dominios para sitios individuales pueden adquirirse en l�nea por $199.  Para obtener la licencia de este sitio y activar todos los informes ahora, haga clic  <A CLASS=normal HREF=\"javascript:parent.getLicense();\">aqu�</A>.");
parent.ssLoad(68,"Informe inhabilitado");
parent.ssLoad(69,"de");

parent.ssLoad(70,"Instant�nea: La Instant�nea muestra la actividad reciente de su sitio. Los elementos del gr�fico de barras representan Visitantes, y pueden alternar con P�ginas vistas, Peticiones o Bytes transferidos (ancho de banda). Si tiene el m�dulo de comercio electr�nico de e-Urchin, tambi�n se mostrar� una ficha de D�lares, que permite ver la informaci�n de �ste y de la mayor�as de los informes en relaci�n a los d�lares gastados en su sitio.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/201.html\">haga clic aqu�</A>.");

parent.ssLoad(71,"Sumario: El informe Sumario es una cuenta num�rica sencilla del tr�fico en su sitio para el per�odo actual. Incluye Totales, Promedios y Promedios por visitante. Sugerencia: Para comparar estos datos con los de otro per�odo, abra una nueva ventana de exploraci�n, vaya a su informe e introduzca otras fechas.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/202.html\">haga clic aqu�</A>.");

parent.ssLoad(72,"Gr�fico horario: Este gr�fico muestra el tr�fico en su sitio seg�n la hora del d�a. El gr�fico indica el n�mero de visitantes de todo el mes. Los elementos del gr�fico de barras pueden alternar con P�ginas vistas,  Peticiones o Bytes transferidos (ancho de banda).<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/203.html\">haga clic aqu�</A>.");

parent.ssLoad(73,"Gr�fico diario: Este gr�fico muestra el tr�fico diario en su sitio durante el per�odo especificado. Use la funci�n Fechas para especificar su alcance. Los elementos del gr�fico de barras representan visitantes, y pueden alternar con P�ginas vistas,  Peticiones o Bytes transferidos (ancho de banda).<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/204.html\">haga clic aqu�</A>.");

parent.ssLoad(74,"Gr�fico mensual: Este gr�fico muestra el tr�fico mensual en su sitio en los �ltimos 12 meses. Si su sitio estuvo en operaciones por menos de 12 meses, se muestran los meses sobre los cuales hay datos disponibles. Los elementos del gr�fico de barras representan visitantes, y pueden alternar con P�ginas vistas,  Peticiones o Bytes transferidos (ancho de banda).<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/205.html\">haga clic aqu�</A>.");

parent.ssLoad(75,"P�ginas principales: Este informe muestra las 10 p�ginas principales visitadas en su sitio, y los gr�ficos de sus porcentajes relativos. Se puede controlar el n�mero de p�ginas mostradas en el informe, cambiando el valor en el �rea Se muestra.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/206.html\">haga clic aqu�</A>.");

parent.ssLoad(76,"�rbol de directorio: Este informe muestra cada directorio (a veces llamado 'carpeta') de su sitio y las p�ginas del sitio que fueron visitadas. Para ver las p�ginas visitadas, haga clic en la flecha peque�a junto a cada entrada, y se expandir� el men�. Se puede controlar el n�mero de directorios mostrados en este informe, cambiando el valor en el �rea Se muestra.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/207.html\">haga clic aqu�</A>.");

parent.ssLoad(77,"Tipos de archivo: Este informe muestra los tipos de archivos consultados en su sitio, tales como im�genes GIF, archivos HTML o guiones CGI. Es interesante ver las Peticiones (solicitudes al servidor) vs. Bytes en el informe para establecer qu� tipo de archivos utilizan mayores recursos de la red. Se puede controlar el n�mero de tipos de archivo mostrados en el informe, cambiando el valor en el �rea Se muestra.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/208.html\">haga clic aqu�</A>.");

parent.ssLoad(78,"Estado/Errores: Este informe muestra el c�digo de estado de cada respuesta. Los n�meros 400 muestran errores, incluyendo los archivos no encontrados. Haga clic en la flecha peque�a para ver m�s detalles sobre los errores.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/1204.html\">haga clic aqu�</A>.");

parent.ssLoad(79,"Referencias principales: Este informe muestra las direcciones reales (URLs) de las p�ginas web utilizadas que tienen enlaces con su sitio. Probablemente incluir� buscadores y otros sitios de directorio. Se puede controlar el n�mero de referencias mostradas en el informe, cambiando el valor en el �rea Se muestra.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/209.html\">haga clic aqu�</A>.");

parent.ssLoad(80,"Palabras clave principales: Este informe muestra las palabras claves principales escritas en los buscadores para encontrar su sitio. Ayuda a establecer si las palabras clave para conducir p�blico a su sitio tienen el efecto deseado.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/211.html\">haga clic aqu�</A>.");

parent.ssLoad(81,"�rbol de referencias: Este informe muestra la lista de dominios principales que trajeron visitantes a su sitio. Si hace clic en la flecha peque�a junto a cada entrada, ver� las p�ginas con enlaces utilizadas por el p�blico.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/210.html\">haga clic aqu�</A>.");

parent.ssLoad(82,"�rbol de claves: Este informe es muy �til y muestra la lista de los buscadores principales utilizados por el p�blico para encontrar su sitio. Si hace clic en la flecha peque�a junto a cada entrada, ver� las palabras clave utilizadas en el buscador para encontrar su sitio. Se puede cambiar el n�mero de entradas mostrado en el informe, cambiando el valor en la casilla \"Se muestra\" y pulsando \"Entrar\" en el teclado. Este informe puede alternar con P�ginas vistas,  Peticiones, Bytes transferidos (ancho de banda) y Hora.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/212.html\">haga clic aqu�</A>.");

parent.ssLoad(83,"Buscadores: Este informe muestra la lista de cada buscador utilizada con �xito para encontrar su sitio. Si hace clic en la flecha peque�a junto a cada entrada, ver� las palabras clave utilizadas por el p�blico. Para un administrador de Web, este es uno de los informes m�s �tiles de Urchin. Muestra exactamente si su sitio est� bien registrado en los buscadores y qu� palabras clave atraen tr�fico a su sitio. Esto puede ser muy �til si registr� o cambi� el contenido de su sitio recientemente.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/212.html\">haga clic aqu�</A>.");

parent.ssLoad(84,"Dominios principales: Este pr�ctico men� muestra desde qu� redes provienen sus visitantes. Urchin puede establecer la identidad de la mayor�a de las redes, pero algunas identidades quedar�n siempre sin establecer. Esta informaci�n es muy importante para el dise�o de su sitio, dado que algunos visitantes pueden contar con navegadores habilitados de forma diferente.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/213.html\">haga clic aqu�</A>.");

parent.ssLoad(85,"�rbol de dominios: Este informe muestra los principales dominios, como \".com\" y \".net\", desde donde se originaron las visitas. Si hace clic en la flecha peque�a junto a cada entrada, ver� las redes debajo de cada domino principal.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/214.html\">haga clic aqu�</A>.");

parent.ssLoad(86,"Pa�ses principales: Este informe muestra los pa�ses principales desde donde su sitio recibi� visitas. Se incluyen los dominios predominantemente estadounidenses (com, net y org) y los exclusivamente estadounidenses (edu, gov y mil). <P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/215.html\">haga clic aqu�</A>.");

parent.ssLoad(87,"ISPs principales: Este informe muestra los <B>principales<B> ISPs (proveedores de servicios de internet) como earthlink.net, de los usuarios que visitaron su sitio. Se puede cambiar el n�mero de entradas mostrado en el informe, introduciendo un nuevo valor en la casilla \"Se muestra\" y pulsando \"Entrar\" en el teclado. Este informe puede alternar con Visitantes, P�ginas vistas, Peticiones, Bytes transferidos (ancho de banda) y Hora.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/topisps.html\">haga clic aqu�</A>.");

parent.ssLoad(88,"�rbol de exploradores: Este informe muestra la lista de los principales exploradores, como Netscape Navigator y Microsoft Internet Explorer, utilizados por los visitantes de su sitio. Tambi�n ver� robots, como los utilizados por buscadores para encontrar el contenido de sitios, y otras clases de programas autom�ticos de internet. Si hace clic en la flecha peque�a junto a cada entrada, podr� ver las versiones de cada navegador o agente en particular.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/216.html\">haga clic aqu�</A>.");

parent.ssLoad(89,"�rbol de plataformas: Este informe muestra la lista de las principales plataformas, como Windows, Macintosh y Unix, utilizadas por los visitantes de su sitio. Si hace clic en la flecha peque�a junto a cada entrada, podr� ver las versiones de cada plataforma utilizada, como Windows 98 � FreeBSD.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/217.html\">haga clic aqu�</A>.");

parent.ssLoad(90,"Combinaciones principales: Este informe combina los informes de navegador y plataforma, y produce una lista de las configuraciones m�s utilizadas por los visitantes de su sitio. Por ejemplo, Explorer 5/Windows 98 y Mac PPC/Netscape 4.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/218.html\">haga clic aqu�</A>.");

parent.ssLoad(91,"Entradas principales: Este informe muestra la lista de las principales p�ginas de llegada de los visitantes de su sitio. Generalmente, las p�ginas ser�n \"index.html\" o \"default.html\", que son los nombres m�s comunes de p�ginas principales. Tambi�n habr� p�ginas en la lista que pueden haber estado enlazadas desde otros sitios o marcadas para acceso r�pido.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/219.html\">haga clic aqu�</A>.");

parent.ssLoad(92,"Salidas principales: Este informe muestra la lista de las p�ginas m�s com�nmente visitadas al final, antes de que los visitantes abandonaran su sitio. Para mejorar la retenci�n de clientes, es importante analizar este informe.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/220.html\">haga clic aqu�</A>.");

parent.ssLoad(93,"Pas� por: Este informe muestra la lista de las rutas principales utilizadas por el p�blico para llegar a su sitio, solicitadas a partir de la p�gina visitada inicialmente. Si hace clic en cada entrada, podr� ver las p�ginas siguientes en las rutas seguidas por los visitantes.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/221.html\">haga clic aqu�</A>.");

parent.ssLoad(94,"Duraci�n de visitas: Este informe muestra el promedio de tiempo empleado por el p�blico para visitar su sitio. Nota: Los segmentos de tiempo de cada elemento gr�fico aumentan a lo largo del eje 'x'.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/223.html\">haga clic aqu�</A>.");

parent.ssLoad(95,"Detalle de visitas: Este informe muestra el detalle de las visitas del p�blico a su sitio, seg�n el n�mero de p�ginas visitadas. Este informe es muy �til para evaluar la pertinencia del contenido para visitantes.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/222.html\">haga clic aqu�</A>.");

parent.ssLoad(96,"Visitantes");
parent.ssLoad(97,"P�ginas/Visitante");
parent.ssLoad(98,"Peticiones/Visitante");
parent.ssLoad(99,"Bytes/Visitante");
parent.ssLoad(100,"Hora/Visitante");
parent.ssLoad(101,"D�lares/Visitante");

parent.ssLoad(102,"Nombres de usuarioss: Este informe muestra la lista de los principales nombres de usuarios utilizados durante cualquier proceso de autenticaci�n exigido por su sitio. Si usted no exige contrase�a, no se muestran los nombres de usuarios.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/224.html\">haga clic aqu�</A>.");

parent.ssLoad(103,"Informe de servidor");
parent.ssLoad(104,"Rankings de sitios");
parent.ssLoad(105,"Rankings de servidores");

parent.ssLoad(106,"Totales: Este informe muestra informaci�n b�sica de ventas para el Per�odo Seleccionado. El importe total de las ventas se muestra junto con los promedios por visitante y por d�a. <P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/totals.html\">haga clic aqu�</A>.");

parent.ssLoad(107,"Productos principales: Este informe muestra la lista de los principales art�culos vendidos en el sitio, junto con el porcentaje del total de ventas que cada uno representa, y un gr�fico de barras relativo para r�pida indicaci�n visual. Junto con cada art�culo de la lista, se indica la categor�a del art�culo (si se aplica). <P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/topproducts.html\">haga clic aqu�</A>.");

parent.ssLoad(108,"�rbol de productos: Este informe muestra la lista de las principales categor�as de art�culos vendidos. Si hace clic en la peque�a flecha azul junto a cada art�culo, ver� las subcategor�as (si se aplica) y los art�culos. <P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/producttree.html\">haga clic aqu�</A>.");

parent.ssLoad(109,"Regiones: Este informe muestra la lista de las principales regiones desde donde sus clientes visitaron su sitio. Si hace clic en la peque�a flecha azul junto a cada entrada, ver� las subregiones. Junto a cada entrada aparece el valor total en d�lares que representa, y un gr�fico de barras relativo a la importancia de las ventas de cada regi�n. <P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/regions.html\">haga clic aqu�</A>.");
parent.ssLoad(110,"Duraci�n de visitas");
parent.ssLoad(111,"Duraci�n de visitas: Este informe muestra el promedio de tiempo empleado por el p�blico para visitar su sitio. Nota: Los segmentos de tiempo de cada elemento gr�fico aumentan a lo largo del eje 'x'.<P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/223.html\">haga clic aqu�</A>.");
parent.ssLoad(112,"Total de visitantes");
parent.ssLoad(113,"Total de p�ginas vistas");
parent.ssLoad(114,"Total de peticiones");
parent.ssLoad(115,"Total de bytes transferidos");
parent.ssLoad(116,"Promedio de visitantes por d�a");
parent.ssLoad(117,"Promedio de p�ginas vistas por d�a");
parent.ssLoad(118,"Promedio de peticiones por d�a");
parent.ssLoad(119,"Promedio de bytes transferidos por d�a");
parent.ssLoad(120,"Promedio de p�ginas vistas por visitante");
parent.ssLoad(121,"Promedio de peticiones por visitante");
parent.ssLoad(122,"Promedio de bytes por visitante");
parent.ssLoad(123,"Promedio de duraci�n de visitas");
parent.ssLoad(124,"Total de las fechas");
parent.ssLoad(125,"Promedio diario");
parent.ssLoad(126,"Promedio horario");
parent.ssLoad(128,"Promedio mensual");
parent.ssLoad(129,"Sistema");
parent.ssLoad(130,"Sitios principales");
parent.ssLoad(131,"Sitios principales: Esta tabla clasifica los sitios Web de su servidor.");
parent.ssLoad(132,"Servidores principales");
parent.ssLoad(133,"Servidores principales: Esta tabla clasifica el servidor utilizado en la compensaci�n de cargas. <P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/server.html\">haga clic aqu�</A>.");

parent.ssLoad(134,"Tiendas principales");
parent.ssLoad(135,"Tiendas principales: Si tiene varias tiendas en su sistema de comercio electr�nico, este informe las ordenar� seg�n el importe en d�lares de las ventas y el n�mero de pedidos. <P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/topstores.html\">haga clic aqu�</A>.");
parent.ssLoad(136,"Total en d�lares");
parent.ssLoad(137,"Promedio diario en d�lares");
parent.ssLoad(138,"Promedio por visitante en d�lares");
parent.ssLoad(139,"Formularios exhibidos");
parent.ssLoad(140,"Formularios exhibidos: Este informe muestra una lista de los principales formularios utilizados en su sitio. La lista indica el manipulador de formularios, tal como un gui�n CGI. S�lo los manipuladores de formularios que utilizan el m�todo POST aparecen en la lista. <P>Para mayor informaci�n, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/sp30/postedforms.html\">haga clic aqu�</A>.");
parent.ssLoad(141,"Enero");
parent.ssLoad(142,"Febrero");
parent.ssLoad(143,"Marzo");
parent.ssLoad(144,"Abril");
parent.ssLoad(145,"Mayo");
parent.ssLoad(146,"Junio");
parent.ssLoad(147,"Julio");
parent.ssLoad(148,"Agosto");
parent.ssLoad(149,"Septiembre");
parent.ssLoad(150,"Octubre");
parent.ssLoad(151,"Noviembre");
parent.ssLoad(152,"Diciembre");
parent.ssLoad(153,"Desde")
parent.ssLoad(154,"Hasta")
parent.ssLoad(155,"Lun")
parent.ssLoad(156,"Mar")
parent.ssLoad(157,"Mie")
parent.ssLoad(158,"Jue")
parent.ssLoad(159,"Vie")
parent.ssLoad(160,"Sab")
parent.ssLoad(161,"Dom")
parent.ssLoad(162,"Ene");
parent.ssLoad(163,"Feb");
parent.ssLoad(164,"Mar");
parent.ssLoad(165,"Abr");
parent.ssLoad(166,"Mayo");
parent.ssLoad(167,"Jun");
parent.ssLoad(168,"Jul");
parent.ssLoad(169,"Ago");
parent.ssLoad(170,"Sep");
parent.ssLoad(171,"Oct");
parent.ssLoad(172,"Nov");
parent.ssLoad(173,"Dic");
parent.ssLoad(174,"seg");
parent.ssLoad(175,"p�ginas");
parent.ssLoad(176,"min");
parent.ssLoad(177,"Se�ale Los Prefernces Para");
parent.ssLoad(178,"N�mero De Serie");
parent.ssLoad(179,"C�digo De La Licencia");
parent.ssLoad(180,"Lenguaje");
parent.ssLoad(181,"Aplique Las Preferencias");
parent.ssLoad(182,"chinos") 
parent.ssLoad(183,"ingleses") 
parent.ssLoad(184,"franceses") 
parent.ssLoad(185,"alemanes") 
parent.ssLoad(186,"italianos") 
parent.ssLoad(187,"japoneses") 
parent.ssLoad(188,"coreanos") 
parent.ssLoad(189,"portugese") 
parent.ssLoad(190,"espa�oles") 
parent.ssLoad(191,"suecos") 
parent.ssLoad(192,"200: OK");
parent.ssLoad(193,"201: Created");
parent.ssLoad(194,"202: Accepted");
parent.ssLoad(195,"203: Non-Authorative Information");
parent.ssLoad(196,"204: No Content");
parent.ssLoad(197,"205: Reset Content");
parent.ssLoad(198,"206: Partial Content");

parent.ssLoad(199,"300: Multiple Choices");
parent.ssLoad(200,"301: Moved Permanently");
parent.ssLoad(201,"302: Found");
parent.ssLoad(202,"303: See Other");
parent.ssLoad(203,"304: Not Modified");
parent.ssLoad(204,"305: Use Proxy");

parent.ssLoad(205,"400: Bad Request");
parent.ssLoad(206,"401: Authorization Required");
parent.ssLoad(207,"402: Payment Required");
parent.ssLoad(208,"403: Forbidden");
parent.ssLoad(209,"404: Not Found");
parent.ssLoad(210,"405: Method Not Allowed");
parent.ssLoad(211,"406: Not Acceptable (encoding)");
parent.ssLoad(212,"407: Proxy Authentication Required");
parent.ssLoad(213,"408: Request Timed Out");
parent.ssLoad(214,"409: Conflicting Request");
parent.ssLoad(215,"410: Gone");
parent.ssLoad(216,"411: Content Length Required");
parent.ssLoad(217,"412: Precondition Failed");
parent.ssLoad(218,"413: Request Entity Too Long");
parent.ssLoad(219,"414: Request URI Too Long");
parent.ssLoad(220,"415: Unsupported Media Type");
parent.ssLoad(221,"416: Requested Range Not Satisfiable");
parent.ssLoad(222,"417: Expectation Failed");

parent.ssLoad(223,"500: Internal Server Error");
parent.ssLoad(224,"501: Not Implemented");
parent.ssLoad(225,"502: Bad Gateway");
parent.ssLoad(226,"503: Service Unavailable");
parent.ssLoad(227,"504: Gateway Timeout");
parent.ssLoad(228,"505: HTTP Version Not Supported");

parent.ssLoad(229,"Click Path From");
parent.ssLoad(230,"Click Through Page");
parent.ssLoad(231,"Clicks");
parent.ssLoad(232,"The Click Paths shows how people navigated through your site. From any one page, this chart shows how many times people clicked on the various links in the page. To see where people went next, click on a link of a particular page.  <P>For more information, <A CLASS=normal TARGET=_blank HREF=\"http://www.urchin.com/help/en30/221.html\">click here</A>.");
parent.ssLoad(233,"Date Range");
parent.ssLoad(234,"Help Information");
parent.ssLoad(235,"Percent");
