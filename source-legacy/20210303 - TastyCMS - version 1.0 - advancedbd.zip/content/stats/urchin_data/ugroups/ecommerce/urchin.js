<!--
//    Copyright (c) 2000 Quantified Systems, Inc. All rights reserved.   
//    The javascript contained herein is the property of Quantified     
//    Systems, Inc., San Diego, CA. It may not be used outside the      
//    Urchin application without written consent.                      
//    -Mutzet                                                         
//
// $Id: urchin.js,v 1.16 2002/02/13 19:32:28 root Exp $

var isMac, isIE, isNav, isVersion;
var ndata,sdata,hdata,pdata,report,tab,nc,ss,ll,gmax,icons;
var startYear=2000;
var navLine=0;

isNav = (navigator.appName == "Netscape") ? true : false;
isIE  = (navigator.appName.indexOf("Microsoft") != -1) ? true : false;
isMac = (navigator.appVersion.indexOf("Mac") != -1) ? true : false;
isVersion = parseInt(navigator.appVersion.charAt(0));
if (((isNav) && (isVersion < 3)) || ((isIE) && (isVersion < 2))) {alert("Warning: Urchin requires at least a 3.0 browser!");}
if (location.href.charAt(location.href.length - 1) == '/') {ll = location.href;}
else {ll = location.href.substring(0,(location.href.lastIndexOf("/")+1));}


function nClear() { ndata = new Array(); }
function dClear() { sdata = new Array(); }
function tClear() { tab = new Array(); }
function ssClear() { ss = new Array(); }
function pClear() { pdata = new Array(); }

function nitem(title,help,level,set,report,type,onoff,onbutton,offbutton,oncolor,offcolor,enabled) {
   this.title     = title;
   this.help      = help;
   this.level     = level;
   this.set       = set;
   this.report    = report;
   this.type      = type
   this.onoff     = onoff;
   this.onbutton  = onbutton;
   this.offbutton = offbutton;
   this.oncolor   = oncolor;
   this.offcolor  = offcolor;
   this.enabled   = enabled;
   return this;
}
function sitem(myname,visitors,pages,hits,bytes,mytime,dollars,prec) {
   this.myname = myname;
   this.isopen = 0;
   this.data = new Array();
   this.data[0] = visitors;
   this.data[1] = pages;
   this.data[2] = hits;
   this.data[3] = bytes;
   this.data[4] = mytime;
   this.data[5] = dollars;
   this.prec = prec;
   return this;
}
function titem(title,onoff,enabled,total) {
   this.title   = title;
   this.onoff   = onoff;
   this.enabled = enabled;
   this.total   = total;

   return this;
}

function pitem(url,page,hits) {
   this.url  = url;
   this.page = page;
   this.data = new Array();
   this.data[0] = hits;
   return this;
}

function ritem() {
   this.title  = "";
   this.language  = "english";
   this.help   = "";
   this.type   = 0;
   this.number = 0;
   this.color  = "";
   this.start  = 0;
   this.mylength = 10;
   this.field  = 0;
   this.perv   = 0;
   this.showhelp = 1;
   this.startdate = 0;
   this.enddate   = 0;
   this.website   = "";
   this.separator = "|";
   this.pervable = 1;
   this.sortable = 1;
   this.enabled = 1;
   this.datetype = 2002;
   this.initdate = 0;
   this.varcode = 0;
   //this.fontFace = "";
   //this.fontSize = "-2";
   this.sortnoreferral = 0;
   this.sortunresolved = 0;
   this.sortother = 1;
   this.sortotherhtml = 1;
   this.colors = new Array();
   this.fonts = new Array();
   this.currency = "dollar";
   return this;
}

function ditem(date) {
   var ndate = date.toString(); 
   this.year = ndate.substring(0,4); 
   this.mon = ndate.substring(4,6); 
   this.day = ndate.substring(6,8); 

   return this;
}

report = new ritem();
var today = new Date();
report.enddate = 20000101;
report.startdate = 20000107;
report.number = 1101;
report.type = 1;

function tLoad(title,onoff,enabled,total) {
   tab[tab.length] = new titem(title,onoff,enabled,total);
}
function ssLoad(i,s) {
   ss[i] = s;
}
function nLoad(title,help,level,set,report,type,onoff,onbutton,offbutton,oncolor,offcolor,enabled) {
   ndata[ndata.length] = new nitem(title,help,level,set,report,type,onoff,onbutton,offbutton,oncolor,offcolor,enabled);
}
function dLoad(myname,visitors,pages,hits,bytes,mytime,dollars,prec) {
   sdata[sdata.length] = new sitem(myname,visitors,pages,hits,bytes,mytime,dollars,prec);
}
function pLoad(url,page,hits) {
   pdata[pdata.length] = new pitem(url,page,hits);
}
function vopen(sss) {
   var mywin = window.open();
   mywin.location = sss;
}
function getLicense() {
   //enable(3001);
   var gi = 'https://secure.quantified.net/buydomain1.cgi?KEYCODE=' + report.website + '&VARCODE='+report.varcode;
   var mywin = window.open(gi);
}
function hLoad() {
   //--creates parent array from sdata.
   hdata = new Array();
   var ss,hotard;
   for (var i=0; i<sdata.length; i++) {
      hotard = 0;

      if (report.number == 1202 && sdata[i].myname == "/") {
         ss = sdata[i].myname;
      } else {
         ss = getfirst(sdata[i].myname);
      }

      for (var j=0; j<hdata.length; j++) {
         if (ss == hdata[j].myname) {
             for (var k=0; k<sdata[i].data.length; k++) hdata[j].data[k] += sdata[i].data[k];
             hotard = 1;
             break;
         }
      }
      if (!hotard) hdata[hdata.length] = new sitem(ss,sdata[i].data[0],sdata[i].data[1],sdata[i].data[2],sdata[i].data[3],sdata[i].data[4],sdata[i].data[5],sdata[i].prec);
   }
}

function sortbyfield(aa,ii) {
   var tnode,h,i,j,f;
   if (aa.length <= 0) return;
   h = 1;
   if (aa.length < 14) h = 1;
   else if (aa.length > 29524) h = 3280;
   else {
       while (h < aa.length) h = 3*h + 1;
       h = Math.round((h/3) - 0.5);
       h = Math.round((h/3) - 0.5);
   }
   //----- Sort-by-insertion in increments of h
   while (h > 0) {
     for (i = h-1; i < aa.length; ++i) {
       tnode = aa[i];
       for (j = i-h; j >= 0; j-=h) {
         if (report.pervable && tnode.myname) {
           if (tnode.data[0] <= aa[j].data[0]) break;
         } else {
           if (tnode.data[ii] <= aa[j].data[ii]) break;
         }
         aa[j+h] = aa[j];
       }
       aa[j+h] = tnode;
     }
     h = Math.round((h/3) - 0.5);
   }

   var fnode = new Array();
   var fc = 0;

   for (i = 0; i < aa.length; ++i) {
      if (   ((aa[i].myname == "(no referral)" || aa[i].myname == "no referral")  && report.sortnoreferral)
          || (aa[i].myname == "/other.html"  && report.sortotherhtml)
          || (aa[i].myname ==  "other.html"  && report.sortotherhtml) 
          || ((aa[i].myname == "(other)" || aa[i].myname == "other")  && report.sortother) 
          || ((aa[i].myname == "(unresolved)" || aa[i].myname == "unresolved") && report.sortunresolved) ) {
          fnode[fc] = aa[i];
          aa[i] = 0;
          fc++;
      }
      if (fnode[0] && aa[i-fc] == 0) { 
         aa[i-fc] = aa[i]; 
         aa[i] = 0;
      }
      //if (aa.length-1 == i+fc) { break; }
   }

   if (fnode[0]) { 
      for (i=0,j=aa.length-1; i < fnode.length;j--,i++) {
         aa[j] = fnode[i];
      }
   }
   return;
}


function reset() {
   if (!isIE) { 
      redraw();
   }
}

function setLength(num) {
   if (num == null || num == "") num = 10;
   report.mylength = 1*num;
   if ((isNav) && (isVersion == 3)) {
      setTimeout("redraw()",1000);
   } else {
      redraw();
   }
}

function setLength2() {
   var form = top.drawframe.document.forms[0];
   var num;
   num = form.elements[0].options[form.elements[0].selectedIndex].value;

   if (num == null || num == "") num = 10;
   report.mylength = 1*num;
   if ((report.pervable) && (report.field == 0)) report.perv = 0;
   if ((report.pervable) && (report.field == 4)) report.perv = 1;
   if ((isNav) && (isVersion == 3)) {
      setTimeout("redraw()",1000);
   } else {
      redraw();
   }
}

function formatTime(mynum) {
   var anum = Math.round(mynum);
   var seconds  = anum % 60;
   var leftover = (anum - seconds)/ 60;
   var minutes  = leftover % 60;
   var hours    = (leftover - minutes)/ 60;

   if (seconds < 10) { seconds = "0" + seconds; }
   if (minutes < 10) { minutes = "0" + minutes; }
   if (hours <10) { hours = "0" + hours; }

   tnum = hours + ":" + minutes + ":" + seconds;
   return tnum;
}
function formatMoney(mynum) {
   if (report.currency == "dollar") {
      var tnum = "$" + addCommas(Math.round(mynum)/100);
   } else if (report.currency == "yen") {
      var tnum = "&yen; " + addCommas(Math.round(mynum)/100);
   } else if (report.currency == "pound") {
      var tnum = "&pound; " + addCommas(Math.round(mynum)/100);
   } else if (report.currency == "euro" && (((isNav) && isVersion > 4) || ((isIE) && isVersion > 3))) {
      var tnum = "&euro; " + addCommas(Math.round(mynum)/100);
   }else {
      var tnum = "" + addCommas(Math.round(mynum)/100); 
   }
   return tnum;
}
function formatNumber(mynum) {
   var x = mynum;
   if (x <= 1024) return x;
   var n,p,start,tnum="",units="";
   if (x >= 1024) {
      units = "KB";
      x = x/1024;
   }
   if (x >= 1024) {
      units = "MB";
      x = x/1024;
   }
   if (x >= 1024) {
      units = "GB";
      x = x/1024;
   }
   if (x >= 1024) {
      units = "TB";
      x = x/1024;
   }
   var ii = 0;
   while(x < 1000) {
      x *= 10;
      ii++;
   }
   x = Math.round(x);
   var y = new Number(x);
   var n = y.toString();
   var s = n.substring(0,n.length - ii);
   var e = n.substring(n.length - ii,n.length);
   var dot = ".";
   if ((report.language != "english") && ((report.language != "english-uk")) &&
       (report.language != "korean") && 
       (report.language != "chinese") && 
       (report.language != "japanese")) {dot = ",";}
   if (e == "") {dot = "";}
   tnum = s + dot + e + units;
   return tnum;
}

function addCommas(mynum) {
   if (((isNav) && (isVersion < 3)) || ((isIE) && (isVersion < 2))) {return mynum;}

   if (report.language == "italian" || report.language == "portuguese" || report.language == "spanish" || report.language == "german")  {
      var s = ".";
      var t = ",";
   } else if (report.language == "french" || report.language == "swedish")  {
      var s = " ";
      var t = ",";
   } else {
      var s = ",";
      var t = ".";
   }

   var x = new Number(mynum);
   var n = x.toString();
   var c = n.charAt(0);
   if ((c < "0" || c > "9") && (c != ".")) {return mynum;}
   if (n.indexOf(".") > 0) {
     var start = n.indexOf(".");
     var added = t + n.substring(start+1,n.length);
     }
   else {
     var start = n.length;
     var added = "";
     }
   for (var p = start ; p > 3 ; p-=3) {
      //added = "." + n.substring(p-3,p) + added;
      added = s + n.substring(p-3,p) + added;
   }
   added = n.substring(0,p) + added;
   return added;
}

function formatMax() {
   var x,y,i;
   i = 0;
   x = gmax * 1.09;
   while (x>10) {
      x = x/10;
      i++;
   }
   y = Math.floor(x);
   if ((x-y) > .5) y = y+1;
   else if (x != y) y = y+0.5;
   while (i>0) {
      y = y * 10;
      i--;
   }
   gmax = y;
   if (gmax == 0) gmax = 1;
}

function disable(x) {

   if (x == 1101 || x == 1100) return;
   if (x == 2000) return;

   for (var i=0;i<ndata.length;i++) {
      if (ndata[i].report == x) {
         ndata[i].enabled = 0;
         ndata[i].onoff = 0;
      }
   }
   if ((x % 100) == 0) {
      var y = x/100;
      var z = 0;
      for (var i=1;i<ndata.length;i++) {
         z = parseInt(ndata[i].report / 100);
         if (y == z) {
            ndata[i].enabled=0;
            ndata[(i-1)].enabled=0;
         }
      }
   }
}

function enable(x) {
   for (var i=0;i<ndata.length;i++) {
      if (ndata[i].report == x) ndata[i].enabled = 1;
   }
}

function upsell(x) {
   for (var i=0;i<ndata.length;i++) {
      if (ndata[i].report == x) ndata[i].enabled = 2;
   }
}
function ndataFind(x) {
   for (var i=0;i<ndata.length;i++) {
      if (ndata[i].report == x) return ndata[i];
   }
   return 0; 
}

function loadData() {
   if (report.enabled == 2) doneLoading();
   else top.drawframe.location.href = ll+"index.cgi?r="+report.number+"&b="+report.startdate+"&e="+report.enddate+"&t="+report.type+"&f="+report.field;


}

function nToggle(nn) {
   var ii = nn;
   if (ndata[ii].enabled == 0) return;
   var year, mon, day;

   var wasonoff = ndata[ii].onoff;
   if (ndata[ii].set > 0) {
      for (var i=0;i<ndata.length;i++) {
         if (ndata[i].set == ndata[ii].set) { ndata[i].onoff = 0; }
      }
   }
   if (ndata[ii].report < 3000) {
      if (ndata[ii].report > 0) { 
         ndata[ii].onoff = 1; 
      } else { 
         if (ndata[ii].set == 1) {
            ndata[ii].onoff = 1;
            ii++;
            while(ndata[ii].enabled == 0 && ndata[ii].report != 0 && ndata[ii].report < 3000 && ii < ndata.length) { ii++; }
            if (ndata[ii].report != 0) nToggle(ii);
            return;
         } else {
            ndata[ii].onoff = 1 - wasonoff;
         }
      }
   }

   if ((ndata[ii].report > 1000) & (ndata[ii].report < 2000)) {
      if ((report.number == 1105) && (report.datetype == 2004) && (ndata[ii].report > 1105) && (ndata[ii].report < 2000)) {
         var z = new ditem(report.initdate);
         report.startdate = "" + z.year + z.mon + "01"; 
         report.enddate = "" + z.year + z.mon + getLastDay(z.mon,z.year);

         report.datetype = 2003;
      }

      report.sortable=1;
      report.pervable=1;
      report.number = ndata[ii].report;
      report.type = ndata[ii].type;
      report.enabled = ndata[ii].enabled;

      if (report.number == 1101) {
         report.datetype = 2002;
         report.showhelp = 1;
         top.drawframe.location.href = ll+"index.cgi?r="+report.number;
         return;
      } else if (report.number == 1102) { 
         if (report.datetype == 2004) {
            var z = new ditem(report.initdate);
            report.startdate = "" + z.year + z.mon + "01"; 
            report.enddate = "" + z.year + z.mon + getLastDay(z.mon,z.year);

            report.datetype = 2003;
         }
         loadData();
         return;
      } else if (report.number == 1103) {

         if (report.datetype != 2003) {
            var z = new ditem(report.initdate);
            report.startdate = "" + z.year + z.mon + "01"; 
            report.enddate = "" + z.year + z.mon + getLastDay(z.mon,z.year);

            report.datetype = 2003;
         }
         loadData();
         return;
      } else if (report.number == 1104) { 
         if (report.datetype != 2002 && report.datetype != 2003 && report.datetype != 2005) {
            var z = new ditem(report.initdate);
            report.startdate = "" + z.year + z.mon + "01"; 
            report.enddate = "" + z.year + z.mon + getLastDay(z.mon,z.year);

            report.datetype = 2003;
         }
         loadData();
         return;
      } else if (report.number == 1105) {
         if (report.datetype != 2005 && report.datetype != 2004) {
            var z = new ditem(report.initdate);
            report.startdate = "" + z.year + "01" + "01"; 
            report.enddate = "" + z.year + "12" + getLastDay(12,z.year);

            report.datetype = 2004;
         }
         loadData();
         return;

      }else if (report.number == 1601 || report.number == 1602 || report.number == 1603) {
         if (report.datetype != 2003) {
            var z = new ditem(report.initdate);
            report.startdate = "" + z.year + z.mon + "01"; 
            report.enddate = "" + z.year + z.mon + getLastDay(z.mon,z.year);

            report.datetype = 2003;
         }
         loadData();

      } else {
         loadData();
      } 
      return;
   }
       
   // Today
   if (ndata[ii].report == 2001) {
      var z = new ditem(report.initdate);
      report.enddate = "" + z.year + z.mon + z.day; 
      report.startdate = report.enddate;

      report.datetype = 2001;
      loadData();
      return;
   }
   // This Week
   if (ndata[ii].report == 2002) {
      var z = new ditem(report.initdate);
      setNewDate(z,6-getDayofWeek(z),1);
      report.enddate = "" + z.year + z.mon + z.day;

      setNewDate(z,-6,1);
      report.startdate = "" + z.year + z.mon + z.day; 

      report.datetype = 2002;
      loadData();
      return;
   }
   // This Month
   if (ndata[ii].report == 2003) {
      var z = new ditem(report.initdate);
      report.startdate = "" + z.year + z.mon + "01"; 
      report.enddate = "" + z.year + z.mon + getLastDay(z.mon,z.year);

      report.datetype = 2003;
      loadData();
      return;
   }
   // This Year
   if (ndata[ii].report == 2004) {
      var z = new ditem(report.initdate);
      report.startdate = "" + z.year + "01" + "01"; 
      report.enddate = "" + z.year + "12" + getLastDay(12,z.year);

      report.datetype = 2004;
      loadData();
      return;
   }
   // Enter Range
   if (ndata[ii].report == 2005) {
      report.datetype = 2005;
      drawDateRange();
      return;
   }
   if (ndata[ii].report == 3001) {
      var mywin=window.open("index.cgi?prefs", "lwindow","location=no,menubar,scrollbars,resizable,width=550,height=275");
      if ((isIE) && (isVersion > 2)) {mywin.focus();}
      return;
   }
   if (ndata[ii].report == 3002) {
      vexport();
      return;
   }
   if (ndata[ii].report == 3004) {
      report.showhelp = 1 - report.showhelp;
      ndata[ii].onoff = 1 - ndata[ii].onoff;
   }
   
   redraw();
   
}

function drawDateRange() {
   var moList = new Array();
   var moDesc = new Array();
   var dayList = new Array();
   var yearList = new Array();

   moList[0] = '01';
   moList[1] = '02';
   moList[2] = '03';
   moList[3] = '04';
   moList[4] = '05';
   moList[5] = '06';
   moList[6] = '07';
   moList[7] = '08';
   moList[8] = '09';
   moList[9] = '10';
   moList[10] = '11';
   moList[11] = '12';

   moDesc[0] = ss[141];
   moDesc[1] = ss[142];
   moDesc[2] = ss[143];
   moDesc[3] = ss[144];
   moDesc[4] = ss[145];
   moDesc[5] = ss[146];
   moDesc[6] = ss[147];
   moDesc[7] = ss[148];
   moDesc[8] = ss[149];
   moDesc[9] = ss[150];
   moDesc[10] = ss[151];
   moDesc[11] = ss[152];

   dayList[0] = '01';
   dayList[1] = '02';
   dayList[2] = '03';
   dayList[3] = '04';
   dayList[4] = '05';
   dayList[5] = '06';
   dayList[6] = '07';
   dayList[7] = '08';
   dayList[8] = '09';
   dayList[9] = '10';
   dayList[10] = '11';
   dayList[11] = '12';
   dayList[12] = '13';
   dayList[13] = '14';
   dayList[14] = '15';
   dayList[15] = '16';
   dayList[16] = '17';
   dayList[17] = '18';
   dayList[18] = '19';
   dayList[19] = '20';
   dayList[20] = '21';
   dayList[21] = '22';
   dayList[22] = '23';
   dayList[23] = '24';
   dayList[24] = '25';
   dayList[25] = '26';
   dayList[26] = '27';
   dayList[27] = '28';
   dayList[28] = '29';
   dayList[29] = '30';
   dayList[30] = '31';

   //var z = new ditem(report.enddate); 
   //var eyr = getpDate(report.enddate,'year');
   //var eyr = z.year;

   var z = new Date();
   var eyr = z.getYear() + 1900;
   if (eyr > 3000) eyr = eyr-1900;

   var syr = startYear;

   while (syr < eyr) {
      yearList[yearList.length] = eyr;
      eyr--
   }
   yearList[yearList.length] = startYear;

   myRange = window.open('','drange','scrollbar=no,menubar=no,width=400,height=185,resizable=yes');
   dr = "<HTML><HEAD>";
   dr += '<META http-equiv=\"Expires\" content=\"now\">';
      dr += '<META http-equiv=\"Content-Type\" content=\"text/html; charset='+report.charset+'\">';
   dr += "<TITLE>Urchin 3.4 - Select Date Range</TITLE></HEAD><body bgcolor=#ffffff>";

   dr += "<blockquote><form><table width=300 border=0 cellspacing=0 cellpadding=0>\n"; 
   dr += "<tr><td width=76 bgcolor="+report.colors[1]+"><IMG SRC='"+ll+"uicons/"+icons+"/prefsurchin.gif' width=76 height=36></td>";
   dr += "<td  width=224 bgcolor="+report.colors[1]+" height=17>"+report.fonts[1]+"<b>&nbsp;"+ss[41]+"<br></td></tr>\n";
   //dr += "<tr><td bgcolor="+report.colors[1]+" height=17 colspan=2>"+report.fonts[1]+"<b>&nbsp;"+ss[41]+"<br></td></tr>\n";
   dr += "<tr><td colspan=2><table border=0 cellspacing=0 cellpadding=0 width=300><tr><td height=1 colspan=2><IMG SRC='"+ll+"uicons/"+icons+"/tspace.gif' WIDTH='300' HEIGHT='1'></td></tr>\n";
   dr += "<tr><td bgcolor="+report.colors[3]+" align=right>"+report.fonts[0]+ss[153]+"</td>\n";


   dr += "<td bgcolor="+report.colors[3]+" nowrap>\n";
   dr += "<IMG SRC='"+ll+"uicons/"+icons+"/tspace.gif' WIDTH='5' HEIGHT='20' HSPACE='0' VSPACE='0'>\n";

   dr += drawSelect("month1",z.mon,moList,moDesc,'')+" / ";
   dr += drawSelect("day1",z.day,dayList,dayList,'')+" / ";
   dr += drawSelect("year1",z.year,yearList,yearList,'');


   dr += "</td></tr>\n";
   dr += "<tr><td height=1 colspan=2><IMG SRC='"+ll+"uicons/"+icons+"/shadow.gif' WIDTH='300' HEIGHT='1'></td></tr>";
   dr += "<tr><td height=1 colspan=2><IMG SRC='"+ll+"uicons/"+icons+"/highlight.gif' WIDTH='300' HEIGHT='1'></td></tr>";
   dr += "<tr><td width=50 bgcolor="+report.colors[3]+" align=right>"+report.fonts[0]+ss[154]+"</td>\n";
   dr += "<td bgcolor="+report.colors[3]+" nowrap>\n";
   dr += "<IMG SRC='"+ll+"uicons/"+icons+"/tspace.gif' WIDTH='5' HEIGHT='20' HSPACE='0' VSPACE='0'>\n";

   dr += drawSelect("month2",z.mon,moList,moDesc,'')+" / ";
   dr += drawSelect("day2",z.day,dayList,dayList,'')+" / ";
   dr += drawSelect("year2",z.year,yearList,yearList,'');

   dr += "</td></tr>\n";
   dr += "<tr><td height=1 colspan=2><IMG SRC='"+ll+"uicons/"+icons+"/shadow.gif' WIDTH='300' HEIGHT='1'></td></tr>";
   dr += "<tr><td height=1 colspan=2><IMG SRC='"+ll+"uicons/"+icons+"/highlight.gif' WIDTH='300' HEIGHT='1'></td></tr>";
   dr += "<tr><td bgcolor="+report.colors[3]+" colspan=2 align=center valign=middle height=30>";
   dr += "<a href='javascript:opener.getReportDates(self);'><IMG SRC='"+ll+"uicons/"+icons+"/submit"+report.language+".gif' border=0 width=61 height=22></a></td></tr>\n";
   dr += "<tr><td height=2 colspan=2 bgcolor="+report.colors[1]+"><IMG SRC='"+ll+"uicons/"+icons+"/tspace.gif' WIDTH=300 HEIGHT=2></td></tr>";
   dr += "</td></tr></table></form></table>";
   dr += "<FONT FACE=\"Times Roman\" size=-7 color=black>Urchin&reg; 3.4 - &copy;2002 <A href=\"http://www.quantified.com/\" target=_blank>Quantified Systems, Inc</A>.</blockquote>";

   if ((isIE) && (isVersion == 2)) {
      setTimeout("drawExport(dr,myRange)",1000);
   } else {
      myRange.document.write(dr);
      myRange.document.close();
      myRange.focus();
   }
}

function getReportDates(winref) {
   var rform = winref.document.forms[0];

   var smo = rform.elements[0].options[rform.elements[0].selectedIndex].value;
   var sday = rform.elements[1].options[rform.elements[1].selectedIndex].value;
   var syr = rform.elements[2].options[rform.elements[2].selectedIndex].value;
   var emo = rform.elements[3].options[rform.elements[3].selectedIndex].value;
   var eday = rform.elements[4].options[rform.elements[4].selectedIndex].value;
   var eyr = rform.elements[5].options[rform.elements[5].selectedIndex].value;

   if (sday > getLastDay(smo,syr)) sday = getLastDay(smo,syr);
   if (eday > getLastDay(emo,eyr)) eday = getLastDay(emo,eyr);

   report.startdate = "" + syr + smo + sday;
   report.enddate = "" + eyr + emo + eday;

   report.datetype = 2005;

   loadData();
}


function drawSelect(fieldName,fieldValue,values,desc,type) {
   var rs = "<select name="+fieldName;
   //if (type == "show") {
      //rs += " onChange='parent.setLength2(this.form)';"
   //}
   rs += ">";
   for (var i=0;i<values.length;i++) {
      rs += "<option value='"+values[i]+"' ";
      if (values[i] == fieldValue) {
         rs += "selected ";
      }
      rs += ">"+desc[i]+"\n";
   }
   rs += "</select>\n";
   return rs;
}

var dr,myRange,mc,myWind;
function vexport() {
   mc = "<PRE>"+ss[report.title]+"\t"+ss[51]+"\t"+ss[6]+"\t"+ss[53]+"\t"+ss[54]+"\n";
   for (var i = 0; i<sdata.length; i++) {
      mc += sdata[i].myname;
      for (var j=0; j<6; j++) {
         mc += "\t" + sdata[i].data[j];
      }
      mc += "\n";
   }
   myWind = window.open('');
   if ((isIE) && (isVersion == 2)) {
      setTimeout("drawExport(mc,myWind)",1000);
   }else {
      myWind.document.write(mc);
      myWind.document.close();
   }
}
 
function drawExport(mc,myWind) {
      myWind.document.write(mc);
      myWind.document.close();
}

function doneLoading() {
   //return 0;
   reportindex = 2;
   for (var i=0;i<ndata.length;i++) {
       if ((ndata[i].report > 1000) && (ndata[i].report < 2000) && (ndata[i].report == report.number)) { reportindex = i; }
       else if (ndata[i].set == 1) { ndata[i].onoff = 0; }
   }
   for (var i=0;i<ndata.length;i++) {
      if (ndata[i].set == ndata[reportindex].set) { ndata[i].onoff = 0; }
   }
   for (var i=reportindex;i>0;i--) {
      if (ndata[i].set == 1) {
         ndata[i].onoff = 1;
         break;
      }
   }
   ndata[reportindex].onoff = 1;
	var fe = 0;
   for (var i=0;i<tab.length;i++) {
	   if (tab[i].enabled) { fe = 1; break; };
   }
	if (!tab[report.field].enabled && (fe)) { 
      for (var i=0;i<tab.length;i++) {
	      if (tab[i].onoff) report.field = i;
      }
   }
   if (report.initdate == 0) { report.initdate = report.enddate; }
   report.title  = ndata[reportindex].title;
   report.help   = ndata[reportindex].help;
   report.type   = ndata[reportindex].type;
   report.number = ndata[reportindex].report;
   report.color  = ndata[reportindex].oncolor;
   report.enabled  = ndata[reportindex].enabled;
   //report.showhelp = 0;
   if (report.type == 3) hLoad();
   else hdata = new Array();
   if (!report.pervable) report.perv=0;
   if (report.sortable) {
      sortbyfield(sdata,report.field);
      sortbyfield(hdata,report.field);
   }
   if ( ((isIE) && (isVersion == 2)) || ((isNav) && (isVersion == 3)) ) {
      setTimeout("redraw()",1000);
   } else {
      redraw();
   }
}



function dToggle(ii) {
   if (report.datetype == 2001) {
      var z = new ditem(report.enddate);
      setNewDate(z,ii,1);
      report.enddate = "" + z.year + z.mon + z.day;
      report.startdate = report.enddate;

   } else if (report.datetype == 2002) {
      var z = new ditem(report.enddate);

      setNewDate(z,(ii)*7,1);
      report.enddate = "" + z.year + z.mon + z.day;

      setNewDate(z,-6,1);
      report.startdate = "" + z.year + z.mon + z.day;

   } else if (report.datetype == 2003) {
      var z = new ditem(report.enddate);
      var y = new ditem(report.startdate);
      setNewDate(z,ii,0);
      setNewDate(y,ii,0);
      report.enddate = "" + z.year + z.mon + getLastDay(z.mon,z.year);
      report.startdate = "" + y.year + y.mon + y.day;
   } else if (report.datetype == 2004) {
      var z = new ditem(report.enddate);
      var y = new ditem(report.startdate);
      report.enddate = "" + ((z.year*1)+ii) + z.mon + z.day;
      report.startdate = "" + ((y.year*1)+ii) + y.mon + y.day;

   }

   loadData();
   //redraw();
}



function tToggle(ii) {
   report.field = ii;
   if (report.sortable) {
      sortbyfield(sdata,report.field);
      sortbyfield(hdata,report.field);
   }
   if ((isNav) && (isVersion == 3)) {
      setTimeout("redraw()",1000);
   } else {
      redraw();
   }
}
function pToggle() {
   report.perv = 1 - report.perv;
   if ((isNav) && (isVersion == 3)) {
      setTimeout("redraw()",1000);
   } else {
      redraw();
   }
}
function zToggle(pagenumber) {
   var url='index.cgi?b='+report.startdate+'&e='+report.enddate+'&r=1606&p='+pagenumber;
   var newWin = window.open(url,pagenumber,"toolbar=yes,scrollbars=yes,status=no,resizable=yes,location=no,width=640,height=300");
   if ( !((isIE) && (isVersion < 4)) ) newWin.focus();
}
function hToggle(hh) {
   if (hh >= hdata.length) return;
   hdata[hh].isopen = 1 - hdata[hh].isopen;
   if ((isNav) && (isVersion == 3)) {
      setTimeout("redraw()",1000);
   } else {
      redraw();
   }
}
function pten() {
   report.start = report.start - report.mylength;
   if (report.start < 0) report.start = 0;
   if ((isNav) && (isVersion == 3)) {
      setTimeout("redraw()",1000);
   } else {
      redraw();
   }
}
function nten() {
   report.start = report.start + report.mylength;
   if (report.start >= sdata.length) {
      report.start = report.start - report.mylength;
      if (report.start < 0) report.start = 0;
   }
   if ((isNav) && (isVersion == 3)) {
      setTimeout("redraw()",1000);
   } else {
      redraw();
   }
}

function showDate2(date) {
   var d = new ditem(date);

   if (report.language == "english") {
      var res = d.mon + "/" + d.day + "/" + d.year;
      return res; 
   } else if (report.language == "japanese") {
      var res = d.year + "/" + d.mon + "/" + d.day;
      return res; 
   } else {
      var res = d.day + "/" + d.mon + "/" + d.year;
      return res; 
   }
}

function getpDate(num,type) {
   //--return partial dates
   var mydate = new Date((num*1000));
   var x = mydate.getYear() + 1900;
   if (x > 3000) x = x-1900;
   if (type == "month") {
   	var pdate = mydate.getMonth() + 1;
   }else if  (type == "date") {
   	var pdate = mydate.getDate();
   }else {
   	var pdate = x;
   }
   return pdate; 
}
function getfirst(s) {
   if (s == "") return s;  
   var p = s.indexOf(report.separator)
   
   //if (report.language == "japanese" || report.language == "english" && report.number == "1204") {
   if (report.number == "1204") {
      if      (s.substring(0,3) == "200" && parent.ss[192]) { return parent.ss[192]; }
      else if (s.substring(0,3) == "201" && parent.ss[193]) { return parent.ss[193]; }
      else if (s.substring(0,3) == "202" && parent.ss[194]) { return parent.ss[194]; }
      else if (s.substring(0,3) == "203" && parent.ss[195]) { return parent.ss[195]; }
      else if (s.substring(0,3) == "204" && parent.ss[196]) { return parent.ss[196]; }
      else if (s.substring(0,3) == "205" && parent.ss[197]) { return parent.ss[197]; }
      else if (s.substring(0,3) == "206" && parent.ss[198]) { return parent.ss[198]; }

      else if (s.substring(0,3) == "300" && parent.ss[199]) { return parent.ss[199]; }
      else if (s.substring(0,3) == "301" && parent.ss[200]) { return parent.ss[200]; }
      else if (s.substring(0,3) == "302" && parent.ss[201]) { return parent.ss[201]; }
      else if (s.substring(0,3) == "303" && parent.ss[202]) { return parent.ss[202]; }
      else if (s.substring(0,3) == "304" && parent.ss[203]) { return parent.ss[203]; }
      else if (s.substring(0,3) == "305" && parent.ss[204]) { return parent.ss[204]; }

      else if (s.substring(0,3) == "400" && parent.ss[205]) { return parent.ss[205]; }
      else if (s.substring(0,3) == "401" && parent.ss[206]) { return parent.ss[206]; }
      else if (s.substring(0,3) == "402" && parent.ss[207]) { return parent.ss[207]; }
      else if (s.substring(0,3) == "403" && parent.ss[208]) { return parent.ss[208]; }
      else if (s.substring(0,3) == "404" && parent.ss[209]) { return parent.ss[209]; }
      else if (s.substring(0,3) == "405" && parent.ss[210]) { return parent.ss[210]; }
      else if (s.substring(0,3) == "406" && parent.ss[211]) { return parent.ss[211]; }
      else if (s.substring(0,3) == "407" && parent.ss[212]) { return parent.ss[212]; }
      else if (s.substring(0,3) == "408" && parent.ss[213]) { return parent.ss[213]; }
      else if (s.substring(0,3) == "409" && parent.ss[214]) { return parent.ss[214]; }
      else if (s.substring(0,3) == "410" && parent.ss[215]) { return parent.ss[215]; }
      else if (s.substring(0,3) == "411" && parent.ss[216]) { return parent.ss[216]; }
      else if (s.substring(0,3) == "412" && parent.ss[217]) { return parent.ss[217]; }
      else if (s.substring(0,3) == "413" && parent.ss[218]) { return parent.ss[218]; }
      else if (s.substring(0,3) == "414" && parent.ss[219]) { return parent.ss[219]; }
      else if (s.substring(0,3) == "415" && parent.ss[220]) { return parent.ss[220]; }
      else if (s.substring(0,3) == "416" && parent.ss[221]) { return parent.ss[221]; }
      else if (s.substring(0,3) == "417" && parent.ss[222]) { return parent.ss[222]; }

      else if (s.substring(0,3) == "500" && parent.ss[223]) { return parent.ss[223]; }
      else if (s.substring(0,3) == "501" && parent.ss[224]) { return parent.ss[224]; }
      else if (s.substring(0,3) == "502" && parent.ss[225]) { return parent.ss[225]; }
      else if (s.substring(0,3) == "503" && parent.ss[226]) { return parent.ss[226]; }
      else if (s.substring(0,3) == "504" && parent.ss[227]) { return parent.ss[227]; }
      else if (s.substring(0,3) == "505" && parent.ss[228]) { return parent.ss[228]; }
      //else { if (p < 0) return s; return s.substring(0,p); }
   }
   if (p < 0) return s;
   return s.substring(0,p);
}

function getlast(s) {
   if (s == "") return s;
   var p = s.indexOf("|")

   if (p < 0) return s;

   if (report.number == "1502") {  
      if      (s.substring(0,p) == "EZweb Device") { return getPhones(s.substring((p+1),s.length),0); }
      //else if (s.substring(0,p) == "J-Sky")      { return getPhones(s.substring((p+1),s.length),1); }
      //else if (s.substring(0,p) == "i-mode")     { return "DoCoMo " + s.substring((p+1),s.length);  }
      //else if (s.substring(0,p) == "DDI Pocket") { return getPhones(s.substring((p+1),s.length),2); }
   }

   return s.substring((p+1),s.length);
}

function getPhones(s,t) {
   if (t == 0) {
      if (s == "HI12")              { return s + " - Hitachi"; }
      else if (s == "HI01")         { return s + " - Hitachi C201H HI01"; }
      else if (s == "MA11")         { return s + " - Panasonic C308P"; }
      else if (s == "MA13")         { return s + " - Panasonic C408P"; }
      else if (s == "MAC1")         { return s + " - Panasonic D305P"; }
      else if (s == "SY11")         { return s + " - Sanyo C304A"; }
      else if (s == "SYC1")         { return s + " - Sanyo D301SA"; }
      else if (s == "SYT1")         { return s + " - Sanyo TS01"; }
      else if (s == "SY02")         { return s + " - Sanyo SCP-4500"; }
      else if (s == "SY03")         { return s + " - Sanyo SCP-5000"; }
      else if (s == "SN11")         { return s + " - Sony 705G"; }
      else if (s == "SNC1")         { return s + " - Sony D306S"; }
      else if (s == "TOxx")         { return s + " - Toshiba D302T"; }
      else if (s == "TS11")         { return s + " - Toshiba 701G"; }
      else if (s == "TS12")         { return s + " - Toshiba C301T"; }
      else if (s == "TST1")         { return s + " - Toshiba TT01"; }
      else if (s == "KCT2")         { return s + " - Kyocera TK01"; }
      else if (s == "KCT1")         { return s + " - Kyocera TK02"; }
      else if (s == "KCC1")         { return s + " - Kyocera D303K"; }
      else if (s == "KCC2")         { return s + " - Kyocera D304K"; }
      else if (s == "CA11")         { return s + " - Casio C303CA CA11"; }
      else if (s == "DN01")         { return s + " - Denso C202DE DN01"; }
      else if (s == "HI11")         { return s + " - Hitachi C302H HI11"; }
      else if (s == "D2")           { return s + " - Panasonic D2"; }
      else if (s == "P-PAT")        { return s + " - Panasonic P-PAT"; }
      else if (s == "MOT-CB")       { return s + " - Accompli6188"; }
      else if (s == "Sanyo-C304SA") { return s + " - Sanyo C304SA Sanyo-C304SA"; }
      else if (s.substring(0,2) == "SY") { return s + " - Sanyo"; }
      else if (s.substring(0,2) == "TS") { return s + " - Toshiba"; }
      else if (s.substring(0,2) == "ST") { return s + " - StarTAC"; }
      else if (s.substring(0,2) == "KC") { return s + " - Kyocera"; }
      else if (s.substring(0,2) == "SN") { return s + " - Sony"; }
      else if (s.substring(0,2) == "DN") { return s + " - Denson"; }
      else if (s.substring(0,2) == "MA") { return s + " - Panasonic"; }
      else if (s.substring(0,2) == "CA") { return s + " - Casio"; }
   }
   return s;
}

function drawHead() {
   nc = '<HT'+'ML><HE'+'AD>';
   nc += '<META http-equiv=\"Expires\" content=\"now\">';
   if ((isNav == false) && (isVersion != 3)) {
      nc += '<META http-equiv=\"Content-Type\" content=\"text/html; charset='+report.charset+'\">';
   }
   nc += '<ST'+'YLE TYPE="text/css"><!'+'-- A {text-decoration';
   nc += ':none;} A.normal {text-decoration:underline;color:blue;} --'+'> </S'+'TYLE></HE'+'AD>';
   nc += '<BOD'+'Y bgcolor='+report.colors[0];
   nc += ' link=black'+' alink=black vlink=black'+' MARGINHEIGHT=0 MARGINWIDTH=0'+' LEFTMARGIN=0 TOPMARGIN=0>';
   nc += '<table width=809 border=0 cellspacing=0 cellpadding=0>';
   nc += '<tr><td width=25 rowspan=3><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=25 HEIGHT=5 HSPACE=0 VSPACE=0></td>';
   nc += '<td width=124 valign=top><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=124 HEIGHT=10></td>';
   nc += '<td width=31><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=31 HEIGHT=5 HSPACE=0 VSPACE=0></td>';
   nc += '<td width=629> <IMG src="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=629 HEIGHT=5></td></tr>';
}
function drawNav() {
   // disable certain dates on reports
   if (report.number == 1101) {
      disable(2001);
      enable(2002);
      disable(2003);
      disable(2004);
      disable(2005);
   }else if (report.number == 1103) {
      disable(2001);
      disable(2002);
      enable(2003);
      disable(2004);
      disable(2005);
   }else if (report.number == 1104) {
      disable(2001);
      enable(2002);
      enable(2003);
      disable(2004);
      enable(2005);
   }else if (report.number == 1105) {
      disable(2001);
      disable(2002);
      disable(2003);
      enable(2004);
      enable(2005);
   }else if (report.number == 1601 || report.number == 1602 || report.number == 1603) {
      disable(2001);
      disable(2002);
      enable(2003);
      disable(2004);
      disable(2005);
   } else {
      enable(2001);
      enable(2002);
      enable(2003);
      enable(2004);
      enable(2005);
   }

   nc += '<tr><td valign=top><table width=124 border=0 cellspacing=0 cellpadding=0>';
   var currentlevel = 0;

   for (var i=0;i<ndata.length;i++) {
      if (ndata[i].level <= currentlevel) {
         drawNavElement(i);
         currentlevel = ndata[i].level;
         if (ndata[i].onoff == 1) {currentlevel++;}
      }
   }

   nc += '</table><p>&nbsp;</td>';
}
function drawNavElement(ii) {
   if (!ndata[ii].enabled) return;

   var line = '',vline = '', sline = '', hline = '';
   var thisbutton = ndata[ii].offbutton;
   var thiscolor  = ndata[ii].offcolor;

   if (ndata[ii].onoff == 1) {
      thisbutton = ndata[ii].onbutton;
      thiscolor  = ndata[ii].oncolor;
      if (ndata[ii].level != 0 && (ndata[ii].report < 2000) && (ndata[ii].report)) {
         line = '<td valign=bottom><img src="'+ll+'uicons/'+icons+'/tline.gif" width=9 height=15></td>';
         navLine = 1;   // flag to start drawing the vertical lines
      }
   }

   if (navLine == 1) {
         sline = '<td><img src="'+ll+'uicons/'+icons+'/sline.gif" width=9 height=1></td>';
         if (!line) {
            if (report.language == "chinese") {
               line = '<td valign=top><img src="'+ll+'uicons/'+icons+'/sline.gif" width=9 height=22></td>';
               vline = '<td valign=top><img src="'+ll+'uicons/'+icons+'/sline.gif" width=9 height=22></td>';
            } else if (report.language == "korean" || report.language == "japanese") {
               line = '<td valign=top><img src="'+ll+'uicons/'+icons+'/sline.gif" width=9 height=18></td>';
               vline = '<td valign=top><img src="'+ll+'uicons/'+icons+'/sline.gif" width=9 height=20></td>';
            } else {
               line = '<td valign=top><img src="'+ll+'uicons/'+icons+'/sline.gif" width=9 height=15></td>';
               vline = '<td valign=top><img src="'+ll+'uicons/'+icons+'/sline.gif" width=9 height=18></td>';
            }
            hline = '<td><img src="'+ll+'uicons/'+icons+'/sline.gif" width=9 height=1></td>';
         }
   }

   if ((ndata[ii].level == 0) && (ii != 0)) { nc += '<tr><td colspan=3 height=18>'+report.fonts[1]+'&nbsp;</td>'+vline+'</font></tr>'; }

   if (ndata[ii].level == 0) {
      nc += '<tr><td bgcolor='+report.colors[thiscolor]+' colspan=3 height=18 nowrap>'+report.fonts[1]+'<b>&nbsp;';
      nc += ss[ndata[ii].title]+'<br></td>'+vline+'</tr>';
   } else if (ndata[ii].report > 2000 && ndata[ii].report < 3000 && ndata[ii].report == report.datetype) {
      thiscolor = report.color;
      var thisbutton2;
      var link1 = '<a href="javascript:parent.nToggle('+ii+')">';
      var link2 = '<a href="javascript:parent.nToggle('+ii+')">';

      thisbutton = ndata[ii].onbutton;

      line = '<td valign=top align=left><img src="'+ll+'uicons/'+icons+'/bline.gif" width=9 height=15></td>';
      navLine = 0;
      sline = '';

      if (report.datetype != 2005) {
         thisbutton2 = ndata[ii].onbutton+1;
         link1 = '<a href="javascript:parent.dToggle(-1)">';
         link2 = '<a href="javascript:parent.dToggle(1)">';
      } else {
         thisbutton2 = thisbutton;
      }

      // first row
      nc += '<tr><td rowspan=3 width=18 valign=bottom>'+link1;
      nc += '<IMG SRC="'+ll+'uicons/'+icons+'/ind'+thisbutton+'.gif" WIDTH=18 HEIGHT=17 border=0></a></td>';
      nc += '<td rowspan=1 colspan=2 width=100><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" width=1 HEIGHT=1></td>';
      nc += hline+'</tr>';

      // second row
      nc += '<tr><td bgcolor=#'+report.colors[thiscolor]+' height=15 nowrap><nobr><a href="javascript:parent.nToggle('+ii+')">';
      nc += report.fonts[0]+'&nbsp;'+ss[ndata[ii].title]+'</font></a></nobr></td>';
      nc += '<td align=right valign=bottom rowspan=1 colspan=1 bgcolor='+report.colors[thiscolor]+'>';
      nc += link2+'<IMG SRC="'+ll+'uicons/'+icons+'/ind'+thisbutton2+'.gif" WIDTH=18 HEIGHT=15 border=0></a></td>'+line;
      nc += '<tr><td colspan=2 bgcolor=#808080><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=1 HEIGHT=1></td>';
      nc += sline+'</tr>';

   } else {
      nc += '<tr><td rowspan=3 width=18 valign=bottom><a href="javascript:parent.nToggle('+ii+')"><IMG S';
      nc += 'RC="'+ll+'uicons/'+icons+'/ind'+thisbutton+'.gif" WIDTH=18 HEIGHT=17 border=0>';
      //nc += '</a></td><td colspan=2><IMG SRC="'+ll+'uicons/'+icons+'/highlight.gif" WIDTH=97 HEIGHT=1></td>';
      nc += '</a></td><td colspan=2><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=97 HEIGHT=1></td>';
      nc += hline+'</tr><tr><td bgcolor=#'+report.colors[thiscolor]+' height=15 colspan=1 nowrap><a href="javascr';
      nc += 'ipt:parent.nToggle('+ii+')">'+report.fonts[0]+'&nbsp;'+ss[ndata[ii].title]+'</';
      //nc += 'FONT></a></td>'+line+'</tr><tr><td colspan=2><IMG SRC="'+ll+'uicons/'+icons+'/shadow.gif" WIDTH=';
      nc += 'FONT></a></td><td bgcolor=#'+report.colors[thiscolor]+'><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=18 HEIGHT=15></td>'+line+'</tr><tr><td colspan=2 bgcolor=#808080><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=';
      nc += '97 HEIGHT=1></td>'+sline+'</tr>';
   }
}

function drawReport() {
   gmax = 0;
   //---calculate max value 
   if (report.type == 0) drawArea(1);
   if (report.type == 1) drawSnap(1);
   if (report.type == 2) drawTop(1);
   if (report.type == 3) drawTree(1);
   if (report.type == 4) drawAverage(1);

   nc += '<td width=31><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=31 HEIGHT=5 HSPACE=0 VSPACE=0></td>';
   nc += '<td valign=top width=625><table border=0 cellspacing=0 cellpadding=0 ';
   //nc += 'width=552><tr bgcolor='+report.colors[1]+'><td rowspan=4 width=1><IMG SRC="'+ll+'uico';
   nc += '><tr bgcolor='+report.colors[1]+'><td rowspan=4 width=1><IMG SRC="'+ll+'uico';
   nc += 'ns/'+icons+'/tspace.gif" WIDTH=1 HEIGHT=5></td><td height=18 colspan=2>'+report.fonts[1];
   nc += '<nobr>&nbsp; '+ss[61]+': <b>'+report.website+'</b></font></nobr><br><IMG';
   nc += ' SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=250 HEIGHT=1></td><td height=18 ';
   nc += 'align=right colspan=1>'+report.fonts[1]+'<nobr><b>'+ss[36]+':</b> ';
   nc += showDate2(report.startdate)+' - '+showDate2(report.enddate)+' &nbsp;</no';
   nc += 'br><br><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=10 HEIGHT=1></td><td ';
   nc += 'rowspan=4 width=1><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=1 HEIGHT=5';
   nc += '></td></tr>';

  if (report.type != 4) {
    nc += '<tr><td align=right rowspan=2 bgcolor='+report.colors[1]+'><IMG SRC=';
    nc += '"'+ll+'uicons/'+icons+'/bigtab.gif" WIDTH=100 HEIGHT=20></td><td rowspan=2 bgcol';
    nc += 'or='+report.colors[2]+'><nobr>&nbsp;'+report.fonts[1]+ss[report.title];
    nc += '</nobr></td><td bgcolor='+report.colors[2]+' colspan=1><IMG SRC="'+ll+'uicons/'+icons+'/tspa';
    nc += 'ce.gif" WIDTH=10 HEIGHT=6></td></tr><tr><td align=right bgcolor='+report.colors[2]+'><table cell';
    nc += 'padding=0 cellspacing=0 border=0><tr>';
    for (var i=0;i<tab.length;i++) {
         if (tab[i].enabled) {
            var thiscolor = 4;
            if (report.field == i) {thiscolor = report.color;}
            nc += '<td bgcolor='+report.colors[thiscolor]+' valign=top><IMG SRC="'+ll+'uicons/'+icons+'/tabside1.gif" WIDTH=9 HEIGHT=14></td>';
            nc += '<td bgcolor='+report.colors[thiscolor]+'><A HREF="javascript:parent.tToggle('+i+');">'+report.fonts[0]+'<nobr><b>'+ss[tab[i].title]+'</b></font></a></td>';
            nc += '<td bgcolor='+report.colors[thiscolor]+' valign=top><IMG SRC="'+ll+'uicons/'+icons+'/tabside2.gif" WIDTH=2 HEIGHT=14></td>';
         }
     }
     nc += '<td bgcolor='+report.colors[2]+'><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=20 HEIGHT=1></td></tr>';
     nc += '</table></td></tr>';
   } else nc += '</tr><td colspan=3 bgcolor='+report.colors[1]+'>&nbsp;</td></tr>';
   nc += '<tr><td colspan=3>';
   //nc += '<table border=0 cellspacing=0 cellpadding=3 width=550>';
   nc += '<table border=0 cellspacing=0 cellpadding=3 width=100%>';
   nc += '<FORM>'; 
   nc += '<tr bgcolor='+report.colors[report.color]+'>';

   if (report.type == 4) {
      /*
      nc += '<td>&nbsp;</td>';
      nc += '<td align=center>'+report.fonts[0]+'<b>'+ss[36]+' '+ss[32]+'</b></td>';
      nc += '<td align=center>'+report.fonts[0]+'<b>'+ss[48]+'</b></td>';
      nc += '<td align=center>'+report.fonts[0]+'<b>'+sdata[sdata.length-1].myname+'</b></td>';
      nc += '<td align=center>'+report.fonts[0]+'<b>'+ss[49]+'</b></td>';
      */
      nc += '<td align=center colspan=2 width=552>'+report.fonts[0]+'<b>'+ss[47]+'</b></td>';
   }
   else if (report.type > 1) {
      nc += '<td width=20><center><A HREF="javascript:parent.pten();"><IMG SRC="'+ll+'uicons/'+icons+'/up.gif" WIDTH=13 HEIGHT=10 BORDER=0></a></td>';

      nc += '<td width=265>'+report.fonts[0]+'<nobr>'+ss[63]+' &nbsp; &nbsp; '+ss[62]+'&nbsp;';
      var n = new Array();
      n[0] = '10';
      n[1] = '20';
      n[2] = '35';
      n[3] = '50';
      n[4] = '75';
      n[5] = '100';
      nc += drawSelect('number',report.mylength,n,n,'show');
      nc += '<A HREF="javascript:parent.setLength2(self.form);"><IMG SRC="'+ll+'uicons/'+icons+'/go'+report.language+'.gif" WIDTH=54 HEIGHT=15 BORDER=0 hspace=0 vspace=0 align=baseline></a></td>';
      //nc += '<INPUT SIZE=3 NAME=number VALUE="'+report.mylength+'" onChange="parent.setLength(self.value);"></nobr></td>';
      var ssp;
      if ((report.pervable) && (report.field !=0)) {
         nc += '<td width=90>'+report.fonts[0]+'<center><b>'+ss[tab[0].title]+'</td>';
         nc += '<td width=57>'+report.fonts[0]+'<center><b>'+ss[tab[report.field].title]+'</td>';
         if (report.field == 3) ssp = formatNumber(gmax) + ' &nbsp;';
         else if (report.field == 5) ssp = formatMoney(gmax) + ' &nbsp;';
         else ssp = '' + formatNumber(gmax) + ' &nbsp;';
      }
      else {
         nc += '<td width=90>'+report.fonts[0]+'<center><b>'+ss[tab[report.field].title]+'</td>';
         nc += '<td width=57 nowrap><nobr>'+report.fonts[0]+'<center><b>'+ss[64]+'</nobr></td>';
         ssp = '' + formatNumber(gmax) + '% &nbsp;';
      }
      nc += '<td width=118><table border=0 cellspacing=0 cellpadding=0><tr><td valign=bottom align=left>'+report.fonts[2]+'0</font></td><td valign=bottom align=right>'+report.fonts[2]+ssp+'</FONT></td></tr><tr><td colspan=2><IMG SRC="'+ll+'uicons/'+icons+'/scale2.gif" WIDTH=118 HEIGHT=8></td></tr></table></td>';
   }
   else {
      nc += '<td>';
      if (report.number < 1200) {
         var rtotal=0,tnum=0,avg=0,ttitle;
         if (report.number == 1103) { 
            ttitle = ss[126];
         } else if (report.number == 1105) { 
            ttitle = ss[128];
         } else {
            ttitle = ss[125];
         }

         for (var i=0; i<sdata.length; i++) {
             rtotal += sdata[i].data[report.field];
             if (sdata[i].data[report.field] != 0) { tnum++; }
         }
         if (tnum > 0) { avg = Math.round(100 * (rtotal/tnum))/100; } 

         if (report.field == 3) { 
            rtotal = formatNumber(rtotal); 
            avg = formatNumber(avg); 
         } else if (report.field == 5) { 
            rtotal = formatMoney(rtotal); 
            avg = formatMoney(avg); 
         } else { 
            rtotal = addCommas(rtotal);  
            avg = addCommas(avg);  
         }
         nc += '<table cellpadding=0 cellspacing=0 border=0><tr>';
         nc += '<td width=40><img src="'+ll+'uicons/'+icons+'/tspace.gif" height=5 width=40 border=0></td>';
         nc += '<td nowrap>'+report.fonts[0]+'<b>'+ss[124]+':</b> '+rtotal+'</td>';
         nc += '<td width=15><img src="'+ll+'uicons/'+icons+'/tspace.gif" height=5 width=15 border=0></td>';
        // commented out display of Hourly Average, jnapier, 6/27/2001
        if (report.number != 1103) {
          nc += '<td nowrap>'+report.fonts[0]+'<b>'+ttitle+':</b> '+avg+'</td>';
        }
         nc += '</tr></table>';
      } else {
         nc += '<td><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" height=5 width=1 border=0>';
         // nc += '<td>&nbsp;'+report.fonts[0]+ss[report.title]+' '+ss[69]+' '+ss[tab[report.field].title]+' (';
         // nc += showDate2(report.startdate)+' - '+showDate(report.enddate)+')</td>';
      }
   }
   nc += '</td></tr></FORM>';

   if (report.enabled != 1) {
      nc += '<tr><td COLSPAN=5><IMG SRC="'+ll+'uicons/'+icons+'/samples/'+report.number+'.gif" border=0></td></tr>';
   }
   else {
      if (report.type == 0) drawArea(0);
      if (report.type == 1) drawSnap(0);
      if (report.type == 2) drawTop(0);
      if (report.type == 3) drawTree(0);
      if (report.type == 4) drawAverage(0);
   }

   nc += '<tr bgcolor='+report.colors[report.color]+'>';
   if ((report.type == 2) || (report.type == 3)) {
      nc += '<td><center><A HREF="javascript:parent.nten();"><IMG SRC="'+ll+'uicons/'+icons+'/down.gif" WIDTH=13 HEIGHT=10 border=0></a></td>';
      nc += '<td colspan=4><nobr>'+report.fonts[0]+ss[65]+' </td>';
   } 

   nc += '</tr></table>';
   nc += '</td></tr>'; 
   if ((report.type == 4)) {
      nc += '<tr bgcolor='+report.colors[1]+'><td colspan=3><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=10 HEIGHT=7></td></td>';
   } else {
      nc += '<tr bgcolor='+report.colors[1]+'><td colspan=5><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=10 HEIGHT=7></td></td>';
   }

   nc += '</table>';

}

function drawSnap(set_max) {
   if (set_max) {
      for (var i=0; i<sdata.length; i++) {
         if (sdata[i].data[report.field] > gmax) gmax = sdata[i].data[report.field];
      }
      return;
   }
   formatMax();
   //compute widths
   var ax,dx,wx,lx,tx,mx;
   dx = Math.floor(480/sdata.length);
   wx = dx*sdata.length;
   ax = (550-wx)/2;
   lx = 150;

   var sx;
   if (report.field == 5) sx = formatMoney(gmax);
   else if (report.field == 4) sx = formatTime(gmax);
   else if (report.field == 3) sx = formatNumber(gmax);
   else sx = addCommas(gmax);
   nc += '<tr bgcolor='+report.colors[5]+'><td colspan=1 align=center><table border=0 cellspacing=0 cellpadding=0>';
   nc += '<tr><td width='+ax+' align=right colspan=2>'+report.fonts[2]+'&nbsp;<BR>'+ss[tab[report.field].title]+'</td><td width='+wx+' colspan='+sdata.length+'>&nbsp;</td><td width='+ax+'>&nbsp;</td></tr>';
   nc += '<tr><td width='+(ax-10)+' valign=top align=right>'+report.fonts[2]+sx+'</td>';
   nc += '<td width=10 rowspan=2><IMG SRC="'+ll+'uicons/'+icons+'/lscale.gif" WIDTH=10 HEIGHT='+lx+'></td>';
   for (var i=0; i<sdata.length; i++) {
       mx = Math.round(lx*sdata[i].data[report.field]/gmax);
       if (mx>lx) mx = lx;
       if (report.field == 5) sx = formatMoney(sdata[i].data[report.field]);
       else if (report.field == 4) sx = formatTime(sdata[i].data[report.field]);
       else if (report.field == 3) sx = formatNumber(sdata[i].data[report.field]);
       else sx = addCommas(sdata[i].data[report.field]);
       nc += '<td width='+dx+' height='+lx+' rowspan=2><table border=0 cellpadding=0 cellspacing=0>';
       nc += '<tr><td colspan=2 width='+dx+' height='+(lx-mx)+' background="'+ll+'uicons/'+icons+'/grid2.gif" valign=bottom align=center>'+report.fonts[2]+sx+'</td></tr>';
       nc += '<tr><td width='+(dx-1)+' height='+mx+' bgcolor='+report.colors[18]+' valign=top align=center><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=1 HEIGHT=1></td>';
       nc += '<td align=bottom bgcolor=white><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=1 HEIGHT=1></td></tr></table></td>';
   }
   nc += '<td width='+ax+' height='+lx+' align=left rowspan=2><IMG SRC="'+ll+'uicons/'+icons+'/rscale.gif" WIDTH=10 HEIGHT='+lx+'></td></tr>';
   nc += '<tr><td width='+(ax-10)+' align=right valign=bottom>'+report.fonts[2]+'0</td></tr>';
   nc += '<tr><td width='+ax+' colspan=2>&nbsp;</td>';
   for (var i=0; i<sdata.length; i++) {
      nc += '<td align=center width='+dx+'>'+report.fonts[2]+sdata[i].myname+'</td>';
   }
   nc += '<td width='+ax+'>&nbsp;</td></tr></table></td></tr>';
}

function drawArea(set_max) {
   if (set_max) {
      for (var i=0; i<sdata.length; i++) {
         if (sdata[i].data[report.field] > gmax) gmax = sdata[i].data[report.field];
      }
      return;
   }
   formatMax();
   //compute widths
   var ax,dx,wx,lx,tx,mx,superx,fv;
   dx = Math.floor(480/sdata.length);
   if (dx < 2) dx = 2;
   wx = dx*sdata.length;
   superx = 550;
   if (wx > 480) superx = wx + 75;
   ax = (superx-wx)/2;
   lx = 150;

   var sx;
   if (report.field == 5) sx = formatMoney(gmax);
   else if (report.field == 4) sx = formatTime(gmax);
   else if (report.field == 3) sx = formatNumber(gmax);
   else sx = addCommas(gmax);
   nc += '<tr bgcolor='+report.colors[5]+'><td colspan=1 align=center><table border=0 cellspacing=0 cellpadding=0>';
   nc += '<tr><td width='+ax+' align=right colspan=2>'+report.fonts[2]+ss[tab[report.field].title]+'</td><td width='+wx+'>&nbsp;</td><td width='+ax+'>&nbsp;</td></tr>';
   nc += '<tr><td width='+(ax-10)+' valign=top align=right>'+report.fonts[2]+sx+'</td>';
   nc += '<td width=10 rowspan=2><IMG SRC="'+ll+'uicons/'+icons+'/lscale.gif" WIDTH=10 HEIGHT='+lx+'></td>';
   nc += '<td width='+wx+' height='+lx+' rowspan=2 background="'+ll+'uicons/'+icons+'/grid2.gif" valign=bottom>';
   for (var i=0; i<sdata.length; i++) {
       mx = Math.round(lx*sdata[i].data[report.field]/gmax);
       if (mx < 1) mx=1;
       if (mx>lx) mx = lx;
       if (report.field == 5)      fv = formatMoney(sdata[i].data[report.field]);
       else if (report.field == 4) fv = formatTime(sdata[i].data[report.field]);
       else if (report.field == 3) fv = formatNumber(sdata[i].data[report.field]);
       else                        fv = addCommas(sdata[i].data[report.field]);

       nc += '<IMG SRC="'+ll+'uicons/'+icons+'/green.gif" alt="'+fv+'" WIDTH='+(dx-1)+' HEIGHT='+mx+'>';
       nc += '<IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=1 HEIGHT=1>';
   }
   nc += '</td><td width='+ax+' height='+lx+' align=left rowspan=2><IMG SRC="'+ll+'uicons/'+icons+'/rscale.gif" WIDTH=10 HEIGHT='+lx+'></td></tr>';
   nc += '<tr><td width='+(ax-10)+' align=right valign=bottom>'+report.fonts[2]+'0</td></tr>';
   nc += '<tr><td width='+ax+' colspan=2>&nbsp;</td><td width='+wx+'><table width='+wx+' border=0 cellspacing=0 cellpadding=0><tr>';
   if (sdata.length < 8) {
      for (var i=0; i<sdata.length; i++) {
         nc += '<td align=center width='+dx+'>'+report.fonts[2]+sdata[i].myname+'</td>';
      }
   }
   else {
      var wx1,wx2,qx,vx,vdx;
      wx1 = wx/8; 
      wx2 = wx/4; 
      nc += '<td width='+wx1+' align=left>'+report.fonts[2]+sdata[0].myname+'</td>';
      for (var i=1; i<=3; i++) {
         nc += '<td width='+wx2+' align=center>';
         qx = i * sdata.length / 4.0;
         vx = Math.floor(qx);
         vdx = qx - vx - .5;
         if (vdx < 0) { nc += '<IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH='+(-2.0*dx*vdx)+' HEIGHT=1>';}
         nc += report.fonts[2]+sdata[vx].myname;
         if (vdx > 0) { nc += '<IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH='+(2.0*dx*vdx)+' HEIGHT=1>';}
         nc += '</td>';
      }
      nc += '<td width='+wx1+' align=right>'+report.fonts[2]+sdata[(sdata.length -1)].myname+'</td>';
   }
   nc += '</tr></table></td><td width='+ax+'>&nbsp;</td></tr></table></td></tr>';
}

function drawAverage(set_max) {
   if (set_max) return;
   var linecolor = 4,data;
   var name;
   for (var i = 0; i<sdata.length; i++) {
      name = ss[sdata[i].myname];
      data = 0;
      for (var j=0; j<6; j++) {
         if (sdata[i].data[j] != 0) { 
            if ((report.number == 1102 && i > 3 && i < 11) || report.number == 1701 && i > 0 && i < 3) {
               data = sdata[i].data[j]/100;
            } else {
               data = sdata[i].data[j];
            }
            break;
         }
      }
      if (j == 5) {
         data = formatMoney(data);
      } else if (i == 3 || i == 7 || i == 10) { 
         data = formatNumber(data);
      } else if (i == 11) { 
         if (report.language == "english" || report.language == "english-uk") {
           data = formatTime(data);
           name += " (H:M:S)";
         } else {
           data += ss[174];
         }
      } else { 
         data = addCommas(data); 
      }

      nc += '<tr bgcolor='+report.colors[linecolor]+'><td>'+report.fonts[0]+'&nbsp;&nbsp;'+name+'</td>';
      nc += '<td align=right>'+report.fonts[0]+data+'&nbsp;&nbsp;</td></tr>';
      if (i == 3 || i == 7) {
         nc += '<tr bgcolor='+report.colors[report.color]+'><td colspan=2><IMG SRC="'+ll+'uicons/'+icons+'/tspace.gif" WIDTH=1 HEIGHT=1></td></tr>';
      }
      linecolor = 9 - linecolor;
   }
}

/*
function drawAverage(set_max) {
   if (set_max) return;
   var linecolor = 4;
   var tx,ax,sx,px,im;
   var count = [0,0,0,0,0,0];

   for (var i = 0; i<sdata.length; i++) {
      for (var j=0; j<6; j++) {
         if (sdata[i].data[j] != 0) {
            count[j]++;
	}
      }
   }

   for (var i = 0; i < tab.length; i++) {
      if ((tab[i].enabled == 0) || (tab[i].total == 0)) continue;
      tx = tab[i].total;
      //ax = tab[i].total/((report.enddate - report.startdate)/86400 + 1);
      //ax = tab[i].total/count[i];
      ax = Math.round(100*(tab[i].total/count[i]))/100;
      sx = sdata[sdata.length-1].data[i];
      px = Math.round(100*(sx - ax)/ax);
      if (px > 0) im = 'plus.gif';
      else {
         im = 'minus.gif';
         px = -1*px;
      }
      if (i == 5) {
         tx = formatMoney(tx);
         sx = formatMoney(sx);
         ax = formatMoney(ax);
      }
      else if (i == 4) {
         tx = formatTime(tx);
         sx = formatTime(sx);
         ax = formatTime(ax);
      }
      else if (i == 3) {
         tx = formatNumber(tx);
         sx = formatNumber(sx);
         ax = formatNumber(ax);
      }
      else {
         tx = addCommas(tx);
         sx = addCommas(sx);
         ax = addCommas(ax);
      }

      nc += '<tr bgcolor='+report.colors[linecolor]+'><td>'+report.fonts[0]+ss[tab[i].title]+'</td>'
      nc += '<td align=center>'+report.fonts[0]+tx+'</td>'
      nc += '<td align=center>'+report.fonts[0]+ax+'</td>'
      nc += '<td align=center>'+report.fonts[0]+sx+'</td>'
      nc += '<td align=center><IMG SRC="'+ll+'uicons/'+icons+'/'+im+'">'+report.fonts[0]+px+'%</td></tr>'
      linecolor = 9 - linecolor;
   }
}
*/

function drawTop(set_max) {
   var hotard = 1;
   var x, gx, sx, sgx;  
   for (var i = report.start; i< (report.start + report.mylength); i++) {
      if (i >= sdata.length) break;
      if (set_max) checkMax(sdata[i]);
      else drawElement(sdata[i],hotard,i,0);
      hotard = 1-hotard;
   }

   //for (var i = 0; i < sdata.length; i++) {
      //var s = sdata[i].myname;
      //if (s.indexOf("auto") >= 0) { drawElement(sdata[i],hotard,i,0); hotard = 1-hotard; }
   //}


}
function drawTree(set_max) {
   var linecolor = 5;
   var x, gx, sx, sgx, skipped=0, h=0, shown=0;  
   var ss;

   while ((shown < report.mylength) && (h < hdata.length)) {
      if (skipped >= report.start) {
         if (set_max) checkMax(hdata[h]);
         else drawElement(hdata[h],1,0,h);
         shown++;
      }
      else skipped++;
      if (hdata[h].isopen) {
         for (var i=0; i<sdata.length; i++) {
            if (shown >= report.mylength) break;

            if (report.number == 1202 && sdata[i].myname == "/") {
               ss = sdata[i].myname;
            } else {
               ss = getfirst(sdata[i].myname);
            }

            if (ss == hdata[h].myname) {
               if (skipped >= report.start) {
                  if (set_max) checkMax(sdata[i]);
                  else drawElement(sdata[i],2,0,0);
                  shown++;
               }
               else skipped++;
            }
         }
      }
      h++;
   }
}
function checkMax(element) {
   var x,gx;
   x = element.data[report.field];
   if ((report.pervable) && (report.field != 0)) gx = (Math.round(10*x/element.data[0]))/10.0;
   else gx = (Math.round(1000*x/tab[report.field].total))/10.0;
   if (gx > gmax) gmax = gx;
}
function drawElement(element,level,ii,hh) {
   var x,gx,lx,sx,sgx,tx,linecolor,ts1="",ts2="",ts3="",cator;
   if (level == 2) tx = getlast(element.myname);
   else tx = element.myname;

   if (tx == "") {
       if   (report.number == "1302") tx = "(no keyword)";
       else tx = "(no data)";
   }
   if ((report.pervable) && (report.field != 0)){
      x = element.data[0];
      sx = addCommas(x);
		if (x != 0) {
         gx = (Math.round(10*element.data[report.field]/x))/10.0;
		} else {
         gx = 0;
      }
      if (report.field == 5) sgx = formatMoney(gx);
      else if (report.field == 4) sgx = formatTime(gx);
      else if (report.field == 3) sgx = formatNumber(gx);
      else sgx = addCommas(gx);
   }
   else {
      x = element.data[report.field];
		if (tab[report.field].total != 0) { 
         gx = (Math.round(1000*x/tab[report.field].total))/10.0;
      } else { 
		   gx = 0;
		}
      sgx = formatNumber(gx) + "%";
      if (report.field == 5) sx = formatMoney(x);
      else if (report.field == 4) sx = formatTime(x);
      else if (report.field == 3) sx = formatNumber(x);
      else sx = addCommas(x);
   } 
   if (level == 0) linecolor = 5;
   if (level == 1) linecolor = 4;
   if (level == 2) linecolor = 5;
   cator = 9;
   if (element.isopen) cator=10;
   if (level == 2) cator = 11;
   if (report.type == 2) {
      ts1 = report.fonts[0];
      if (report.sortable) { ts1 += (ii+1)+'.'; }
      else {ts1 += '&nbsp;';}
   }
   if (report.type == 3) ts1 = '<IMG SRC="'+ll+'uicons/'+icons+'/ind'+cator+'.gif" WIDTH=7 HEIGHT=7 border=0>';
   if ((report.type == 3) && (level == 1)) {
      ts2='<a href="javascript:parent.hToggle('+hh+');">';
      ts3='</a>';
   }
   if (report.number == 1603) {
      tx = '<a class="normal" href="javascript:parent.zToggle('+element.prec+');">'+tx+'</A>';
   }
   lx = 100*gx/gmax;
   nc += '<tr bgcolor='+report.colors[linecolor]+'><td align=right>'+ts2+ts1+ts3+'</td>';
   nc += '<td>'+report.fonts[0]+tx+'</td><td>'+report.fonts[0]+'<center>'+sx+'</td>'
   nc += '<td>'+report.fonts[0]+'<center>'+sgx+'</td><td><IMG SRC="'+ll+'uicons/'+icons+'/hbar.gif" WIDT';
   if (lx > 100) lx=100;
   nc += 'H='+lx+' HEIGHT=8></td></tr>';
}
function drawHelp() {
   nc += '<p>&nbsp;<br><table border=0 cellspacing=0 cellpadding=0 width=552><tr><td>';
   nc += '<nobr><IMG SRC="'+ll+'uicons/'+icons+'/harrow.gif" WIDTH=7 HEI';
   nc += 'GHT=7>'+report.fonts[0]+'<b> '+ss[66]+':</b></nobr><p>'+ss[report.help];
   nc += '</td></tr></table><p>';
}
function drawUpsell() {
   nc += '<p>&nbsp;<br><table border=0 cellspacing=0 cellpadding=0 width=552><tr><td>';
   nc += '<nobr><IMG SRC="'+ll+'uicons/'+icons+'/alert.gif">';
   nc += report.fonts[0]+'<b> '+ss[68]+':</b></nobr><p>'+ss[67];
   nc += '</td></tr></table><p>';
}
function drawFoot() {
   nc += '&nbsp;<P>'+report.fonts[2]+'Urchin&reg; 3.4 - &copy;2002 <a href="http://www.quantified.com" class="normal" target=_blank>Quantified Systems, Inc</a>.<p>';
   nc += '</td></tr></TABLE>';
}

function redraw() {
   if ((report.pervable) && (report.field == 0)) report.perv = 0;
   if ((report.pervable) && (report.field == 4)) report.perv = 1;
   nc = ' ';
   drawHead();
   drawNav();
   drawReport();
   if (report.enabled == 2) { drawUpsell(); }
   if (report.showhelp) { drawHelp(); }
   drawFoot();
   var c=0;
   //for (i=0;i<500000;i++) {
      //c++;
   //}
   //alert(c);
   
   top.drawframe.document.write(nc);
   top.drawframe.document.close();
}

function getLastDay(mon,year) {
   var m = mon*1;
   var yr = year*1;
   if (m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12) { return 31; }
   if (m == 4 || m == 6 || m == 9 || m == 11) { return 30;  }
   if (m == 2) {
      if (yr%4 == 0) {return 29; }
      else             {return 28; }
   }
}

function setNewDate(date,md,type) {
   var year = date.year * 1;
   var mon = date.mon * 1;
   var day = date.day * 1;

   if (type == 1) { 
      day += md;
      if (day <= 0) {
         mon--;
         if (mon <= 0) { year--; mon += 12; }
         day += (getLastDay(mon,year))*1;
      }
      if (day > getLastDay(mon,year)*1) {
         day = (day - getLastDay(mon,year)*1);
         mon++;
         if (mon > 12) { year++; mon = 1; }
      }
   }

   if (type == 0) { 
      mon += md;
      if (mon <= 0) { year--; mon += 12; }
      if (mon > 12) { year++; mon = 1; }
   }

   date.year = year;
   if (mon < 10) { date.mon = "0"+mon; }
   else          { date.mon = ""+mon; }

   if (day < 10) { date.day = "0"+day; }
   else          { date.day = ""+day; }

}

function getDayofWeek(date) {
   var year = date.year * 1;
   var mon = date.mon * 1;
   var day = date.day * 1;
   var dow = 0;

   var leapyear = 0 
   var dayoftheyear = 0;

   if (year % 4 == 0)  { leapyear = 1; }

   if      (mon-1 == 0)  { dayoftheyear = 0   + day; }
   else if (mon-1 == 1)  { dayoftheyear = 31  + day; }
   else if (mon-1 == 2)  { dayoftheyear = 59  + day + leapyear; }
   else if (mon-1 == 3)  { dayoftheyear = 90  + day + leapyear; }
   else if (mon-1 == 4)  { dayoftheyear = 120 + day + leapyear; }
   else if (mon-1 == 5)  { dayoftheyear = 151 + day + leapyear; }
   else if (mon-1 == 6)  { dayoftheyear = 181 + day + leapyear; }
   else if (mon-1 == 7)  { dayoftheyear = 212 + day + leapyear; }
   else if (mon-1 == 8)  { dayoftheyear = 243 + day + leapyear; }
   else if (mon-1 == 9)  { dayoftheyear = 273 + day + leapyear; }
   else if (mon-1 == 10) { dayoftheyear = 304 + day + leapyear; }
   else if (mon-1 == 11) { dayoftheyear = 334 + day + leapyear; }
   else                  { dayoftheyear = 0 + day; }

   dow = 365*(year-1970) + Math.floor((year-1969)/4) + dayoftheyear;
   dow = Math.floor((dow+3)%7);

   return dow;
}


//-->

