// -- disable/enable reports

//parent.disable(3001);
//parent.disable(1204);
parent.disable(3004);
//parent.disable(1700);
//parent.upsell(1701);
//parent.upsell(1702);
//parent.upsell(1703);
//parent.upsell(1704);
//parent.upsell(1102);

// -- report sorting options
parent.report.sortnoreferral = 0;
parent.report.sortunresolved = 1;
parent.report.sortother = 1;
parent.report.sortotherhtml = 1;

// -- report options
//  
// currency symbol for ecommerce-enabled reports. Valid     
// selections are "dollar", "euro", "pound" and "yen".
parent.report.currency = "yen";

// Misc customization - turn off Log Files (aka Top Servers)
parent.disable(1106);
