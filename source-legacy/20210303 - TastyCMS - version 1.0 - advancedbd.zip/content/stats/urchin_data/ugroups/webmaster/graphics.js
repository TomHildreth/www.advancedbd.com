
parent.icons = "default";

parent.report.fonts[0] = '<FONT FACE="Verdana,Arial,Helvetica" size="-2" color=black>';
parent.report.fonts[1] = '<FONT FACE="Verdana,Arial,Helvetica" size="-2" color=white>';
parent.report.fonts[2] = '<FONT FACE="Times Roman" size=-7 color=black>';

parent.report.colors[0] = "FFFFFF";
parent.report.colors[1] = "000000";
parent.report.colors[2] = "0000AA";
parent.report.colors[3] = "CCCCCC";
parent.report.colors[4] = "EEEEEE";
parent.report.colors[5] = "FFFFFF";
parent.report.colors[6] = "66CCFF";
parent.report.colors[7] = "B9E7FF";
parent.report.colors[8] = "FFCC66";
parent.report.colors[9] = "FFE699";
parent.report.colors[10] = "8FDD8F";
parent.report.colors[11] = "CCE9CC";
parent.report.colors[12] = "66CCCC";
parent.report.colors[13] = "AFEBEB";
parent.report.colors[14] = "CCCC66";
parent.report.colors[15] = "E3E3AA";
parent.report.colors[16] = "CCCCFF";
parent.report.colors[17] = "E3E9FF";
parent.report.colors[18] = "FF9900";
parent.report.colors[19] = "339933";
